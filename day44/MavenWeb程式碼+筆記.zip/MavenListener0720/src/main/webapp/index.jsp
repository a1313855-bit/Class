<html>
<body>
	<h2><%="Hello World!"%></h2>
	<!-- applicationScope Service(Tomcat)啟動 -> Service(Tomcat)關閉 
		 這代表如果只是關閉瀏覽器資料還是會被保存，直到關機或 Service 關閉才會重製
	-->
	<h1>App Start Var Date :${applicationScope.appStart}</h1>
</body>
</html>
