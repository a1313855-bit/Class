
import jakarta.servlet.ServletContextEvent;
import jakarta.servlet.ServletContextListener;
import jakarta.servlet.annotation.WebListener;

/**
 * Application Lifecycle Listener implementation class AppContextListener
 *
 */
@WebListener
/*
 * 如果沒有 @WebListener 就要在 web.xml 裡面寫 <listener>
 * <listener-class>com.example.listener.AppContextListener</listener-class>
 * </listener>
 */

public class AppContextListener implements ServletContextListener {

	/**
	 * Default constructor.
	 */
	public AppContextListener() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see ServletContextListener#contextInitialized(ServletContextEvent)
	 */
	// 應用程式啟動時執行
	/* 寫上 @Override 代表繼承父類別的方法 */
	@Override
	public void contextInitialized(ServletContextEvent sce) {
		// TODO Auto-generated method stub
		System.out.println("=== Web 應用程式啟動 ===");

		// 取得 ServletContext
		sce.getServletContext().setAttribute("appStart", new java.util.Date());

		// 載入設定檔
		/* 取得初始化參數 Init(初始化) */
		/* 在 web.xml 裡面
		 * <context-param>
		 *  這行代表 getInitParameter(名稱)
		 *  -> <param-name>appName</param-name>
		 *  
		 *  這行代表 getInitParameter(值)
		 *  -> <param-value>WebListener0720</param-value>
		 * </context-param>
		 */
		String appName = sce.getServletContext().getInitParameter("appName");
		/* 所以這裡印出的是 應用程式名稱： WebListener0720 */
		System.out.println("應用程式名稱：" + appName);
	}

	/**
	 * @see ServletContextListener#contextDestroyed(ServletContextEvent)
	 */
	/* 寫上 @Override 代表繼承父類別的方法 */
	@Override
	public void contextDestroyed(ServletContextEvent sce) {
		// TODO Auto-generated method stub

	}

}
