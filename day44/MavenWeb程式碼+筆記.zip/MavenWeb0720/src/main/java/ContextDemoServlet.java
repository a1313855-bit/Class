
import jakarta.servlet.ServletContext;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

/**
 * Servlet implementation class ContextDemoServlet
 */
@WebServlet("/context-demo")
public class ContextDemoServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public ContextDemoServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		/* 從這一次的 request 中，取得目前 Web 應用程式的 ServletContext 物件 */
		/*
		 * ServletContext 可以理解成 代表整個 Web 應用程式的共用空間 不是只有這一位使用者，也不是只有這一次 request，而是目前整個
		 * Web 應用程式共用 變數 context 就是用來接住取得的 ServletContext 物件
		 */
		ServletContext context = request.getServletContext();

		// 1. 設定/取得全域屬性
		context.setAttribute("globalVar", "全域變數");

		/* setAttribute -> 預設回傳類型 Object 轉成 String */
		String value = (String) context.getAttribute("globalVar");

		// 2. 取得初始化參數 Init(初始化)
		/* 取得事先設定好的初始化參數 */
		String appName = context.getInitParameter("appName");

		// 3. 取得虛擬路徑對應的真實路徑
		/* 把 Web 專案裡看到的路徑，轉換成伺服器硬碟上的真正路徑 */
		String realPath = context.getRealPath("/WEB-INF");

		// 4. 取得 MIME 類型 (副檔名)
		/* 根據副檔名取得 MIME 類型 */
		String mimeType = context.getMimeType("mypicture.jpg");

		// 5. 取得版本資訊
		int majorVersion = context.getMajorVersion();
		int minorVersion = context.getMinorVersion();

		// 6. 記錄日誌
		context.log("這是一則日誌訊息");

		/* 設定文字編碼格式 */
		/* 告訴瀏覽器，這次回應內容是 HTML，而且文字編碼是 UTF-8 */
		response.setContentType("text/html;charset=utf-8");

		// 輸出結果
		/* 向 response 取得一支可以往瀏覽器回應內容中寫字的工具 */
		PrintWriter out = response.getWriter();
		out.println("<h2>ServletContext Demo</h2>");
		out.println("<p>應用程式名稱：" + appName + "</p>");
		out.println("<p>全域變數：" + value + "</p>");
		out.println("<p>真實路徑：" + realPath + "</p>");
		out.println("<p>MIME 類型：" + mimeType + "</p>");
		out.println("<p>Servlet 版本：" + majorVersion + "." + minorVersion + "</p>");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
