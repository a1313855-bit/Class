
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import model.User;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

/**
 * Servlet implementation class LoginServlet
 */
@WebServlet("/login")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	// 模擬資料庫
	private static final Map<String, User> users = new HashMap<>();

	static {
		users.put("admin", new User(1, "admin", "管理員", "admin"));
		users.put("tom", new User(2, "tom", "Tom", "user"));
		users.put("jerry", new User(3, "jerry", "Jerry", "user"));
	}

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public LoginServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		// response.getWriter().append("Served at: ").append(request.getContextPath());

		// 檢查是否已登入
		/* getSession(false) 如果存在 session 不建立新的 session */
		HttpSession session = request.getSession(false);
		/* 如果 session 不是 null 且 從表單送來的"user"(使用者) 不是 null */
		if (session != null && session.getAttribute("user") != null) {
			/* 導入到 /home */
			response.sendRedirect(request.getContextPath() + "/home");
			return;
		}

		// 顯示登入頁面
		/* 如果不存在 session 或者沒有登入過的痕跡 顯示 /login.jsp" */
		request.getRequestDispatcher("/login.jsp").forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		// doGet(request, response);
		
		/* 設計變數 username(帳號) = 從 login.jsp 收到的 username */
		String username = request.getParameter("username");
		/* 設計變數 password(密碼) = 從 login.jsp 收到的 password */
		String password = request.getParameter("password");

		// 驗證帳號密碼
		/* 用物件 User 把帳號裝起來 */
		User user = users.get(username);
		/* 如果 user 不是 null(有此帳號) 且 密碼是"1234" */
		if (user != null && "1234".equals(password)) {
			// 登入成功，建立 Session
			HttpSession session = request.getSession(true);
			session.setAttribute("user", user);
			session.setAttribute("loginTime", new java.util.Date());

			// 設定 Session 超時時間（30分鐘）
			session.setMaxInactiveInterval(30 * 60);

			// 導向首頁
			/* 登入成功 導入到 /home */
			response.sendRedirect(request.getContextPath() + "/home");
		} else {
			// 登入失敗
			/* 輸出錯誤訊息 */
			request.setAttribute("error", "帳號或密碼錯誤");
			/* 如果不存在 session 顯示 /login.jsp" */
			request.getRequestDispatcher("/login.jsp").forward(request, response);
		}
	}

}
