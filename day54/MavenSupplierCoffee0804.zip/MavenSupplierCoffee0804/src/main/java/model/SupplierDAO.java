package model;

import java.util.List;

import config.JpaUtil;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityTransaction;
import jakarta.persistence.TypedQuery;

public class SupplierDAO {
	public List<Supplier> getAll() {
		EntityManager em = JpaUtil.createEntityManager();
		try {
			TypedQuery<Supplier> query = em
					.createQuery("select s from Supplier s join fetch s.coffees order by s.supId ", Supplier.class);
			return query.getResultList();
		} catch (Exception ex) {
			throw ex;
		} finally {
			em.close();
		}
	}

	public Supplier save(Supplier supplier) {
		EntityManager em = JpaUtil.createEntityManager();
		EntityTransaction tx = em.getTransaction();
		try {
			Supplier found = em.find(Supplier.class, supplier.getSupId());
			if (found == null) {
				tx.begin();
				em.persist(supplier);
				tx.commit();
				return supplier;
			} else {
				return null;
			}
		} catch (Exception ex) {
			if (tx.isActive())
				tx.rollback();
			throw ex;
		} finally {
			em.close();
		}
	}
}
