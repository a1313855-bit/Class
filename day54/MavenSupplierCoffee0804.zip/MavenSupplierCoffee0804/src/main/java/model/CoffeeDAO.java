package model;

import java.util.List;

import config.JpaUtil;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityTransaction;
import jakarta.persistence.TypedQuery;

public class CoffeeDAO {

	public Coffee save(Coffee coffee) {
		EntityManager em = JpaUtil.createEntityManager();
		EntityTransaction tx = em.getTransaction();
		try {
			Coffee found = em.find(Coffee.class, coffee.getCofName());
			if (found == null) {
				tx.begin();
				em.persist(coffee);
				tx.commit();
				return coffee;
			} else {
				return null;
			}

		} catch (Exception ex) {
			if (tx.isActive())
				tx.rollback();
			System.out.println("save coffee jpa error " + ex.getMessage());
			throw ex;
		} finally {

			em.close();
		}
	}

	public List<Coffee> findBySupId(int SupId) {
		EntityManager em = JpaUtil.createEntityManager();
		try {
			TypedQuery<Coffee> query = em.createQuery("SELECT c FROM Coffee c WHERE c.supplier.supId = :supId",
					Coffee.class);
			query.setParameter("supId", SupId);
			List<Coffee> coffees = query.getResultList();
			return coffees;
		} finally {
			em.close();
		}
	}
	
	public Coffee updateCoffee(String cofName , Coffee coffee) {
		 EntityManager em=JpaUtil.createEntityManager();
		 Coffee existing = em.find(Coffee.class, cofName);
		 if (existing == null) return null;
		 em.getTransaction().begin();
		 existing.setPrice(coffee.getPrice());         // 更新各欄位
		 existing.setSales(coffee.getSales());
		 if (coffee.getSupplier() != null) {
		     existing.setSupplier(coffee.getSupplier());  // 可選：更新供應商
		 }
		 existing.setTotal(coffee.getTotal());
		 Coffee cf=em.merge(existing);
		 em.getTransaction().commit();
		 return cf;
	}
}
