<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8"%>
<!-- 匯入 uri="jakarta.tags.core" 使其可以執行 forEach -->
<%@ taglib prefix="c" uri="jakarta.tags.core"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Employee View</title>
</head>
<body>
	<table border="1" width="50%">
		<tr>
			<!-- 設計欄位名稱 -->
			<th>編號</th>
			<th>名字</th>
			<th>Email</th>
			<th>職稱</th>
			<th>辦公室</th>
		</tr>
		<!-- c:forEach 逐筆走訪 requestScope.emps。
		 	 items 是要走訪的 List，var="employee" 表示每次迴圈取出的一筆 Employees 物件 -->
		<c:forEach var="employee" items="${requestScope.emps}">
			<tr>
				<!-- 欄位內填入收到的值 -->
				<!-- 補充：
					 EL 透過 JavaBean getter 取得 Employees 的屬性。
					 例如 ${employee.employeeNumber} 會對應 getEmployeeNumber()。
				-->
				<td>${employee.employeeNumber}</td>
				<td>${employee.firstName}/${employee.lastName}</td>
				<td>${employee.email}</td>
				<td>${employee.jobTitle}</td>
				<td>${employee.officeCode}</td>
			</tr>
		</c:forEach>
	</table>
</body>
</html>