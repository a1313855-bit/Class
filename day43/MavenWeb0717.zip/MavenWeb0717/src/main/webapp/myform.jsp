<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Submit Test</title>
</head>
<body>
	<!-- action=執行的Servlet method=執行方法 -->
	<form action="submitTest" method="post">
		<!-- type=數字 name=變數名稱 min=最小值 max=最大值 value=預設值 -->
		Value 1:<input type="number" name="num1" min="10" max="20" value="10" /><br />
		Value 2:<input type="number" name="num2" min="10" max="20" value="12" /><br />
		<!-- type=數字 name=變數名稱 value=預設值 -->
		<input type="submit" name="submit" value="add" /> 
		<input type="submit" name="submit" value="multiply" />
	</form>
</body>
</html>