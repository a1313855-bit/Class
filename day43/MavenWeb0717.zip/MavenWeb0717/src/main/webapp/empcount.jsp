<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Show Employee Number In City</title>
</head>
<body>
<h1>
   <!-- city 與 num 都是 MySQL2Servlet 使用 request.setAttribute() 放入的資料。
   		forward 到此 JSP 後，再由 EL 的 requestScope 取得並顯示 -->
   ${requestScope.city} has Employee count: ${requestScope.num} 
</h1>
</body>
</html>