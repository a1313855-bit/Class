<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>User Greeting</title>
</head>
<body>
<h1>
   Message : ${greeting}
</h1>
</body>
</html>