<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>View</title>
</head>
<body>
	<h2>
		<!-- requestScope 是 EL 的隱含物件，用來取得 request 範圍中的 attribute -->
		<!-- 這裡的 ${requestScope.first} 會取得 Servlet 中 request.setAttribute("first", ...) 放入的資料。
			 ⭐ 目前 MVC 資料流：
			 Servlet setAttribute → forward → JSP 使用 EL 顯示。
		-->
		Model data is ${requestScope.first}
	</h2>
</body>
</html>