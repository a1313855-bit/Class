
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * Servlet implementation class SubmitTestServlet
 */
@WebServlet("/submitTest")
public class SubmitTestServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public SubmitTestServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		// doGet(request, response);
		/* 設計一個變數 n1 裡面放入從 網頁(這次是myform) 裡的變數("num1") 的值 */
		String n1 = request.getParameter("num1");
		/* 設計一個變數 n2 裡面放入從 網頁(這次是myform) 裡的變數("num2") 的值 */
		String n2 = request.getParameter("num2");
		/* 設計一個變數 sb 裡面放入從 網頁(這次是myform) 裡的變數("submit") 的值 */
		String sb = request.getParameter("submit");
		/* switch(sb) 來辨識從 網頁(這次是myform) 裡的變數("submit") 是哪一個 */
		switch (sb) {
		/* 是"add"的場合 相加 */
		case "add":
			/* 設計一個變數 value=相加結果 網頁輸入進來的值預設 String 轉成 Integer 做運算 */
			int value = Integer.parseInt(n1) + Integer.parseInt(n2);
			/* 輸出相加運算結果 */
			response.getWriter().append("add: ").append("" + value);
			break;
		/* 是"multiply"的場合 相乘 */
		case "multiply":
			/* 設計一個變數 value=相乘結果 網頁輸入進來的值預設 String 轉成 Integer 做運算 */
			int value2 = Integer.parseInt(n1) * Integer.parseInt(n2);
			/* 輸出相乘運算結果 */
			response.getWriter().append("Multiply: ").append("" + value2);
			break;
		/* 都不是 輸出運算錯誤 */
		default:
			response.getWriter().append("Invalid OP");
			break;
		}
	}

}
