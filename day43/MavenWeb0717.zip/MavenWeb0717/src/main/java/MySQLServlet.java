
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import model.Employees;
import model.EmployeesDAO;

import java.io.IOException;
import java.util.List;

/**
 * Servlet implementation class MySQLServlet
 */
@WebServlet("/mysql")
public class MySQLServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public MySQLServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		/* 建立 EmployeesDAO 物件 */
		EmployeesDAO dao = new EmployeesDAO();
		/* 設計一個變數 city 裡面放入值 */
		String city = request.getParameter("city");
		/* 如果 city 沒有值( null , 空白 ) 查詢 Boston */
		if (city == null || city == "")
			city = "Boston";
		/* 用 EmployeesDAO 方法 execGetEmpInOffice(city) */
		/* 補充：DAO 回傳 List<Employees>，Servlet 再負責把這份 Model 資料交給 JSP 顯示。 */
		List<Employees> data = dao.execGetEmpInOffice(city);
		/* request.setAttribute 將查詢結果放入 request 範圍 ( 變數名稱 , 變數內容 ) */
		request.setAttribute("emps", data); //->data(所在城市辦公室資訊)
		/* request.getRequestDispatcher 導向 show.jsp(可自己設計) 與 View 串聯 */
		request.getRequestDispatcher("show.jsp").forward(request, response);
		/* 顯示該城市的員工資訊 */
		//response.getWriter().append(data.toString());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
