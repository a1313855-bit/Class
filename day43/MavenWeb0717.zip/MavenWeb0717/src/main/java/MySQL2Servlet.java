

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import model.EmployeesDAO;

import java.io.IOException;

/**
 * Servlet implementation class MySQL2Servlet
 */
@WebServlet("/mysql2")
public class MySQL2Servlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public MySQL2Servlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		/* 建立 EmployeesDAO 物件 */
		EmployeesDAO dao=new EmployeesDAO();
		/* 設計一個變數 city 裡面放入值 */
		String city=request.getParameter("city");
		/* 如果 city 沒有值( null , 空白 ) 查詢 Boston */
		if(city==null || city=="")
			city="Boston";
		/* 用 EmployeesDAO 方法 execGetEmpCountInOffice(city) */
		/*
		補充：
		這個 DAO 方法呼叫 Stored Procedure 的 OUT 參數，
		最後回傳指定城市的員工人數。
		 */
		int data=dao.execGetEmpCountInOffice(city);
		/* request.setAttribute 將查詢結果放入 request 範圍 ( 變數名稱 , 變數內容 ) */
		request.setAttribute("num", data); //->data(辦公室人數)
		request.setAttribute("city", city); //->city(目前所在城市)
		/* request.getRequestDispatcher 導向 empcount.jsp(可自己設計) 與 View 串聯 */
		request.getRequestDispatcher("empcount.jsp").forward(request, response);
		/* 顯示該城市的員工人數 */
		//response.getWriter().append("Employees in "+city+ " has "+data+" people");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
