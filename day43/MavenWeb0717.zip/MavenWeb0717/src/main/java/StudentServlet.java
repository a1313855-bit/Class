import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import model.*;
import java.util.*;

/**
 * Servlet implementation class StudentServlet
 */
@WebServlet("/student")
public class StudentServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private StudentDAO studentDAO;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public StudentServlet() {
		super();
		studentDAO = new StudentDAO();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		// response.getWriter().append("Served at: ").append(request.getContextPath());
		String action = request.getParameter("action");
		if (action == null)
			action = "list";

		switch (action) {
		case "list":
			listStudents(request, response);
			break;
		case "add":
			request.getRequestDispatcher("student-form.jsp").forward(request, response);
			break;
		case "edit":
			editStudent(request, response);
			break;
		default:
			listStudents(request, response);
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		// doGet(request, response);
		request.setCharacterEncoding("UTF-8");
		String action = request.getParameter("action");

		if ("save".equals(action)) {
			saveStudent(request, response);
		} else if ("update".equals(action)) {
			updateStudent(request, response);
		}
	}

	void listStudents(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		List<Student> data = studentDAO.findAll();
		request.setAttribute("students", data);
		request.getRequestDispatcher("student-list.jsp").forward(request, response);
	}

	private void editStudent(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		int id = Integer.parseInt(request.getParameter("id"));
		Student student = studentDAO.findById(id);
		request.setAttribute("student", student);
		request.setAttribute("isEdit", true);
		request.getRequestDispatcher("student-form.jsp").forward(request, response);
	}

	private void saveStudent(HttpServletRequest request, HttpServletResponse response) throws IOException {

		String name = request.getParameter("name");
		int age = Integer.parseInt(request.getParameter("age"));
		String email = request.getParameter("email");

		Student student = new Student(0, name, age, email);
		studentDAO.save(student);

		response.sendRedirect("student?action=list");
	}

	private void updateStudent(HttpServletRequest request, HttpServletResponse response) throws IOException {

		int id = Integer.parseInt(request.getParameter("id"));
		String name = request.getParameter("name");
		int age = Integer.parseInt(request.getParameter("age"));
		String email = request.getParameter("email");

		Student student = new Student(id, name, age, email);
		studentDAO.save(student);

		response.sendRedirect("student?action=list");
	}
}
