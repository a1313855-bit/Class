

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import model.HelloModel;
/**
 * Servlet implementation class HelloController
 */
@WebServlet("/hello")
public class HelloController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	/* 先導入 HelloModel 物件 */
    HelloModel model=new HelloModel();   
    /**
     * @see HttpServlet#HttpServlet()
     */
    public HelloController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		/* 設計一個變數 n 裡面放入值 */
		String n=request.getParameter("username");
		/* 如果 n 沒有值( null , 空白 ) 導入 Mary */
		if(n==null||n=="") {
			n="Mary";
		}
		/* 設計一個變數 message 裡面放入 HelloModel 物件 .says(n)方法的值(massage) */
		String message=model.says(n);
		/* request.setAttribute 設置變數 ( 變數名稱 , 變數內容 ) */
		request.setAttribute("greeting", message);
		/* request.getRequestDispatcher 導向 helloview.jsp(可自己設計) 與 View 串聯 */
		request.getRequestDispatcher("helloview.jsp").forward(request, response);
		//response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
