package model;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;

public class EmployeesDAO {
	/* 設計一個方法與資料庫取得連線 */
	/* 補充：create() 的責任是建立並回傳 Connection，提供 DAO 內其他方法連線資料庫 */
	Connection create() {
		/* 取得連線所需要的三個資訊 */
		String url = "jdbc:mysql://localhost:3306/classicmodels";
		String user = "root";
		String password = "1234";
		try {
			/* 載入 MySQL JDBC Driver 類別 */
			Class.forName("com.mysql.cj.jdbc.Driver");
			/* DriverManager.getConnection 輸入連線的三個資訊 */
			Connection conn = DriverManager.getConnection(url, user, password);
			/* 連線成功後回傳 Connection 物件 conn */
			return conn;
		} catch (Exception ex) {
			/* 連線失敗印出訊息 + 原因 */
			System.out.println("Connection error " + ex.getMessage());
		}
		/* 連線失敗時回傳 null(空值) */
		return null;
	}

	/* 設計一個方法來使用MySQL的 Stored Procedures */
	/* 補充： 這個方法會呼叫 MySQL Stored Procedure， 並把查詢結果轉換成 List<Employees> 回傳 */
	public List<Employees> execGetEmpInOffice(String city) {
		/* 用剛做好的 create() 取得連線 */
		Connection conn = create();
		/* 如果未取得連線(null) 新增一個空的 ArrayList<Employees>() */
		if (conn == null)
			return new ArrayList<Employees>();
		/*
		 * Connection、CallableStatement、ResultSet 都是資料庫資源。 目前老師的範例重點在 JDBC 與 Stored
		 * Procedure 流程， 但使用完後通常需要關閉，避免連線資源一直被占用。
		 */

		try {
			/* 用.prepareCall 用來建立可呼叫 Stored Procedure 的 CallableStatement */
			CallableStatement st = conn.prepareCall("call classicmodels.GetEmpInOffice(?)");
			/* 填入第一個問號 內容為 city */
			st.setString(1, city);
			ResultSet rs = st.executeQuery();
			/* 做一個空的 ArrayList<Employees>() 來裝查詢到的資料 */
			List<Employees> data = new ArrayList<>();
			/* while(rs.next()) 查詢所有city內的所有資料 */
			while (rs.next()) {
				/* 新增一個空的 Employees 物件 來把資料放進去 */
				Employees e1 = new Employees();
				/* 從目前 ResultSet 這一筆資料中，依欄位名稱取得各欄位值 */
				int no = rs.getInt("employeeNumber");
				String fn = rs.getString("firstName");
				String ln = rs.getString("lastName");
				String ex = rs.getString("extension");
				String em = rs.getString("email");
				String code = rs.getString("officeCode");
				int rpt = rs.getInt("reportsTo");
				String job = rs.getString("jobTitle");
				/* 透過 setter 將 ResultSet 取得的資料設定到 Employees 物件 */
				e1.setEmployeeNumber(no);
				e1.setFirstName(fn);
				e1.setLastName(ln);
				e1.setExtension(ex);
				e1.setEmail(em);
				e1.setOfficeCode(code);
				e1.setReportsTo(rpt);
				e1.setJobTitle(job);
				/* 新增進 ArrayList */
				data.add(e1);
			}
			/* 回傳包含查詢結果的 List<Employees> */
			return data;
		} catch (Exception ex) {
			/* 失敗印出訊息 + 原因 */
			System.out.println("execGetEmpInOffice error " + ex.getMessage());
		}
		/* 如果未取得連線(null) 回傳空的ArrayList<Employees>() */
		return new ArrayList<Employees>();
	}

	/* 設計一個方法來使用MySQL的 Stored Procedures */
	public int execGetEmpCountInOffice(String city) {
		/* 用剛做好的 create() 取得連線 */
		Connection conn = create();
		/* 如果未取得連線(null) 回傳-1(因為人數不可能是負數回傳負數代表錯誤) */
		if (conn == null)
			return -1;
		try {
			/* 用.prepareCall 呼叫MySQL語法 */
			CallableStatement st = conn.prepareCall("call classicmodels.GetEmpCountInOffice(?,?)");
			/* 填入第一個問號 內容為 city */
			st.setString(1, city);
			/* 填入第二個問號 內容為 INTEGER(辦公室內人數) */
			st.registerOutParameter(2, Types.INTEGER);
			st.execute();
			/* 回傳辦公室內的人數 */
			return st.getInt(2);
		} catch (Exception ex) {
			/* 失敗印出訊息 + 原因 */
			System.out.println("execGetEmpCountInOffice error " + ex.getMessage());
		}
		/* 如果未取得連線(null) 回傳-1(因為人數不可能是負數回傳負數代表錯誤) */
		return -1;
	}
}
