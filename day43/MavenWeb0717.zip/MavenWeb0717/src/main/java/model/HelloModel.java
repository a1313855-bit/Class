package model;

import java.util.HashMap;
import java.util.Map;
/* 建立一個 Model 資料模型 */
public class HelloModel {
	/* 建立一個 Map<String, String> < key , massage > */
	Map<String, String> model = new HashMap<>();
	/* 建立一個 HelloModel() 方法放入內容 */
	public HelloModel() {
		/* .put( key , massage ) 把內容放進 Map<String, String> */
		model.put("Mary", "Good Day");
		model.put("Janet", "Hi");
		model.put("Alan", "Good Afternoon");
	}
	
	/* 建立一個 says(String n) 放入名稱(n) 找出 massage */
	public String says(String n) {
		/* 建立一個 greet 變數名稱取出的 massage 取出 */
		String greet = model.get(n);
		/* 回傳名稱和訊息 */
		return "Your Name is " + n + " says " + greet;
	}
}
