package repository;

import java.util.List;
import java.util.Optional;

import model.Book;

public interface Repository<T, ID> {
    T save(T entity);
    Optional<T> findById(ID id);
    List<T> findAll();
    T update(ID id,T entity);
    void deleteById(ID id);
    boolean existsById(ID id);
	/** 依價格區間查詢 */
	List<Book> findByPriceRange(Double min, Double max);
}
