package controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.DefaultValue;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import model.Book;
import repository.Repository;
import repository.BookDAO;

@Path("/books")
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
public class BookController {
	Repository<Book, Long> repo = new BookDAO();

	@GET
	public Response getAllBook() {
		List<Book> data = repo.findAll();
		return Response.ok(ok(data)).build();
	}

	@GET
	@Path("/{id}")
	public Response findById(@PathParam("id") Long id) {
		Optional<Book> found = repo.findById(id);
		if (found.isPresent()) {
			return Response.ok(ok(found.get())).build();
		} else {
			return Response.status(Response.Status.NOT_FOUND).entity(fail("查無此ID")).build();
		}
	}

	@GET
	@Path("/price")
	public Response findByPriceRange(@DefaultValue("1") @QueryParam("min") double min,
			@DefaultValue("200") @QueryParam("max") double max) {
		List<Book> data = repo.findByPriceRange(min, max);
		if (data != null && data.size() > 0)
			return Response.ok(ok(data)).build();
		else
			return Response.status(Response.Status.NOT_FOUND).entity(fail("沒有資料")).build();
	}

	/*
	 * @GET
	 * 
	 * @Path("/price") public Response
	 * findByPriceRange(@DefaultValue("-1") @QueryParam("max") Double max,
	 * 
	 * @DefaultValue("-2") @QueryParam("min") Double min) { if (max.equals("-1") ||
	 * min.equals("-2")) { return
	 * Response.status(Response.Status.BAD_REQUEST).entity(fail("請輸入正確金額區間")).build(
	 * ); } else { List<Book> data = repo.findByPriceRange(min, max); if (data !=
	 * null && data.size() > 0) { return Response.ok(ok(data)).build(); } else {
	 * return Response.noContent().entity(fail("該金額區間無資料")).build(); } } }
	 */

	@POST
	public Response saveBook(Book book) {
		try {
			Book added = repo.save(book);
			return Response.ok(added).build();
		} catch (Exception ex) {
			System.out.println("saveBook error " + ex.getMessage());
			return Response.status(Response.Status.BAD_REQUEST).entity(fail(ex.getMessage())).build();
		}
		// return Response.noContent().build();
	}

	@PUT
	@Path("/{id}")
	public Response updateBook(@PathParam("id") Long id, Book book) {
		Book found = repo.update(id, book);
		if(found!=null) {
			return Response.ok(ok(found)).build();
		}else {
			return Response.status(Response.Status.NOT_FOUND).entity(fail("查無此ID")).build();
		}
	}
	
	@DELETE
	@Path("/{id}")
	public Response deleteBook(@PathParam("id") Long id) {
		Optional<Book> found = repo.findById(id);
		if(found.isPresent()) {
			repo.deleteById(id);
			return Response.ok(ok(found.get())).build();
		}else {
			return Response.status(Response.Status.NOT_FOUND).entity(fail("查無此ID")).build();
		}
		
	}

	private Map<String, Object> ok(Object data) {
		return Map.of("success", true, "data", data);
	}

	private Map<String, Object> fail(String msg) {
		return Map.of("success", false, "error", msg);
	}
}
