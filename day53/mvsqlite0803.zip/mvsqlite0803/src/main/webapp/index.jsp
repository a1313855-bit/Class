<html>
<body>
<h2><% response.sendRedirect("api/books/price"); %></h2>
</body>
</html>
