/* config 設定檔 */
package config;

import jakarta.ws.rs.ApplicationPath;
import jakarta.ws.rs.core.Application;

/**
 * JAX-RS Application 設定
 *
 * 作用：告訴 Jersey「請把所有 REST 資源的根路徑設為 /api」
 * 繼承 Application：Jersey 偵測到此類別後會啟動自動掃描
 * @ApplicationPath 定義所有 REST API 的根路徑為 /api
 */
/* 💡 我的理解 : 把 "/api" 設定為入口路徑 */
@ApplicationPath("/api")
public class MyFirstApp extends Application{
	// 空白實作：Jersey 會自動掃描並登錄所有帶有 @Path 的 Resource 類別
    // 若需要手動控制，可覆寫 getClasses() 或 getSingletons() 方法
}

/* ❄ 重點 : 可以創建多個入口路徑 */
/* 📝 範例 : MySecondApp.java */