import jakarta.ws.rs.GET;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;

@Path("/hello")
public class Hello {
	/* 💡 我的理解 : Servlet 的 toGet */
	@GET	
	/* 📖 概念 : 告訴伺服器：這個方法回傳的資料格式是 HTML */
	/* @Produces 這個 API 會產生 (Produce) 什麼格式的資料 */
	@Produces(MediaType.TEXT_HTML)
	public String sayHello() {
		return "<h1>Hello World</h1>";
	}
}