package controller;

import java.net.URI;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.DefaultValue;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import model.Employee;

/**
 * Employee REST Controller
 *
 * 類別層級標注說明：
 *   @Path("/employees")  → 此類別處理所有 /api/employees 開頭的請求
 *   @Produces(JSON)      → 類別內所有方法預設回應 application/json
 *   @Consumes(JSON)      → 類別內所有方法預設接受 application/json 請求體
 *   （方法層級的標注可覆寫類別層級的設定）
 */
@Produces(MediaType.APPLICATION_JSON) // 預設回應 JSON
@Consumes(MediaType.APPLICATION_JSON) // 預設接受 JSON
@Path("/employees")
public class EmployeeController {

	/* 💡 我的理解 : Servlet 的 toGet */
	@GET
	/* 📖 概念 : 告訴伺服器：這個方法回傳的資料格式是 JSON */
	@Produces(MediaType.APPLICATION_JSON)
	public Employee create() {
		Employee e1 = new Employee();
		e1.setId(1);
		e1.setName("Mr.A");
		e1.setDepartment("Personnel");
		e1.setSalary(30000.0);
		e1.setEmail("aaa@dome.con");
		e1.setActive(true);
		return e1;
	}

	// 暫時用 ConcurrentHashMap 模擬資料庫
	private static final Map<Integer, Employee> DB = new HashMap<>();
	private static int nextId = 1; // 模擬自動遞增 ID

	// static 區塊：類別載入時執行一次，填入測試資料
	/* 💡 我的理解 : 會把裡面的程式存在記憶體中，所以不會每次執行程式都創建一次 */
	static {
		/* 💡 我的理解 : HashMap 新增資料用 .put < key , value > */
		DB.put(1, new Employee(nextId++, "Mr.A", "Engineering", 85000, "aaa@demo.com", true));
		DB.put(2, new Employee(nextId++, "Mr.B", "Marketing", 72000, "bbb@demo.com", false));
		DB.put(3, new Employee(nextId++, "Mr.C", "Engineering", 90000, "ccc@demo.com", true));
	}

	/**
	 * 取得所有員工 GET /api/employees
	 *
	 * 回傳：200 OK + Employee 陣列（JSON） 若無資料，回傳空陣列 [] 而非 null（避免客戶端
	 * NullPointerException）
	 */
	/* ⚠ 注意 : 一個程式內不可以有兩個相同路徑的 @GET */
	@GET
	/* 🔍 原因 : 由於上面已經有 @GET 所以此方法要新增一個不同的路徑 */
	@Path("/all")
	/* 💡 我的理解 : 此方法回傳 Response 物件 */
	public Response getAllEmployees() {
		/* 💡 我的理解 : 新增 ArrayList 物件內容裝載 HashMap 物件的所有資料 */
		List<Employee> employees = new ArrayList<>(DB.values());
		/* 📖 概念 : 回傳 HTTP 200 OK 的 Response 物件 */
		/* 📖 概念 : .header 自訂 Header（如分頁資訊） */
		return Response.ok(employees).header("X-Total-Count", employees.size()).build(); // Response.ok() 自動設定狀態碼 200
	}

	/**
	 * 依 ID 取得員工 GET /api/employees/{id}
	 *
	 * @PathParam("id") 將 URI 中 {id} 的值注入為方法參數 回傳：找到 → 200 + Employee JSON；找不到 → 404
	 * + 錯誤訊息
	 */

	@GET
	@Path("/{id}")
	/* 💡 我的理解 : @PathParam : 路徑參數 */
	/* 💡 我的理解 : 把路徑參數放進 id */
	public Response getEmployeeById(@PathParam("id") int id) {
		/* 💡 我的理解 : HashMap 物件打包成 Employee 物件 */
		/* .get(key) key 裡的值 */
		Employee emp = DB.get(id);
		/* 💡 我的理解 : 如果獲得的 HashMap 物件沒有值(null) */
		if (emp == null) {
			// 404 Not Found：資源不存在時的標準回應
			return Response.status(Response.Status.NOT_FOUND)
					/* 💡 我的理解 : .entity 的括弧 是 Json 的語法 */
					.entity("{\"message\":\"Employee not found: " + id + "\"}").build();
		}
		/* 📖 概念 : 200 OK : 成功 */
		return Response.ok(emp).build();
	}

	@GET
	@Path("/search")
	/* 💡 我的理解 : @DefaultValue : 預設值 */
	/* 💡 我的理解 : @QueryParam : 詢問參數 📝 範例 : /search?department="" */
	/* 💡 我的理解 : 把詢問參數放進 department 如果沒有寫值，預設為 NA */
	public Response searchDepartment(@DefaultValue("NA") @QueryParam("department") String department) {

		/* 💡 我的理解 : 如果參數 department 字元等於 "NA" */
		/* 🔍 原因 : 預設輸入 "NA" 代表沒填入 department */
		if (department.equals("NA")) {
			/* 📖 概念 : 400 Bad Request : 請求格式錯誤 */
			return Response.status(Response.Status.BAD_REQUEST).entity("{\"message\":\"department 參數為必填\"}").build();
		}
		/* 💡 我的理解 : HashMap 物件內的資料打包進 ArrayList 再藉由 ArrayList 打包進 List */
		/* 🔍 原因 : ArrayList 和 List 是父子類別， HashMap 無關聯物件 */
		List<Employee> data = new ArrayList<Employee>(DB.values());

		/* 📖 概念 : */
		/* 1. .stream() 把 data(List) 變成一條可以加工處理的資料流 */
		/* 2. .filter(...) 過濾符合條件的資料 */
		/* 3. Lambda語法 如果部門符合，就保留使用 equalsIgnoreCase() 忽略大小寫 */
		/* 4. toList() 把 Stream 收集回 List */
		/* 5. 把篩選過後的內容打包進 List 物件 變數名稱 found */
		List<Employee> found = data.stream().filter(d -> d.getDepartment().equalsIgnoreCase(department)).toList();

		/* 💡 我的理解 : 如果 found 不是 null(空值) 且 found 裡的資料數量大於 0 */
		/* 🔍 原因 : !=null(空值) 不等於空值代表有資料 , List.size()->顯示資料數量 大於0表示有資料 */
		if (found != null && found.size() > 0) {
			/* 📖 概念 : HTTP 200 OK 的 Response 物件 */
			return Response.ok(found).build();
		} else {
			/* 📖 概念 : 204 No Content : 成功但無內容 */
			return Response.noContent().build();
		}
	}
	
	@POST
	public Response createEmployee(Employee employee) {
		/* 📖 概念 : */
		// 201 Created + Location Header（POST 成功建立資源時使用）
    	// Location Header 告訴客戶端新資源的 URI 在哪裡
		// TODO 1：驗證 employee 及 name 不為 null/空白
		if(employee.getName()==null || employee.getName()=="") {
			/* 📖 概念 : 400 Bad Request : 請求格式錯誤 */
    		return Response.status(Response.Status.BAD_REQUEST)
    				.entity("{\"message\":\"Employee Name must have Value\"}").build();
    	}
		// TODO 2：指派新的 ID（使用 nextId++）
		employee.setId(nextId++);
		// TODO 3：存入 DB
		DB.put(employee.getId(), employee);
		// TODO 4：建構 Location URI
	    //         提示：URI.create("employees/" + employee.getId())
		// TODO 5：回傳 201 Created + Location Header + Employee 物件
    	return Response.created(URI.create("employees/" + employee.getId()))
    	        .entity(employee)       // 選擇性：把新建的資源也一起回傳
    	        .build();
	}
	
	/* 💡 我的理解 : @DELETE : 刪除 */
	@DELETE
	@Path("/{id}")
	public Response deleteEmployeeById(@PathParam("id") int id) {
		/* 💡 我的理解 : .remove(key) 將 key 裡的值刪除 並打包成一個 Employee 物件 */
		Employee emp = DB.remove(id);
		/* 💡 我的理解 : 如果獲得的 emp 沒有值(null) */
		if (emp == null) {
			// 404 Not Found：資源不存在時的標準回應
			return Response.status(Response.Status.NOT_FOUND)
					/* 💡 我的理解 : .entity 的括弧 是 Json 的語法 */
					.entity("{\"message\":\"Employee not found: " + id + "\"}").build();
		}
		/* 📖 概念 : 204 No Content : 成功但無內容 */
		/* 🔍 原因 : 代表刪除成功所以沒有內容 */
		return Response.noContent().build();
	}
}
