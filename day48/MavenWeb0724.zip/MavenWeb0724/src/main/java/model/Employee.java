package model;

import com.fasterxml.jackson.annotation.JsonIgnore;

/**
 * 員工資料模型（POJO）
 *
 * 序列化方向：Java Employee 物件 → {"id":1,"name":"Alice",...}（回傳給客戶端）
 * 反序列化方向：{"name":"Dave",...} → Java Employee 物件（客戶端 POST 過來）
 */

public class Employee {

    private int id;
    private String name;
    private String department;
    /* 💡 我的理解 : 隱藏 Json 屬性(不是消失) */
    //@JsonIgnore
    private double salary;
    private String email;
    private boolean active;

    // ★ 無參數建構子（Jackson 反序列化時必須存在，否則拋出 InvalidDefinitionException）
    public Employee() {}

    //public Employee(int id, String name, String department, double salary) {
    //    this.id = id;
    //    this.name = name;
    //    this.department = department;
    //    this.salary = salary;
    //}
    
    public Employee(int id, String name, String department, double salary, String email, boolean active) {
		super();
		this.id = id;
		this.name = name;
		this.department = department;
		this.salary = salary;
		this.email = email;
		this.active = active;
	}

    // Getters & Setters
    public int getId() { return id; }
	public void setId(int id) { this.id = id; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getDepartment() { return department; }
    public void setDepartment(String department) { this.department = department; }

    public double getSalary() { return salary; }
    public void setSalary(double salary) { this.salary = salary; }
    
    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }
    
    public boolean isActive() { return active; }
    public void setActive(boolean active) { this.active=active; }

	@Override
	public String toString() {
		return "Employee [id=" + id + ", name=" + name + ", department=" + department + ", salary=" + salary
				+ ", email=" + email + ", active=" + active + "]";
	}

    
}