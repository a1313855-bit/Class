# MavenWeb0715 註解 Code Review

## 已直接修正的程式問題

1. `user.html` 的 `methods="post"` 改為 `method="post"`。原寫法不會正確設定 POST。
2. `user.html` 的 `</br>` 改為 `<br>`。`br` 是空元素，不使用結尾標籤。
3. `userform.jsp` 的建構式註解修正為 `new User(name, Integer.parseInt(age))`，因為建構式第二個參數是 `int`。

## 註解用語統一

- 「呼叫 HTML 裡的變數」改為「從 Request 取得表單參數」。HTML 表單送出的是參數，不是可供 JSP 直接呼叫的變數。
- `<% %>` 統一標記為 JSP Scriptlet，其中撰寫 Java 程式碼。
- `session.setAttribute()` 說明為「在 Session 中儲存屬性」。
- `pageContext.setAttribute()` 說明為「在 page scope 中儲存屬性」，不是把物件轉換成 EL 變數。
- `${user.name}` 說明為透過 JavaBean 的 `getName()` 讀值。
- `sendRedirect()` 說明為要求瀏覽器重新發出另一個請求，而不只是一般的「返回」。

## 標記方式

- `[保留並補充]`：原方向正確，增加精準說明。
- `[修正]`：原註解容易誤解或用詞不準確，已改寫。
- `[注意]`：程式可行，但有型別或使用條件需要留意。
- `[補充]`：原本沒有錯，但加入目前理解所需的重點。
