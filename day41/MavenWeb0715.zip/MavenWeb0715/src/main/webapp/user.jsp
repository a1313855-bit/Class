<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>User JSP</title>
</head>
<body>
	<%
	/* [修正] 以下是 JSP Scriptlet，區塊內撰寫 Java 程式碼。 */
	/* [修正] 從 Request 取得 name="username" 的表單參數，存入區域變數 username。 */
	String username = request.getParameter("username");
	
	/* [修正] 將 username 存入 Session，屬性名稱為 user。 */
	session.setAttribute("user", username);
	%>
	<!-- [保留並補充] 使用 EL 取得本次 Request 的 username 參數。 -->
	<!-- [修正] ${param.username} 不是呼叫 HTML，而是讀取 Request 參數。 -->
	<h1>User Name is ${param.username}</h1>
</body>
</html>