<%@ page contentType="text/html;charset=UTF-8"%>
<!-- prefix（JSTL 標籤的前綴名稱）  -->
<!-- 💡 實務補充 uri 用來指出這個 prefix 對應哪一套標籤庫 -->
<%@ taglib prefix="c" uri="jakarta.tags.core"%>
<!DOCTYPE html>
<html lang="zh-TW">
<head>
<meta charset="UTF-8">
<title>EL 基本練習</title>
<style>
body {
	font-family: "Microsoft JhengHei", Arial;
	max-width: 800px;
	margin: 50px auto;
	padding: 20px;
}

.section {
	background: #f9f9f9;
	padding: 15px;
	margin: 10px 0;
	border-radius: 5px;
}

h2 {
	color: #333;
	border-bottom: 2px solid #3498db;
	padding-bottom: 5px;
}

.result {
	color: #27ae60;
	font-weight: bold;
}
</style>
</head>
<body>
	<h1>EL 基本練習</h1>

	<!-- 設定變數 -->
	<!-- 補充：這裡使用 c:set 建立 name、age、score 三個 EL 可以取得的變數 -->
	<c:set var="name" value="張小明" />
	<c:set var="age" value="25" />
	<c:set var="score" value="85.5" />

	<!-- 1. 顯示變數 -->
	<!-- 補充：${name}、${age}、${score} 是用 EL 取得並輸出前面設定的變數值 -->
	<div class="section">
		<h2>1. 顯示變數</h2>
		<p>姓名：<span class="result">${name}</span></p>
		<p>年齡：<span class="result">${age}</span></p>
		<p>分數：<span class="result">${score}</span></p>
	</div>

	<!-- 2. 算術運算 -->
	<!-- 補充：EL 可以直接進行加、減、乘、除及取餘數等基本算術運算 -->
	<div class="section">
		<h2>2. 算術運算</h2>
		<p>10 + 5 = <span class="result">${10 + 5}</span></p>
		<p>10 - 5 = <span class="result">${10 - 5}</span></p>
		<p>10 * 5 = <span class="result">${10 * 5}</span></p>
		<!-- EL 的除法運算會保留小數結果 -->
		<p>10 / 3 = <span class="result">${10 / 3}</span></p>
		<p>10 % 3 = <span class="result">${10 % 3}</span></p>
	</div>

	<!-- 3. 比較運算 -->
	<!-- 補充：比較運算的結果會是 true 或 false -->
	<div class="section">
		<h2>3. 比較運算</h2>
		<p>10 > 5：<span class="result">${10 > 5}</span></p>
		<p>10 < 5：<span class="result">${10 < 5}</span></p>
		<p>10 == 10：<span class="result">${10 == 10}</span></p>
		<p>10 != 5：<span class="result">${10 != 5}</span></p>
	</div>

	<!-- 4. 邏輯運算 -->
	<!-- 補充：&& 表示「且」、|| 表示「或」、! 表示「相反」 邏輯運算的結果同樣會是 true 或 false -->
	<div class="section">
		<h2>4. 邏輯運算</h2>
		<p>true && false：<span class="result">${true && false}</span></p>
		<p>true || false：<span class="result">${true || false}</span></p>
		<p>!true：<span class="result">${!true}</span></p>
	</div>

	<!-- 5. 條件運算 -->
	<!-- 補充：這裡使用的是三元運算子，格式為： 條件 ? 條件成立時的結果 : 條件不成立時的結果 -->
	<div class="section">
		<h2>5. 條件運算</h2>
		<c:set var="score2" value="75" />
		<p>成績：${score2}</p>
		<!-- 三元運算 -->
		<!-- 補充：「是否及格」使用一層三元運算；「等級」則把多個三元運算串在一起判斷 -->
		<!-- 多層三元運算雖然可以使用，但條件過多時會較難閱讀 -->

		<p>是否及格：<span class="result">${score2 >= 60 ? '及格' : '不及格'}</span></p>
		<p>等級：<span class="result">${score2 >= 90 ? 'A' : score2 >= 80 ? 'B' : score2 >= 70 ? 'C' : 'D'}</span></p>
	</div>

	<!-- 6. empty 運算 -->
	<!-- 補充：empty 用來判斷資料是否為空，回傳結果為 true 或 false -->
	<div class="section">
		<h2>6. empty 運算</h2>
		<c:set var="emptyStr" value="" />
		<c:set var="nullStr" value="${null}" />
		<c:set var="hasValue" value="Hello" />
		<!-- empty 應用 -->
		<!-- 補充：這裡分別測試空字串、null 與有內容的字串。因此可以觀察 empty 在不同資料狀態下的判斷結果 -->
		<!-- 實務補充（老師尚未教到）empty 之後也可用來判斷空集合或空陣列，不只限於字串與 null。 -->
		<p>空字串 empty ''：<span class="result">${empty emptyStr}</span></p>
		<p>null empty null：<span class="result">${empty nullStr}</span></p>
		<p>有值 empty 'Hello'：<span class="result">${empty hasValue}</span></p>
	</div>

	<br>
	<a href="index.jsp">回首頁</a>
</body>
</html>