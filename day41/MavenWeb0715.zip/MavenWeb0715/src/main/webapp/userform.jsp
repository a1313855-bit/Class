<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8"%>
<!-- [修正] JSP page directive：匯入 entity.User 類別，供 Scriptlet 使用。 -->
<%@ page import="entity.User"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Username JSP</title>
</head>
<body>
	<!-- [修正] 以下是 JSP Scriptlet，區塊內撰寫 Java 程式碼。 -->
	<%
	/* [修正] 從 Request 取得 name="name" 的表單參數。 */
	String name = request.getParameter("name");
	
	/* [修正] 從 Request 取得 name="age" 的表單參數。 */
	String age = request.getParameter("age");
	
	/* [修正] 建立 User 物件，並以區域變數 user1 保存其參照。 */
	User user1 = new User();
	
	/* [修正] 透過 setter 設定 user1 的 name 與 age 屬性。 */
	user1.setName(name);
	user1.setAge(Integer.parseInt(age));

	/* [注意] 也可使用建構式，但 age 參數型別為 int，仍需先轉型：
	User user1 = new User(name, Integer.parseInt(age));
	*/

	/* [修正] 將 user1 以屬性名稱 user 存入 page scope，讓同一 JSP 頁面的 EL 可透過 ${user} 取得。 */
	pageContext.setAttribute("user", user1);
	%>
	<!-- [保留並補充] EL 會透過 JavaBean getter 讀取 user 的 name 與 age。 -->
	<h1>
		<!-- [修正] ${user.name} 對應 getName()；${user.age} 對應 getAge()。 -->
		<p>姓名 : ${user.name }</p>
		<p>年齡 : ${user.age }</p>
	</h1>
</body>
</html>