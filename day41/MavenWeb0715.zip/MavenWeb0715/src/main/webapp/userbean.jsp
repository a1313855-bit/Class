<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Create User Bean</title>
</head>
<body>
	
	<!-- id=物件 class = 物件位置 -->
	<jsp:useBean id="userA" class="entity.User"></jsp:useBean>
	<!-- 這裡用Java的感覺寫就像 -->
	<!-- User userA=new User(); -->
	
	<!-- property=變數名稱 name = 使用的物件 value=填入的值 -->	
	<jsp:setProperty property="name" name="userA" value="${param.name}" />
	<!-- 這裡用Java的感覺寫就像 -->
	<!-- userA.setName(value); -->
	
	<!-- property=變數名稱 name = 使用的物件 value=填入的值 -->	
	<jsp:setProperty property="age" name="userA" value="${param.age}" />
	<!-- 這裡用Java的感覺寫就像 -->
	<!-- userA.setAge(value); -->
	<h1>
  	User Name :${userA.name}<br/>
  	User Age : ${userA.age}
	</h1>
</body>
</html>