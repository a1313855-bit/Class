<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Show User</title>
</head>
<body>
	<%
	/* [修正] 以下是 JSP Scriptlet，區塊內撰寫 Java 程式碼。 */
	/* [修正] 檢查 Session 中是否存在名為 user 的屬性；存在則輸出，否則重新導向。 */
	if (session.getAttribute("user") != null) {
		out.println("session attribute user is " + session.getAttribute("user"));
	} else {
		//out.println("session attribute user is not");
		/* [修正] response.sendRedirect("user.html")：請瀏覽器重新請求 user.html。 */
		response.sendRedirect("user.html");
	}
	%>
	<!-- [保留並補充] 以下使用 EL 讀取 Session 範圍中的屬性。 -->
	<!-- [修正] sessionScope.user 取得 Session 中屬性名稱為 user 的值。 -->
	<h2>EL session user is ${sessionScope.user}</h2>
</body>
</html>