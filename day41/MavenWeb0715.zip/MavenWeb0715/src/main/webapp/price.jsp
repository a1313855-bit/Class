<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Price JSP</title>
</head>
<body>
	<h2>
		<!-- [保留並補充] 以下使用 EL（Expression Language）取得及運算表單參數。 -->
		<!-- [修正] 取得本次 Request 中名稱為 price 的表單參數。 -->
		Price : ${param.price }<br />

		<!-- [修正] 取得本次 Request 中名稱為 qty 的表單參數。 -->
		Quantity : ${param.qty }<br />

		<!-- [修正] 使用 EL 將 price 與 qty 轉為數值後相乘，並輸出結果。 -->
		Total : ${param.price * param.qty }
	</h2>
</body>
</html>