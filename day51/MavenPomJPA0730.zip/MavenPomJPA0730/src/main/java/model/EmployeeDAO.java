package model;

import java.util.*;

import config.JpaUtil;
import jakarta.persistence.EntityManager;
import jakarta.persistence.TypedQuery;
public class EmployeeDAO {
	
    public static List<Employee>  getAll(){
    	  EntityManager mgr= JpaUtil.createEntityManager();
    	  TypedQuery<Employee> query =mgr.createQuery("select e from Employee e", Employee.class);
    	  return query.getResultList();
    }
}
