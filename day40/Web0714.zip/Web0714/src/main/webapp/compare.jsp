<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<body>
<h1>a : ${param.va}</h1>
<h1>b : ${param.vb}</h1>
<h1>
<%
   String va=request.getParameter("va");
   String vb=request.getParameter("vb");
   int a=Integer.parseInt(va);
   int b=Integer.parseInt(vb);
   String msg=a>b ? a+">"+b:(a<b? a+"<"+b:a+"=="+b);
   out.println(msg);
%>
${ param.va> param.vb ? "a > b" :( param.va<param.vb ? "a < b" : "a==b" )}
</h1>
</body>
</html>