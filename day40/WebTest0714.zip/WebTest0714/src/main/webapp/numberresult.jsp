<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>數字比大小結果</title>
</head>
<body>
	<h1>數字比大小結果</h1>
	<div class="numberresult">
		<p>
			<span class="label">數字大小：</span> 
			${param.number1 } 
			${param.number1 > param.number2 ? '>' : (param.number1 < param.number2 ? '<' :  '=')}
			${param.number2 }
		</p>
	</div>
	<p>
		<a href="number.html">返回表單</a>
	</p>	
</body>
</html>