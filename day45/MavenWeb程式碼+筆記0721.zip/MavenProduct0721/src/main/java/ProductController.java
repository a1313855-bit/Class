
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import model.Product;
import model.ProductDao;
import model.ProductDaoImpl;

import java.io.IOException;
import java.math.BigDecimal;

/**
 * Servlet implementation class ProductController
 */
@WebServlet("/products/*")
public class ProductController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	private ProductDao productDao = new ProductDaoImpl();

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public ProductController() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		String path = request.getPathInfo(); // 取得 /product 之後的路徑，如 /list, /edit
		// response.getWriter().append("Served at: ").append(path);
		switch (path) {
		case "/list":
			listProduct(request, response);
			break;
		default:
			response.getWriter().append("Invalid Path : ").append(path);
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		// 取得 /product 之後的路徑，如 /list, /edit
		String path = request.getPathInfo(); 
		// response.getWriter().append("Served at: ").append(path);
		switch (path) {
		case "/add":
			addProduct(request, response);
			break;
		default:
			response.getWriter().append("Invalid Path : ").append(path);
		}
	}

	private void addProduct(HttpServletRequest request, HttpServletResponse response) {
		String name = request.getParameter("name");
		String price = request.getParameter("price");
		String stock = request.getParameter("stock");
		String category = request.getParameter("category");
		Product p = new Product(name, new BigDecimal(price), Integer.parseInt(stock), category);
		productDao.insert(p);
		try {
			response.getWriter().append("insert completed");
		} catch (Exception ex) {
		}
	}

	private void listProduct(HttpServletRequest request, HttpServletResponse response) {

	}

}
