package model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.List;
import java.util.Optional;

public class ProductDaoImpl implements ProductDao {

	@Override
	public void insert(Product product) {
		String sql = "INSERT INTO mydb.products (name, price, stock, category) VALUES (?, ?, ?, ?)";
		try (Connection conn = DBUtil.getConnection();
				/* Statement.RETURN_GENERATED_KEYS 先請 JDBC 幫你保留 MySQL 自動填入id的值 */
				PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
			ps.setString(1, product.getName());
			/* Product 物件 price 類型是 BigDecimal 把輸入進去的資料先轉成 String 後再轉成 Double */
			ps.setDouble(2, Double.parseDouble(product.getPrice().toString()));
			ps.setInt(3, product.getStock());
			ps.setString(4, product.getCategory());
			ps.executeUpdate(); 
			/* ResultSet rs = ps.getGeneratedKeys() 把 Statement.RETURN_GENERATED_KEYS 保留的主鍵讀出來 */
			try (ResultSet rs = ps.getGeneratedKeys()) {
				if (rs.next()) {
					product.setId(rs.getInt(1)); // 將自增 ID 回寫到物件
				}
			}
			System.out.println("insert product :" + product);
		} catch (Exception ex) {
			System.out.println("Insert Product Error " + ex.getMessage());
		}

	}

	@Override
	public Optional<Product> findById(int id) {
		// TODO Auto-generated method stub
		return Optional.empty();
	}

	@Override
	public List<Product> findAll() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Product> searchByName(String name) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Product> findByCategory(String category) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void update(Product product) {
		// TODO Auto-generated method stub

	}

	@Override
	public void delete(int id) {
		// TODO Auto-generated method stub

	}

	@Override
	public long count() {
		// TODO Auto-generated method stub
		return 0;
	}

}
