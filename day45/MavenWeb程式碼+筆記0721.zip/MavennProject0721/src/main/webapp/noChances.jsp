<%@page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" errorPage="errorHandler.jsp"%>
<!DOCTYPE html>
<html lang="zh-TW">
<head>
    <meta charset="UTF-8">
    <title>遊戲結束</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 50px; text-align: center; }
        .failure { color: #FF6B6B; font-size: 20px; }
        .btn { padding: 10px 20px; background-color: #FFA07A; color: white; text-decoration: none; border-radius: 5px; }
    </style>
</head>
<body>
    <div class="failure">
        <h1>😔 很遺憾...</h1>
        <p>您已經沒有猜測機會了！</p>
        <p>不過沒關係，再接再厲！</p>
    </div>
    <br/>
    <a href="guess.html" class="btn">開始新遊戲</a>
</body>
</html>