package model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class ProductdbDao {
	List<Product> data=new ArrayList<>();	
	Connection getDb() {
		String url = "jdbc:mysql://locathost:3306/products";
		String user = "root";
		String password = "1234";
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection conn = DriverManager.getConnection(url, user, password);
			return conn;
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			System.out.println("no connection");
		} catch (SQLException e) {
			System.out.println("no driver");
		}
		return null;
	}

	public List<Product> getAll() {
		Connection conn = getDb();
		String sql = "select * from demo.products";
		try {
			Statement st = conn.createStatement();
			ResultSet rs = st.executeQuery(sql);
			while (rs.next()) {
				String id = rs.getString("pid");
				String name = rs.getString("name");
				double p = rs.getDouble("price");
				Product pt1 = new Product(id, name, p);
				data.add(pt1);
			}
			conn.close();
			return data;
		} catch (Exception ex) {
			if (conn != null)
				try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			System.out.println("getAll error " + ex.getMessage());
			return new ArrayList<Product>();
		}
	}

	public Optional<Product> find(String id) {
		return null;
	}

	public Optional<Product> findByName(String name) {
		return null;
	}

	public boolean addProduct(Product p) {
		return false;
	}

	public Product updateById(String id, Product updateObj) {
		return null;

	}

	public Product deleteById(String id) {
		return null;

	}
}