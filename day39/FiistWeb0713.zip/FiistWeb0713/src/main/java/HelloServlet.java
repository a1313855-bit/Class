import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.logging.Logger;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet(urlPatterns= {"/hello","/hi"})
public class HelloServlet extends HttpServlet {
	private static final Logger logger = Logger.getLogger(HelloServlet.class.getName());
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//super.doGet(req, resp);
		logger.info("收到 GET 請求：" + req.getRequestURI());
		
		LocalDateTime now = LocalDateTime.now();
	     DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
	     String currentTime = now.format(formatter);
		resp.getWriter().append(currentTime);
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//super.doPost(req, resp);
		logger.info("收到 POST 請求：" + req.getRequestURI());
		req.setCharacterEncoding("utf-8");
		String n=req.getParameter("username");
		System.out.println("input name is "+n);
		resp.setContentType("text/html;charset=UTF-8");
		resp.setCharacterEncoding("utf-8");
		resp.getWriter().append("<h1>Post User Name is "+n+"</h1>");
	}
  
}
