package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootEmployee0812Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootEmployee0812Application.class, args);
	}

}
