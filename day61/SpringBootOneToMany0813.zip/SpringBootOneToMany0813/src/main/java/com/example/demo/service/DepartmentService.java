package com.example.demo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.model.Department;
import com.example.demo.repository.DepartmentRepository;

@Service
public class DepartmentService {
	@Autowired
	DepartmentRepository repo;

	// 查詢所有部門（含員工，已透過 JOIN FETCH 避免 N+1）
	public List<Department> findAll() {
		return repo.findAllWithEmployees();
	}

	public Optional<Department> findById(Integer id) {
		return repo.findById(id);
	}
	
	public Optional<Department> findByName(String name){
		return repo.findByName(name);
	}

	public Department create(Department department) {
		return repo.save(department);
	}
	
	public Department update(Integer id,Department updated) {
		Optional<Department> found = repo.findById(id);
		if(found.isPresent()) {
			Department data = found.get();
			data.setName(updated.getName());
			repo.save(data);
			return data;
		}
		return null;
	}

	public boolean delete(Integer id) {
		if (repo.existsById(id)) {
			repo.deleteById(id);
			return true;
		} else {
			return false;
		}
	}
}
