package com.example.demo.model;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonManagedReference;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import lombok.Data;

@Data
@Entity
@Table(name = "categories")
public class Category {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;

	@Column(nullable = false, unique = true) // 類別名稱不可重複
	private String name;

	// @OneToMany：一個 Category 對應多個 Product
	// mappedBy = "category" → 指向 Product.java 中的屬性名稱（不是欄位名）
	// fetch = LAZY → 需要時才查詢商品（預設 LAZY，但明確標示更清楚）	
	@OneToMany(mappedBy = "category",
			fetch = FetchType.LAZY,
			cascade = CascadeType.PERSIST,
			targetEntity = Product.class)
	// @JsonManagedReference → 「管理端」，序列化時正常輸出 products 陣列
	// 搭配 Product 端的 @JsonBackReference，共同切斷 JSON 無限遞迴
	@JsonManagedReference
	private List<Product> products = new ArrayList<>();

	public Category() {
	}

	public Category(String name) {
		this.name = name;
	}

	// ⚠️ 若有 toString()，切勿直接印出 products（會觸發 LAZY 載入並可能遞迴）
	@Override
	public String toString() {
		return "Category{id=" + id + ", name='" + name + "'}";
	}
}
