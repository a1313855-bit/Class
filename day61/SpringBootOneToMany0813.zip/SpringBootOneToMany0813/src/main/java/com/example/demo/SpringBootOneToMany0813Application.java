package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootOneToMany0813Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootOneToMany0813Application.class, args);
	}

}
