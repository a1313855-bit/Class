package com.example.demo.config;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import com.example.demo.model.Category;
import com.example.demo.model.Department;
import com.example.demo.model.Employee;
import com.example.demo.model.Product;
import com.example.demo.repository.CategoryRepository;
import com.example.demo.repository.DepartmentRepository;

@Component
public class DataInitConfig implements CommandLineRunner {
	@Autowired
	DepartmentRepository repo;
	@Autowired
	CategoryRepository repo2;
    
	@Override
	public void run(String... args) throws Exception {
		if(repo.count()==0) {
			Department d1 = new Department("MIS");
			List<Employee> e1 = List.of(
					new Employee("Mr.A","aaa@test.com",d1,50000.0),
					new Employee("Mr.B","bbb@test.com",d1,52000.0));
			d1.setEmployees(e1);
			Department d2 = new Department("Finance");
			List<Employee> e2 = List.of(
					new Employee("Mr.C","ccc@test.com",d2,60000.0),
					new Employee("Mr.D","ddd@test.com",d2,62000.0));
			d2.setEmployees(e2);
			repo.save(d1);
			repo.save(d2);
			System.out.println("以建立初始資料");
		}
		
		if(repo2.count()==0) {
			Category c1 = new Category("A");
			List<Product> p1 = List.of(
					new Product("A001",10000.0,10,c1),
					new Product("A002",12000.0,12,c1));
			c1.setProducts(p1);
			Category c2 = new Category("B");
			List<Product> p2 = List.of(
					new Product("B001",20000.0,20,c2),
					new Product("B002",22000.0,22,c2));
			c2.setProducts(p2);
			repo2.save(c1);
			repo2.save(c2);
		}
	}
}
