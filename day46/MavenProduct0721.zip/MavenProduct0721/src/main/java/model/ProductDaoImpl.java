package model;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class ProductDaoImpl implements ProductDao {
	/* ┌───────────────────────────────────────────────┐ */
	/* │ ===================== C ===================== │ */
	/* └───────────────────────────────────────────────┘ */
	@Override
	public void insert(Product product) {
		/* SQL語法 */
		String sql = "INSERT INTO mydb.products (name, price, stock, category) VALUES (?, ?, ?, ?)";
		/* 取得連線 */
		try (Connection conn = DBUtil.getConnection();
				/* Statement.RETURN_GENERATED_KEYS 先請 JDBC 幫你保留 MySQL 自動填入id的值 */
				PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
			ps.setString(1, product.getName());
			/* Product 物件 price 類型是 BigDecimal 把輸入進去的資料先轉成 String 後再轉成 Double */
			ps.setDouble(2, Double.parseDouble(product.getPrice().toString()));
			ps.setInt(3, product.getStock());
			ps.setString(4, product.getCategory());
			/* 更新資料庫 */
			ps.executeUpdate();
			/* ResultSet rs = ps.getGeneratedKeys() */
			/* 把 Statement.RETURN_GENERATED_KEYS 保留的主鍵讀出來 */
			try (ResultSet rs = ps.getGeneratedKeys()) {
				/* 確認 ResultSet 裡有的資料 if(讀取單筆) */
				if (rs.next()) {
					/* 讀取 ResultSet 第一筆資料並放入 id */
					/* 解釋:rs.getInt(1) 可以把放進 ResultSet 資料想像成一個表格 */
					/* ┌────────────────┐ */
					/* │id │name │..... │ */
					/* │────────────────│ */
					/* │ 1 │Apple│..... │ */
					/* └────────────────┘ */
					/* 所以 getInt(1) 就是指取得 ResultSet 裡的第一筆資料 */
					/* 補充:SQL 表是從 1 開始 vs Java 陣列是從 0 */
					product.setId(rs.getInt(1)); // 將自增 ID 回寫到物件
				}
			}
			/* 成功:Console 印出 "insert product" */
			System.out.println("insert product :" + product);
		} catch (Exception ex) {
			/* 失敗:Console 印出 "Insert Product Error" */
			System.out.println("Insert Product Error " + ex.getMessage());
		}

	}

	/* ┌───────────────────────────────────────────────┐ */
	/* │ ================== R (單筆) ================== │ */
	/* └───────────────────────────────────────────────┘ */
	@Override
	public Optional<Product> findById(int id) {
		String sql = "SELECT * FROM mydb.products WHERE id = ? AND deleted = 0";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return Optional.of(mapRow(rs));
                }
            }
        } catch (SQLException e) {
            throw new RuntimeException("查詢商品失敗, id=" + id, e);
        }
        return Optional.empty();
	}

	/* ┌───────────────────────────────────────────────┐ */
	/* │ ================== R (多筆) ================== │ */
	/* └───────────────────────────────────────────────┘ */
	@Override
	public List<Product> findAll() {
		/* SQL語法 */
		String sql = "SELECT * FROM mydb.products WHERE deleted = 0";
		List<Product> list = new ArrayList<>();
		/* 取得連線 */
		try (Connection conn = DBUtil.getConnection();
				/* SQL語法中沒有問號不用填入值 Statement st = conn.createStatement() */
				Statement st = conn.createStatement()) {
			/* SQL語法取得的資料 放進 ResultSet */
			ResultSet rs = st.executeQuery(sql);
			/* 確認 ResultSet 裡有的資料 while(讀取多筆) */
			while (rs.next()) {
				/* 把多筆資料放進 List<Product> */
				list.add(mapRow(rs));
			}
			/* 成功:回傳 List<Product> */
			return list;
		} catch (Exception ex) {
			/* 失敗:Console 印出 "findAll Products Error" */
			System.out.println("findAll Products Error " + ex.getMessage());
		}
		/* 失敗:回傳空的ArrayList */
		return new ArrayList();
	}

	/* ┌───────────────────────────────────────────────┐ */
	/* │ ========= findById 和 findAll 使用方法 ========= │ */
	/* └───────────────────────────────────────────────┘ */
	private Product mapRow(ResultSet rs) throws SQLException {
		/* 新增一個空的 Product 物件 */
		Product product = new Product();
		/* ResultSet 物件裡的值放到 Product 物件 */
		product.setId(rs.getInt("id"));
		product.setName(rs.getString("name"));
		/* Product 物件 Price 類型為 BigDecimal rs.getDouble("price") 轉型為 BigDecimal */
		product.setPrice(new BigDecimal(rs.getDouble("price")));
		product.setStock(rs.getInt("stock"));
		product.setCategory(rs.getString("category"));
		/* 回傳放入值的 Product 物件 */
		return product;
	}

	/* ┌───────────────────────────────────────────────┐ */
	/* │ ================== R (模糊) ================== │ */
	/* └───────────────────────────────────────────────┘ */
	@Override
	public List<Product> searchByName(String name) {
		// TODO Auto-generated method stub
		return null;
	}

	/* ┌───────────────────────────────────────────────┐ */
	/* │ ================== R (類別) ================== │ */
	/* └───────────────────────────────────────────────┘ */
	@Override
	public List<Product> findByCategory(String category) {
		// TODO Auto-generated method stub
		return null;
	}

	/* ┌───────────────────────────────────────────────┐ */
	/* │ ===================== U ===================== │ */
	/* └───────────────────────────────────────────────┘ */
	@Override
	public void update(Product product) {
		/* SQL語法 */
		String sql = "UPDATE mydb.products SET name = ?, price = ?, stock = ?, category = ? WHERE id = ? AND deleted = 0";
		/* 取得連線 */
		try (Connection conn = DBUtil.getConnection();
				/* SQL語法中有問號 PreparedStatement st = conn.prepareStatement() */
				PreparedStatement ps = conn.prepareStatement(sql)) {
			ps.setString(1, product.getName());
			/* Product 物件 price 類型是 BigDecimal 把輸入進去的資料先轉成 String 後再轉成 Double */
			ps.setDouble(2, Double.parseDouble(product.getPrice().toString()));
			ps.setInt(3, product.getStock());
			ps.setString(4, product.getCategory());
			ps.setInt(5, product.getId());
			/* 更新資料庫 */
			ps.executeUpdate();
			/* 成功:Console 印出 "updated product" */
			System.out.println("updated product" + product);
		} catch (Exception ex) {
			/* 失敗:Console 印出 "update Product Error" */
			System.out.println("update Product Error " + ex.getMessage());
		}
	}

	/* ┌───────────────────────────────────────────────┐ */
	/* │ ================== D (軟刪除) ================= │ */
	/* └───────────────────────────────────────────────┘ */
	@Override
	public void delete(int id) {
		/* SQL語法 */
		String sql = "UPDATE mydb.products SET deleted = 1 WHERE id = ?";
		/* 取得連線 */
		try (Connection conn = DBUtil.getConnection();
				/* SQL語法中有問號 PreparedStatement st = conn.prepareStatement() */
				PreparedStatement ps = conn.prepareStatement(sql)) {
			ps.setInt(1, id);
			/* 更新資料庫 */
			ps.executeUpdate();
			/* 成功:Console 印出 "delete product id" */
			System.out.println("delete product id :" + id);
		} catch (Exception ex) {
			/* 失敗:Console 印出 "delete Product Error" */
			System.out.println("delete Product Error :" + ex.getMessage());
		}
	}

	/* ┌───────────────────────────────────────────────┐ */
	/* │ =================== 總筆數 ==================== │ */
	/* └───────────────────────────────────────────────┘ */
	@Override
	public long count() {
		// TODO Auto-generated method stub
		return 0;
	}

}
