
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import model.Product;
import model.ProductDao;
import model.ProductDaoImpl;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

/**
 * Servlet implementation class ProductController
 */
@WebServlet("/products/*")
public class ProductController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	private ProductDao productDao = new ProductDaoImpl();

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public ProductController() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// response.getWriter().append("Served at: ").append(path);

		// 取得 /product 之後的路徑，如 /list, /edit
		String path = request.getPathInfo();
		/* 根據進入的網址(path) 來決定使用的方法 */
		switch (path) {
		/* 進入 "/list" 顯示所有的商品資料 */
		case "/list":
			/* List<Product> 物件 裝載目前搜尋到的所有商品資料 */
			List<Product> data = listProduct(request, response);
			/* 回應顯示 List<Product> 物件 裝載資料顯示為字串 */
			// response.getWriter().append(data.toString());
			request.setAttribute("products", data);
			request.getRequestDispatcher("../productlist.jsp").forward(request, response);
			break;
		case "/delete":
			deletePorduct(request, response);	
			request.setAttribute("products", listProduct(request,response));			
			request.getRequestDispatcher("../productlist.jsp").forward(request, response);
			break;
		case "/add":
			request.getRequestDispatcher("../productform.jsp").forward(request, response);
			break;
		case "/edit":
			showEditForm(request,response);
			break;
		/* 進入以上以外的網址 顯示 "Invalid Path : 進入的網址 */
		default:
			response.getWriter().append("Invalid Path : ").append(path);
		}
	}

	/* ┌───────────────────────────────────────────────┐ */
	/* │ ========== 導入 ProductDao findAll() ========= │ */
	/* └───────────────────────────────────────────────┘ */
	private List<Product> listProduct(HttpServletRequest request, HttpServletResponse response) {
		/* 新增一個空的 List<Product> 物件導入 ProductDao findAll() 獲取所有資料 */
		List<Product> list = productDao.findAll();
		/* 回傳裝有資料的 List<Product> 物件 */
		return list;
	}

	/* ┌───────────────────────────────────────────────┐ */
	/* │ ======= 導入 ProductDao delete(int id) ======= │ */
	/* └───────────────────────────────────────────────┘ */
	private void deletePorduct(HttpServletRequest request, HttpServletResponse response) {
		/* 從對應表單上 變數 取得其值 */
		String id = request.getParameter("id");
		/* 使用 ProductDao 物件 delete(int id) */
		/* 注意:這裡要轉型 Integer 因為 Product 物件中的 id 資料類型是 int */
		productDao.delete(Integer.parseInt(id));
		/* 新增一個空的 List<Product> 物件導入 ProductDao findAll() 獲取所有資料 */
		/* 原因:確認軟刪除完成後的資料 */
		List<Product> data = productDao.findAll();
		try {
			/* 成功:回應顯示 List<Product> 物件 裝載資料顯示為字串 */
			response.getWriter().append(data.toString());
		} catch (Exception ex) {
		}
	}
	
	/* ┌───────────────────────────────────────────────┐ */
	/* │ ====== 導入 ProductDao findById(int id) ====== │ */
	/* └───────────────────────────────────────────────┘ */
	void showEditForm(HttpServletRequest request, HttpServletResponse response) {
		String id=request.getParameter("id");
		Optional<Product> opt= productDao.findById(Integer.parseInt(id));
		if(opt.isPresent()) {
			Product p=opt.get();
			try {
			  request.setAttribute("product", p);
			  request.getRequestDispatcher("../productedit.jsp").forward(request, response);
			  
			}catch(Exception ex) {}
		}else {
			try {
			  response.getWriter().append(id+" No Data Found");
			}catch(Exception ex) {}
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// response.getWriter().append("Served at: ").append(path);

		// 取得 /product 之後的路徑，如 /list, /edit
		String path = request.getPathInfo();
		/* 根據進入的網址(path) 來決定使用的方法 */
		switch (path) {
		/* 進入 "/add" 新增產品資料 */
		case "/add":
			addProduct(request, response);
			List<Product> data = listProduct(request, response);
			request.setAttribute("products", data);
			request.getRequestDispatcher("../productlist.jsp").forward(request, response);
			break;
		/* 進入 "/update" 修改產品資料 */
		case "/update":
			updateProduct(request, response);
			request.setAttribute("products", listProduct(request, response));
			request.getRequestDispatcher("../productlist.jsp").forward(request, response);
			break;
		/* 進入以上以外的網址 顯示 "Invalid Path : 進入的網址 */
		default:
			response.getWriter().append("Invalid Path : ").append(path);
		}
	}

	/* ┌───────────────────────────────────────────────┐ */
	/* │ === 導入 ProductDao insert(Product product) == │ */
	/* └───────────────────────────────────────────────┘ */
	private void addProduct(HttpServletRequest request, HttpServletResponse response) {
		/* 從對應表單上 變數 取得其值 */
		String name = request.getParameter("name");
		String price = request.getParameter("price");
		String stock = request.getParameter("stock");
		String category = request.getParameter("category");
		/* 新增空的 Product 物件 放入表單資料 */
		/* 注意:新增進 Product 物件的變數必須和 Product 物件的資料類型相同 */
		Product p = new Product(name, new BigDecimal(price), Integer.parseInt(stock), category);
		/* 使用 ProductDao 物件 insert(Product product) */
		productDao.insert(p);
		try {
			/* 成功:回應"insert completed" */
			response.getWriter().append("insert completed");
		} catch (Exception ex) {
		}
	}

	/* ┌───────────────────────────────────────────────┐ */
	/* │ === 導入 ProductDao update(Product product) == │ */
	/* └───────────────────────────────────────────────┘ */
	private void updateProduct(HttpServletRequest request, HttpServletResponse response) {
		/* 從對應表單上 變數 取得其值 */
		String id = request.getParameter("id");
		String name = request.getParameter("name");
		String price = request.getParameter("price");
		String stock = request.getParameter("stock");
		String category = request.getParameter("category");
		/* 新增空的 Product 物件 放入表單資料 */
		/* 注意:新增進 Product 物件的變數必須和 Product 物件的資料類型相同 */
		Product p = new Product(name, new BigDecimal(price), Integer.parseInt(stock), category);
		/* 表單中的 id 變數 轉型 Integer 補充:表單預設輸出 String */
		/* 注意:這裡要轉型 Integer 因為 Product 物件中的 id 資料類型是 int */
		p.setId(Integer.parseInt(id));
		/* 使用 ProductDao 物件 update(Product product) */
		productDao.update(p);
		/* 新增一個空的 List<Product> 物件導入 ProductDao findAll() 獲取所有資料 */
		/* 原因:確認修改完成後的資料 */
		List<Product> data = productDao.findAll();
		try {
			/* 成功:回應顯示 List<Product> 物件 裝載資料顯示為字串 */
			response.getWriter().append(data.toString());
		} catch (Exception ex) {
		}
	}
}
