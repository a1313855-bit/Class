package controller;

import java.util.List;
import java.util.Optional;

import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import model.Coffee;
import model.CoffeeDAO;
import model.CoffeeDAOImpl;

@Path("coffees")
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
public class CoffeeController {
	CoffeeDAO dao = new CoffeeDAOImpl();

	@GET
	public Response getAllCoffee() {
		List<Coffee> data = dao.findAll();
		if (data != null && data.size() > 0) {
			return Response.ok(data).build();
		} else {
			return Response.noContent().build();
		}
	}

	@GET
	@Path("/{name}")
	public Response findByName(@PathParam("name") String name) {
		Optional<Coffee> found = dao.findByName(name);
		if (found.isPresent()) {
			return Response.ok(found.get()).build();
		} else {
			return Response.status(Response.Status.NOT_FOUND).build();
		}
	}

	@POST
	public Response saveCoffee(Coffee coffee) {
		Coffee saved = dao.save(coffee);
		if (saved != null) {
			return Response.ok(saved).build();
		} else {
			return Response.noContent().build();
		}
	}
	
	@PUT
	@Path("/{name}")
	public Response updateByName(@PathParam("name") String name,Coffee coffee) {
		coffee.setCofName(name);
		Coffee found=dao.update(coffee);
		if(found!=null) {
			return Response.ok(found).build();
		}else {
			return Response.status(Response.Status.NOT_FOUND).build();
		}
	}
	
	@DELETE
	@Path("/{name}")
	public Response deleteByName(@PathParam("name") String name) {
		try {
			dao.deleteByName(name);
			return Response.ok("delete success").build();
		}catch(Exception e) {
			System.out.println("delete error "+e.getMessage());
			return Response.status(Response.Status.NOT_FOUND).build();
		}
	}
}
