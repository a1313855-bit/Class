package model;

import java.util.List;
import java.util.Optional;

import config.JpaUtil;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityTransaction;

public class CoffeeDAOImpl implements CoffeeDAO {

	@Override
	public List<Coffee> findAll() {
		EntityManager em = JpaUtil.createEntityManager();
		List<Coffee> data = em.createNamedQuery("Coffee.findAll", Coffee.class).getResultList();
		return data;
	}

	@Override
	public Optional<Coffee> findByName(String name) {
		EntityManager em = JpaUtil.createEntityManager();
		Coffee coffee = em.find(Coffee.class, name);
		return Optional.ofNullable(coffee);
	}

	@Override
	public Coffee save(Coffee coffee) {
		EntityManager em = JpaUtil.createEntityManager();
		EntityTransaction tx = em.getTransaction();
		try {
			tx.begin();
			em.persist(coffee);
			tx.commit();
			return coffee;
		} catch (Exception e) {
			if (tx.isActive())
				tx.rollback();
			throw e;
		} finally {
			em.close();
		}
	}

	@Override
	public Coffee update(Coffee coffee) {
		EntityManager em = JpaUtil.createEntityManager();
		EntityTransaction tx = em.getTransaction();
		try {
			tx.begin();
			Coffee found = em.find(Coffee.class, coffee.getCofName());
			if (found == null) {
				return null;
			} else {
				found.setPrice(coffee.getPrice());
				found.setSales(coffee.getSales());
				found.setSupId(coffee.getSupId());
				found.setTotal(coffee.getTotal());
				Coffee merged = em.merge(found);
				tx.commit();
				return merged;
			}
		} catch (Exception e) {
			if (tx.isActive())
				tx.rollback();
			throw e;
		} finally {
			em.close();
		}
	}

	@Override
	public void deleteByName(String name) {
		EntityManager em = JpaUtil.createEntityManager();
		EntityTransaction tx = em.getTransaction();
		try {
			tx.begin();
			Coffee coffee = em.find(Coffee.class, name);
			if (coffee != null) {
				em.remove(coffee);
			}
			tx.commit();
		} catch (Exception e) {
			if (tx.isActive())
				tx.rollback();
			throw e;
		} finally {
			em.close();
		}
	}

}
