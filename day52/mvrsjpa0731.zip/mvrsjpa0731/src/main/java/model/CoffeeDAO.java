package model;

import java.util.List;
import java.util.Optional;

public interface CoffeeDAO {
	List<Coffee> findAll();
	Optional<Coffee> findByName(String name);
	Coffee save(Coffee coffee);
	Coffee update(Coffee coffee);
	void deleteByName(String name);
}
