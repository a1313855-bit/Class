package com.example.SpringBoot0806_2.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api")
public class HelloWorld {
	@GetMapping
	public String hello() {
		return "Hello Spring Boot 2";
	}
}
