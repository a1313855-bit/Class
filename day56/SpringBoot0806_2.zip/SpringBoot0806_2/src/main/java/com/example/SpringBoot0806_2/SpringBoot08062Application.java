package com.example.SpringBoot0806_2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBoot08062Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringBoot08062Application.class, args);
	}

}
