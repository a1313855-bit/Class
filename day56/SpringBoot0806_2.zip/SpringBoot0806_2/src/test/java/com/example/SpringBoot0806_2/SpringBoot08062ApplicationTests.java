package com.example.SpringBoot0806_2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBoot08062ApplicationTests {

	@Test
	void contextLoads() {
	}

}
