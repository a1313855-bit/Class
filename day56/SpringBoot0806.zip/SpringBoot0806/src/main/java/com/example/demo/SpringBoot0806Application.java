package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBoot0806Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringBoot0806Application.class, args);
	}

}
