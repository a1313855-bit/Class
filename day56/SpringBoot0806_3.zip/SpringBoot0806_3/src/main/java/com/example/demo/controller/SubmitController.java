package com.example.demo.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.User;

@RestController
@RequestMapping("/api/submit")
public class SubmitController {
	@PostMapping("/form")
	public ResponseEntity<User> receiveModel(@ModelAttribute User user) {
		if (user.getName() != null) {
			System.out.println("user:" + user);
			User u1 = new User(user.getName(), user.getEmail(), user.getAge());
			return ResponseEntity.ok(u1);
		} else {
			return ResponseEntity.badRequest().build();
		}
	}

	@PostMapping("/json")
	public ResponseEntity<User> receiveJson(@RequestBody User user) {
		if (user.getName() != null) {
			System.out.println("user:" + user);
			User u1 = new User(user.getName(), user.getEmail(), user.getAge());
			return ResponseEntity.ok(u1);
		} else {
			return ResponseEntity.badRequest().build();
		}
	}
}
