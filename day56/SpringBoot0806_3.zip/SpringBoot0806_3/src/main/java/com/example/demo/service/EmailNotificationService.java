package com.example.demo.service;

import org.springframework.stereotype.Service;

@Service
public class EmailNotificationService implements NotificationService {
	@Override
	public String sandNotification(String message) {
		return "Email : 已發送: " + message;
	}

}
