package com.example.demo.service;

public interface NotificationService {
	String sandNotification(String message);
}
