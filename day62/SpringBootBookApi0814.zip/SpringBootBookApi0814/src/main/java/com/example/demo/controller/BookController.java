package com.example.demo.controller;

import java.net.URI;
import java.util.List;
import java.util.Map;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.dto.BookCreateRequest;
import com.example.demo.dto.BookResponse;
import com.example.demo.dto.BookUpdateRequest;
import com.example.demo.model.Book;
import com.example.demo.service.BookService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/books")
public class BookController {
	final BookService bookService;

	BookController(BookService bookService) {
		this.bookService = bookService;
	}

	// GET /api/books 或 GET /api/books?category=Programming
	@GetMapping
	public List<Book> getAll(@RequestParam(required = false) String category) {
		if (category != null) {
			return bookService.findByCategory(category);
		}
		return bookService.findAll();
	}

	// GET /api/books/{id}
	@GetMapping("/{id}")
	public ResponseEntity<Book> getById(@PathVariable Long id) {
		return bookService.findById(id).map(ResponseEntity::ok).orElse(ResponseEntity.notFound().build());
	}

	@GetMapping("/category_count")
	public ResponseEntity<List<Map<String, Integer>>> countBooksByCategory() {
		return ResponseEntity.ok(bookService.countBooksByCategory());
	}

	// POST /api/books
	@PostMapping
	public ResponseEntity<BookResponse> create(@Valid @RequestBody BookCreateRequest request) {
		// ① @Valid 觸發驗證（@NotBlank、@Pattern、@Positive...）
		// 驗證失敗 → 拋 MethodArgumentNotValidException → GlobalExceptionHandler 處理
		// ② 請求 DTO → Entity 轉換
		Book book = new Book(request.getTitle(), request.getAuthor(), request.getIsbn(), request.getPrice(),
				request.getStock(), request.getCategory());
		// ③ 委派 Service
		Book saved = bookService.create(book);
		// ④ 建立 Location header 指向新資源
		URI location = URI.create("/api/books/" + saved.getId());
		// ⑤ Entity → 回應 DTO，回傳 201 Created
		return ResponseEntity.created(location).body(BookResponse.from(saved));
	}

//	@PostMapping
//	public ResponseEntity<Book> create(@RequestBody Book book) {
//		Book saved = bookService.create(book);
//		URI location = URI.create("/api/books/" + saved.getId());
//		return ResponseEntity.created(location).body(saved);
//	}

	// PUT /api/books/{id}
	@PutMapping("/{id}")
	public ResponseEntity<BookResponse> update(
			@PathVariable Long id, @Valid @RequestBody BookUpdateRequest req) {
		Book updatedData = new Book(req.getTitle(), req.getAuthor(),
				req.getIsbn(), req.getPrice(), req.getStock(), req.getCategory());
		return bookService.update(id, updatedData).map(BookResponse::from).map(ResponseEntity::ok)
				.orElse(ResponseEntity.notFound().build());
	}

//	@PutMapping("/{id}")
//	public ResponseEntity<Book> update(@PathVariable Long id, @RequestBody Book book) {
//		return bookService.update(id, book).map(ResponseEntity::ok)
//		.orElse(ResponseEntity.notFound().build());
//	}

	// DELETE /api/books/{id}
	@DeleteMapping("/{id}")
	public ResponseEntity<Void> delete(@PathVariable Long id) {
		if (bookService.delete(id)) {
			return ResponseEntity.noContent().build();
		}
		return ResponseEntity.notFound().build();
	}

}
