package com.example.demo.dto;

import java.math.BigDecimal;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Positive;
import jakarta.validation.constraints.Size;
import lombok.Data;

@Data
//新增書籍時，客戶端傳入的資料格式（不含 id，因為 id 由資料庫自動產生）
public class BookCreateRequest {
	@NotBlank(message = "書名不得為空")
	@Size(max = 200, message = "書名長度不可超過 200")
	private String title;

	@NotBlank(message = "作者不得為空")
	private String author;

	@NotBlank(message = "ISBN 不得為空")
	@Pattern(regexp = "^[0-9-]{10,17}$", message = "ISBN 格式不正確")
	private String isbn;

	@NotNull(message = "價格不得為空")
	@Positive(message =  "價格必須大於 0")
	private BigDecimal price;

	@NotNull(message = "庫存不得為空")
	@Min(value = 0, message = "庫存不可為負數")
	private Integer stock;

	private String category; // 分類可為空（選填）
}
