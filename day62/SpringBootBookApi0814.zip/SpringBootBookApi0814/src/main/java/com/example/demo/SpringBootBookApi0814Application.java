package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootBookApi0814Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootBookApi0814Application.class, args);
	}

}
