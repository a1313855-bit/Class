package com.example.demo.model;

import java.math.BigDecimal;
import java.time.LocalDateTime;

import com.fasterxml.jackson.annotation.JsonFormat;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.PrePersist;
import jakarta.persistence.Table;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@Entity
@Table(name="books")
public class Book {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	@Column(nullable = false , length = 200)
	private String title;
	
	@Column(nullable = false , length = 100)
	private String author;
	
	@Column(nullable = false , length = 20 , unique = true)
	private String isbn;
	
	@Column(nullable = false , precision = 10 , scale = 2)
	private BigDecimal price;
	
	@Column(nullable = false)
    private Integer stock;

    @Column(length = 50)
    private String category;

    @Column(name = "created_at", updatable = false)
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime createdAt;

    @PrePersist
    protected void onCreate() {
        createdAt = LocalDateTime.now();
    }

	public Book(String title, String author, String isbn,
			BigDecimal price, Integer stock, String category) {
		this.title = title;
		this.author = author;
		this.isbn = isbn;
		this.price = price;
		this.stock = stock;
		this.category = category;
	}
  
}
