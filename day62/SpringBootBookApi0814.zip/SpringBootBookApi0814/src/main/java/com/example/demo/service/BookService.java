package com.example.demo.service;

import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.demo.model.Book;
import com.example.demo.repository.BookRepository;

@Service
public class BookService {

	final BookRepository bookRepository;

	BookService(BookRepository bookRepository) {
		this.bookRepository = bookRepository;
	}

	// readOnly = true：告訴資料庫這是查詢操作，不修改資料
    // 好處：資料庫可最佳化讀取，提升查詢效能
    @Transactional(readOnly = true)
	public List<Book> findAll() {
		return bookRepository.findAll();
	}

	public Optional<Book> findById(Long id) {
		return bookRepository.findById(id);
	}

	@Transactional
    public Book create(Book book) {
        // 業務規則：ISBN 不可重複
        if (bookRepository.existsByIsbn(book.getIsbn())) {
            throw new IllegalArgumentException("ISBN 已存在：" + book.getIsbn());
        }
        Book saved= bookRepository.save(book);
        if (saved.getId()>0) {
            throw new RuntimeException("測試是否儲存BOOK" );
        }
        return saved;
    }

	public Optional<Book> update(Long id, Book updatedBook) {
		return bookRepository.findById(id).map(existing -> {
			existing.setTitle(updatedBook.getTitle());
			existing.setAuthor(updatedBook.getAuthor());
			existing.setIsbn(updatedBook.getIsbn());
			existing.setPrice(updatedBook.getPrice());
			existing.setStock(updatedBook.getStock());
			existing.setCategory(updatedBook.getCategory());
			return bookRepository.save(existing);
		});
	}

	//@Transactional 例外被 try-catch 吃掉，Spring 不知道要 rollback
//	@Transactional
//    public Optional<Book> update(Long id, Book updatedBook) {
//   	Book bk1=bookRepository.findById(id).map(existing -> {
//          existing.setTitle(updatedBook.getTitle());
//          existing.setAuthor(updatedBook.getAuthor());
//          existing.setIsbn(updatedBook.getIsbn());
//          existing.setPrice(updatedBook.getPrice());
//          existing.setStock(updatedBook.getStock());
//          existing.setCategory(updatedBook.getCategory());
//            return existing;
//        }).get();
//    	try {
//    	    bookRepository.save(bk1);
//    	    throw new RuntimeException("測試修改");
//    	    //return Optional.of(bk1);
//    	}catch(Exception ex) {    		
//    		System.out.println("update error "+ex.getMessage());
//    		return Optional.empty();
//    	}
//    }
	
	public boolean delete(Long id) {
		if (!bookRepository.existsById(id)) {
			return false;
		}
		bookRepository.deleteById(id);
		return true;
	}

	public List<Book> findByCategory(String category) {
		return bookRepository.findByCategory(category);
	}

	public List<Book> searchByTitle(String keyword) {
		return bookRepository.findByTitleContaining(keyword);
	}
	
	public List<Map<String,Integer>> countBooksByCategory(){
		// List<Map<String,Integer>>
		List<Object[]> data = bookRepository.countBooksByCategory();
		List<Map<String,Integer>> objects = data.stream()
				.map(object -> Map.of(object[0].toString(),
						Integer.parseInt(object[1].toString()))).toList();
    	return objects;
    }
}
