package com.example.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootBookApi0814ApplicationTests {

	@Test
	void contextLoads() {
	}

}
