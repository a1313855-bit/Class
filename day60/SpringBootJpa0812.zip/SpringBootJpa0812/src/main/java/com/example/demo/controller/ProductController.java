package com.example.demo.controller;

import java.net.URI;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Product;
import com.example.demo.service.ProductService;

@RestController
@RequestMapping("/api/products")
public class ProductController {

	@Autowired
	ProductService dao;

	// ========== GET (查詢所有產品資料) ==========

	@GetMapping
	public ResponseEntity<List<Product>> getAll() {
		List<Product> prodcuts = dao.findAll();
		return ResponseEntity.ok(prodcuts);
	}

	// ========== GET (ID查詢產品資料) 註:接收JSON ==========

	@GetMapping("/{id}")
	public ResponseEntity<Product> findByIdJson(@PathVariable Integer id) {
		//Product product = dao.findById(id).orElse(null);
		// if (product != null) {
		//		return ResponseEntity.ok(product);
		// } else {
		//  	return ResponseEntity.notFound().build();
		// }

		return dao.findById(id)
				.map(ResponseEntity::ok)
				.orElse(ResponseEntity.notFound().build());
	}
	
	// ========== GET (ID查詢產品資料) 註:接收表單 ==========

//	@GetMapping("/{id}")
//	public ResponseEntity<Product> findByIdProduct(@ModelAttribute Long id) {
		//Product product = dao.findById(id).orElse(null);
		// if (product != null) {
		//		return ResponseEntity.ok(product);
		// } else {
		//  	return ResponseEntity.notFound().build();
		// }

//		return dao.findById(id)
//				.map(ResponseEntity::ok)
//				.orElse(ResponseEntity.notFound().build());
//	}
	
	// ========== POST (新增產品資料) ==========

	@PostMapping
	public ResponseEntity<Product> createPrdocut(@RequestBody Product product) {
		Product data = dao.create(product);
		URI location = URI.create("/api/prodcut/" + product.getId());
		return ResponseEntity.created(location).body(data);
	}

	// ========== PUT (ID修改產品資料) ==========

	@PutMapping("/{id}")
	public ResponseEntity<Product> updateProduct(
			@PathVariable Integer id,
			@RequestBody Product product) {
		return dao.update(id, product)
				.map(ResponseEntity::ok)
				.orElse(ResponseEntity.notFound().build());
	}

	// ========== DELETE (ID刪除產品資料) ==========

	@DeleteMapping("/{id}")
	public ResponseEntity<Product> deletePrdouct(@PathVariable Integer id) {
		if (dao.delete(id)) {
			return ResponseEntity.noContent().build();
		}else {
			return ResponseEntity.notFound().build();
		}
	}
}
