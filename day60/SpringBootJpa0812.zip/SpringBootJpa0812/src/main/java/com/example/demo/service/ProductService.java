package com.example.demo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Service;

import com.example.demo.model.Product;
import com.example.demo.repository.ProductRepository;

@Service // 標記為 Spring 元件
public class ProductService implements CommandLineRunner {

	// 建構子注入：@Autowired
	@Autowired
	ProductRepository productRepository;

	// 程式啟動時執行
	@Override
	public void run(String... args) throws Exception {
		if(productRepository.count()==0) {
			productRepository.save(new Product("A001",100.0,10,"A"));
			productRepository.save(new Product("A002",150.0,15,"A"));
			productRepository.save(new Product("B001",1000.0,100,"B"));
		}
	}

	public List<Product> findAll() {
		return productRepository.findAll();
	}

	public Optional<Product> findById(Integer id) {
		return productRepository.findById(id);
	}

	public Product create(Product product) {
		return productRepository.save(product); // id 為 null → INSERT
	}

	public Optional<Product> update(Integer id, Product updated) {
		return productRepository.findById(id).map(existing -> {
			existing.setName(updated.getName());
			existing.setPrice(updated.getPrice());
			existing.setStock(updated.getStock());
			existing.setCategory(updated.getCategory());
			return productRepository.save(existing); // id 有值 → UPDATE
		});
	}

	public boolean delete(Integer id) {
		if (productRepository.existsById(id)) { // 確認是否存在
			productRepository.deleteById(id);
			return true;
		}
		return false;
	}
}
