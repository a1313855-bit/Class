package com.example.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootJpa0812ApplicationTests {

	@Test
	void contextLoads() {
	}

}
