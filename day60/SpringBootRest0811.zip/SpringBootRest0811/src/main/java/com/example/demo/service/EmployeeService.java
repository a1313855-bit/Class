package com.example.demo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Service;

import com.example.demo.model.Employee;
import com.example.demo.repository.EmployeeRepository;

@Service // 標記為服務元件，Spring 會自動管理此類別的實例
public class EmployeeService implements CommandLineRunner {
	// 透過建構子注入（Constructor Injection），這是 Spring 官方推薦的注入方式
	private final EmployeeRepository employeeRepository;

	@Override
	public void run(String... args) throws Exception {
		if (employeeRepository.count() == 0) {
			employeeRepository.save(new Employee("John", "john@demo.com", "admin", 50000.0));
			employeeRepository.save(new Employee("Mary", "mary@demo.com", "personnel", 45000.0));
			employeeRepository.save(new Employee("George", "george@demo.com", "mis", 55000.0));
		}
	}

	public EmployeeService(EmployeeRepository employeeRepository) {
		this.employeeRepository = employeeRepository;
	}

	// 查詢所有員工
	public List<Employee> findAll() {
		return employeeRepository.findAll();
	}

	// 依 id 查詢單筆（回傳 Optional，讓呼叫者自行處理找不到的情況）
	public Optional<Employee> findById(Long id) {
		return employeeRepository.findById(id);
	}

	// 新增員工
	public Employee create(Employee employee) {
		return employeeRepository.save(employee);
	}

	// 修改員工資料（先確認是否存在，再更新）
	public Optional<Employee> update(Long id, Employee updatedEmployee) {
		return employeeRepository.findById(id).map(existing -> {
			existing.setName(updatedEmployee.getName());
			existing.setEmail(updatedEmployee.getEmail());
			existing.setDepartment(updatedEmployee.getDepartment());
			existing.setSalary(updatedEmployee.getSalary());
			return employeeRepository.save(existing); // save 有 id → UPDATE
		});
	}

	// 刪除員工（回傳 boolean 告知呼叫者是否成功）
	public boolean delete(Long id) {
		if (employeeRepository.existsById(id)) {
			employeeRepository.deleteById(id);
			return true;
		}
		return false;
	}
}
