package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootRestC0811Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootRestC0811Application.class, args);
	}

}
