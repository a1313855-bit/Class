package controller;

import java.util.List;

import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import model.DAO;
import model.Office;
import model.OfficeDAO;

@Path("/offices")
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
public class OfficeController {
	DAO<Office, String> dao = new OfficeDAO();

	// ========== Create ==========
	@POST
	public Response saveOffice(Office office) {
		Office data = dao.save(office);
		if (data != null) {
			return Response.ok(data).build();
		} else {
			return Response.status(Response.Status.NOT_FOUND).build();
		}
	}

	// ========== Read ==========
	@GET
	public Response findAll() {
		List<Office> data = dao.findAll();
		if (data != null && data.size() > 0) {
			return Response.ok(data).build();
		} else {
			return Response.status(Response.Status.NO_CONTENT).build();
		}

	}

	@GET
	@Path("/{code}")
	public Response findByKey(@PathParam("code") String code) {
		Office data = dao.findByKey(code);
		if (data != null) {
			return Response.ok(data).build();
		} else {
			return Response.status(Response.Status.NOT_FOUND).build();
		}
	}

	// ========== Update ==========

	@PUT
	@Path("/{code}")
	public Response updateByCode(@PathParam("code") String code, Office office) {
		Office data = dao.updateByKey(code, office);
		if (data != null) {
			return Response.ok(data).build();
		} else {
			return Response.status(Response.Status.NOT_FOUND).build();
		}
	}

	// ========== Delete ==========
}
