package model;

import java.util.List;

public interface DAO<T, K> {
	// Create
	T save(T object);

	// Read
	List<T> findAll();

	T findByKey(K key);

	// Update
	T updateByKey(K key, T updated);

	// Delete
	T deleteByKey(K key);
}
