package model;

import java.util.List;

import config.JpaUtil;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityTransaction;
import jakarta.persistence.TypedQuery;

public class OfficeDAO implements DAO<Office, String> {

	// ========== Create ==========
	@Override
	public Office save(Office object) {
		EntityManager em = JpaUtil.createEntityManager();
		EntityTransaction tx = em.getTransaction();
		object.getEmployees().forEach(e1 -> e1.setOffice(object));
		Office found = em.find(Office.class, object.getOfficeCode());
		try {
			if (found == null) {
				tx.begin();
				em.persist(object);
				tx.commit();
				return object;
			} else {
				return null;
			}
		} catch (Exception e) {
			System.out.println("save office error " + e.getMessage());
			if (tx.isActive())
				tx.rollback();
			throw e;
		} finally {
			em.close();
		}
	}

	// ========== Read ==========
	@Override
	public List<Office> findAll() {
		EntityManager em = JpaUtil.createEntityManager();
		TypedQuery<Office> query = em.createQuery("SELECT o FROM Office o", Office.class);
		return query.getResultList();
	}

	@Override
	public Office findByKey(String key) {
		EntityManager em = JpaUtil.createEntityManager();
		Office found = em.find(Office.class, key);
		try {
			if (found != null) {
				return found;
			} else {
				return null;
			}
		} finally {
			em.close();
		}
	}

	// ========== Update ==========
	@Override
	public Office updateByKey(String key, Office updated) {
		EntityManager em = JpaUtil.createEntityManager();
		EntityTransaction tx = em.getTransaction();
		Office found = em.find(Office.class, key);
		try {
			if (found != null) {
				tx.begin();
				found.setAddressLine1(updated.getAddressLine1());
				found.setAddressLine2(updated.getAddressLine2());
				found.setCity(updated.getCity());
				found.setCountry(updated.getCountry());
				found.setPhone(updated.getPhone());
				found.setPostalCode(updated.getPostalCode());
				found.setState(updated.getState());
				found.setTerritory(updated.getTerritory());
				Office merged = em.merge(found);
				tx.commit();
				return merged;
			} else {
				return null;
			}
		} catch (Exception e) {
			System.out.println("update office error " + e.getMessage());
			if (tx.isActive())
				tx.rollback();
			throw e;
		} finally {
			em.close();
		}
	}

	// ========== Delete ==========
	@Override
	public Office deleteByKey(String key) {
		return null;
	}
}
