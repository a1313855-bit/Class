# Luxe Shopping Platform - Spring Boot 3 Web 版

這份專案已由原本的 Java SE + Swing(WindowBuilder) 改成 Web 架構：

- 前端：HTML + CSS + JavaScript + Bootstrap 5
- 後端：Spring Boot 3 + REST API
- ORM：Spring Data JPA / Hibernate
- 資料庫：MySQL 8.0
- 架構：MVC + DAO Pattern

> 注意：Spring Boot 3 需要 JDK 17 以上，不能使用 JDK 11 執行。

---

## 一、專案架構

```text
luxe-shopping-platform-springboot3
├── pom.xml
├── run_windows.bat
├── src/main/java/com/codebyx/luxeshop
│   ├── LuxeShoppingPlatformApplication.java
│   ├── controller        # REST Controller，負責接收前端請求
│   ├── dao               # DAO 介面
│   │   └── impl          # DAO 實作，使用 EntityManager 操作 JPA
│   ├── dto               # 前後端傳輸資料物件
│   ├── exception         # 例外處理
│   ├── model             # JPA Entity / Model
│   └── service           # 商業邏輯
│       └── impl
└── src/main/resources
    ├── application.properties
    ├── data.sql          # 測試資料
    └── static            # 前端 HTML/CSS/JS/Bootstrap 頁面
        ├── index.html
        └── assets
            ├── css/style.css
            └── js/app.js
```

---

## 二、資料庫設定

本專案的 `application.properties` 預設如下：

```properties
spring.datasource.url=jdbc:mysql://localhost:3306/luxe_shop?createDatabaseIfNotExist=true&useUnicode=true&characterEncoding=utf8&serverTimezone=Asia/Taipei&useSSL=false&allowPublicKeyRetrieval=true
spring.datasource.username=root
spring.datasource.password=1234
```

如果你的 MySQL 密碼不是 `1234`，請修改：

```text
src/main/resources/application.properties
```

專案啟動時會自動建立資料表，並透過 `data.sql` 匯入範例資料。

---

## 三、Eclipse 匯入步驟

1. 開啟 Eclipse IDE for Enterprise Java and Web Developers
2. 選擇 `File -> Import`
3. 選擇 `Maven -> Existing Maven Projects`
4. 選取本專案資料夾：`luxe-shopping-platform-springboot3`
5. 等待 Maven 下載套件
6. 找到主程式：

```text
src/main/java/com/codebyx/luxeshop/LuxeShoppingPlatformApplication.java
```

7. 右鍵 `Run As -> Java Application`

---

## 四、執行方式

### Windows

雙擊：

```text
run_windows.bat
```

或在 Terminal 執行：

```bash
mvn spring-boot:run
```

啟動後打開瀏覽器：

```text
http://localhost:8080
```

---

## 五、測試帳號

### 後台管理員

| 帳號 | 密碼 | 說明 |
|---|---|---|
| admin | admin123 | 系統管理員 |
| staff | staff123 | 客服人員 |

### 會員

| 帳號 | 密碼 | 說明 |
|---|---|---|
| yuro | 1234 | VIP 會員 |
| bochen | 1234 | 一般會員 |
| sihan | 1234 | VIP 會員 |

`zixuan / 1234` 是停權會員，系統會阻擋登入。

---

## 六、已完成功能

- 登入：管理員 / 會員
- Dashboard：會員數、商品數、訂單數、銷售總額
- 會員管理：新增、查詢、修改、停權 / 恢復
- 商品管理：分類、商品 CRUD、上下架、庫存
- 前台購物：商品列表、加入購物車
- 購物車：修改數量、刪除、建立訂單
- 訂單管理：查詢、修改訂單狀態
- 優惠券管理：新增、修改、啟用 / 停用
- 報表分析：商品銷售排行

---

## 七、主要 API

| 功能 | Method | URL |
|---|---|---|
| 登入 | POST | `/api/auth/login` |
| Dashboard | GET | `/api/dashboard` |
| 會員列表 | GET | `/api/members` |
| 新增會員 | POST | `/api/members` |
| 修改會員 | PUT | `/api/members/{id}` |
| 商品列表 | GET | `/api/products` |
| 新增商品 | POST | `/api/products` |
| 修改商品 | PUT | `/api/products/{id}` |
| 購物車查詢 | GET | `/api/cart/{memberId}` |
| 加入購物車 | POST | `/api/cart/{memberId}` |
| 建立訂單 | POST | `/api/orders/checkout` |
| 訂單列表 | GET | `/api/orders` |
| 優惠券列表 | GET | `/api/coupons` |
| 商品銷售排行 | GET | `/api/reports/product-sales` |

---

## 八、教學重點

本專案適合用來教學：

1. 前後端分離概念：HTML/JS 用 fetch 呼叫 Spring Boot REST API
2. Spring Boot 3 專案結構
3. JPA Entity 與資料表對應
4. DAO Pattern：Controller -> Service -> DAO -> EntityManager -> MySQL
5. MVC 分層：畫面、控制器、服務、資料存取、模型
6. MySQL 電商資料表設計
