@echo off
chcp 65001 > nul
echo ========================================
echo Luxe Shopping Platform Spring Boot 3
echo ========================================
echo.
echo 請確認已安裝：
echo 1. JDK 17 以上
echo 2. Maven
echo 3. MySQL 8.0
echo.
echo 啟動中...
mvn spring-boot:run
pause
