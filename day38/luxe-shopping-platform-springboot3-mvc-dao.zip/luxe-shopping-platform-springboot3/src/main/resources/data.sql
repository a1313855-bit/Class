INSERT IGNORE INTO admins(id, username, password, name, role, status, created_at) VALUES
(1, 'admin', 'admin123', 'Admin', 'ADMIN', 'ACTIVE', CURRENT_TIMESTAMP),
(2, 'staff', 'staff123', '客服人員', 'STAFF', 'ACTIVE', CURRENT_TIMESTAMP);

INSERT IGNORE INTO members(id, username, password, name, email, phone, level, status, created_at) VALUES
(1, 'yuro', '1234', '林雨柔', 'yuro.lin@email.com', '0912-345-678', 'VIP', '正常', CURRENT_TIMESTAMP),
(2, 'bochen', '1234', '陳柏諺', 'bochen.chen@email.com', '0933-456-789', '一般會員', '正常', CURRENT_TIMESTAMP),
(3, 'sihan', '1234', '王思涵', 'sihan.wang@email.com', '0908-123-456', 'VIP', '正常', CURRENT_TIMESTAMP),
(4, 'chiahao', '1234', '張家豪', 'chiahao.chang@email.com', '0911-222-333', '一般會員', '正常', CURRENT_TIMESTAMP),
(5, 'zixuan', '1234', '黃子軒', 'zixuan.huang@email.com', '0909-777-888', '停權會員', '停權', CURRENT_TIMESTAMP);

INSERT IGNORE INTO categories(id, name, description, status) VALUES
(1, '居家選物', '木質、香氛、生活用品', '啟用'),
(2, '時尚配件', '包款、皮件、飾品', '啟用'),
(3, '質感課程', '線上課程與顧問服務', '啟用');

INSERT IGNORE INTO products(id, category_id, name, price, stock, status, description, created_at) VALUES
(1, 1, '橡木擴香組', 1680, 32, '上架', '木質調居家香氛', CURRENT_TIMESTAMP),
(2, 1, '石紋托盤', 980, 45, '上架', '餐桌與玄關擺飾', CURRENT_TIMESTAMP),
(3, 2, '金棕皮革卡夾', 1280, 28, '上架', '簡約會員卡夾', CURRENT_TIMESTAMP),
(4, 2, '霧金手鍊', 1880, 18, '上架', '低調金色系飾品', CURRENT_TIMESTAMP),
(5, 3, 'AI 自動化入門課', 5200, 20, '上架', 'n8n 與 AI 報告實作', CURRENT_TIMESTAMP),
(6, 3, 'Java 電商平台實戰', 6800, 15, '上架', 'MVC + DAO + MySQL 完整專案', CURRENT_TIMESTAMP);

INSERT IGNORE INTO cart_items(id, member_id, product_id, quantity, created_at) VALUES
(1, 1, 1, 2, CURRENT_TIMESTAMP),
(2, 1, 3, 1, CURRENT_TIMESTAMP),
(3, 2, 5, 1, CURRENT_TIMESTAMP);

INSERT IGNORE INTO orders(id, order_no, member_id, total_amount, payment_method, shipping_method, status, created_at) VALUES
(1, 'OD202607060001', 1, 68900, '信用卡', '宅配', '已完成', '2026-07-01 10:24:00'),
(2, 'OD202607060002', 2, 12450, 'ATM', '超商取貨', '待出貨', '2026-07-02 14:12:00'),
(3, 'OD202607060003', 3, 45780, '信用卡', '宅配', '已出貨', '2026-07-03 09:31:00');

INSERT IGNORE INTO order_items(id, order_id, product_id, product_name, price, quantity, subtotal) VALUES
(1, 1, 6, 'Java 電商平台實戰', 6800, 8, 54400),
(2, 1, 1, '橡木擴香組', 1680, 5, 8400),
(3, 1, 3, '金棕皮革卡夾', 1280, 5, 6400),
(4, 2, 5, 'AI 自動化入門課', 5200, 2, 10400),
(5, 2, 2, '石紋托盤', 980, 2, 1960),
(6, 3, 6, 'Java 電商平台實戰', 6800, 5, 34000),
(7, 3, 4, '霧金手鍊', 1880, 6, 11280);

INSERT IGNORE INTO coupons(id, code, name, discount_amount, min_spend, start_date, end_date, status) VALUES
(1, 'VIP500', 'VIP 會員折扣', 500, 5000, '2026-07-01', '2026-12-31', '啟用'),
(2, 'WOOD200', '木質選物折扣', 200, 2000, '2026-07-01', '2026-08-31', '啟用'),
(3, 'NEW100', '新會員首購折扣', 100, 1000, '2026-07-01', '2026-12-31', '啟用');
