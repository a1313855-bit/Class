const api = '';
let currentUser = null;
let membersCache = [];
let productsCache = [];
let couponsCache = [];

const $ = (id) => document.getElementById(id);
const money = (v) => '$' + Number(v || 0).toLocaleString('zh-TW');

async function request(url, options = {}) {
    const res = await fetch(api + url, {
        headers: { 'Content-Type': 'application/json' },
        ...options
    });
    if (!res.ok) {
        let message = '操作失敗';
        try {
            const data = await res.json();
            message = data.message || message;
        } catch (_) {}
        throw new Error(message);
    }
    if (res.status === 204) return null;
    return res.json();
}

function showMessage(message, type = 'success') {
    const box = $('messageBox');
    box.className = `alert alert-${type}`;
    box.textContent = message;
    box.classList.remove('d-none');
    setTimeout(() => box.classList.add('d-none'), 3500);
}

function escapeHtml(value) {
    return String(value ?? '').replace(/[&<>'"]/g, (c) => ({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]));
}

$('loginType').addEventListener('change', () => {
    if ($('loginType').value === 'member') {
        $('username').value = 'yuro';
        $('password').value = '1234';
    } else {
        $('username').value = 'admin';
        $('password').value = 'admin123';
    }
});

$('loginForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    try {
        currentUser = await request('/api/auth/login', {
            method: 'POST',
            body: JSON.stringify({
                loginType: $('loginType').value,
                username: $('username').value,
                password: $('password').value
            })
        });
        $('loginPage').classList.add('d-none');
        $('appPage').classList.remove('d-none');
        $('loginUser').textContent = `${currentUser.name} / ${currentUser.role}`;
        await bootApp();
    } catch (err) {
        alert(err.message);
    }
});

$('logoutBtn').addEventListener('click', () => location.reload());

document.querySelectorAll('.sidebar .nav-link').forEach(btn => {
    btn.addEventListener('click', async () => {
        document.querySelectorAll('.sidebar .nav-link').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        document.querySelectorAll('.content-section').forEach(s => s.classList.add('d-none'));
        $(btn.dataset.section).classList.remove('d-none');
        $('pageTitle').textContent = btn.textContent;
        await loadSection(btn.dataset.section);
    });
});

async function bootApp() {
    await loadMembers();
    await loadCategories();
    await loadDashboard();
    await loadSection('dashboard');
}

async function loadSection(section) {
    switch(section) {
        case 'dashboard': return loadDashboard();
        case 'members': return loadMembers();
        case 'products': return loadProducts();
        case 'shop': return loadShop();
        case 'cart': return loadCart();
        case 'orders': return loadOrders();
        case 'coupons': return loadCoupons();
        case 'reports': return loadReports();
    }
}

async function loadDashboard() {
    const stats = await request('/api/dashboard');
    $('statsCards').innerHTML = [
        ['會員數', stats.memberCount, '人'],
        ['商品數', stats.productCount, '項'],
        ['訂單數', stats.orderCount, '筆'],
        ['銷售總額', money(stats.salesAmount), 'TWD']
    ].map(([title, value, unit]) => `
        <div class="col-md-3">
            <div class="stat-card">
                <div class="text-muted">${title}</div>
                <div class="value">${value}</div>
                <small>${unit}</small>
            </div>
        </div>`).join('');
}

async function loadMembers() {
    membersCache = await request('/api/members');
    $('memberTable').innerHTML = membersCache.map(m => `
        <tr>
            <td>${m.id}</td><td>${escapeHtml(m.username)}</td><td>${escapeHtml(m.name)}</td>
            <td>${escapeHtml(m.email)}</td><td>${escapeHtml(m.phone)}</td><td>${escapeHtml(m.level)}</td>
            <td><span class="badge ${m.status === '正常' ? 'text-bg-success' : 'text-bg-danger'}">${escapeHtml(m.status)}</span></td>
            <td class="d-flex gap-2">
                <button class="btn btn-sm btn-outline-primary" onclick="editMember(${m.id})">編輯</button>
                <button class="btn btn-sm btn-outline-warning" onclick="toggleMemberStatus(${m.id}, '${m.status === '正常' ? '停權' : '正常'}')">${m.status === '正常' ? '停權' : '恢復'}</button>
            </td>
        </tr>`).join('');
    renderShoppingMemberSelect();
}

$('memberForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    const id = $('memberId').value;
    const payload = {
        username: $('memberUsername').value,
        password: $('memberPassword').value,
        name: $('memberName').value,
        email: $('memberEmail').value,
        phone: $('memberPhone').value,
        level: $('memberLevel').value,
        status: $('memberStatus').value
    };
    try {
        await request(id ? `/api/members/${id}` : '/api/members', { method: id ? 'PUT' : 'POST', body: JSON.stringify(payload) });
        resetMemberForm();
        await loadMembers();
        showMessage('會員資料已儲存');
    } catch (err) { showMessage(err.message, 'danger'); }
});

function editMember(id) {
    const m = membersCache.find(x => x.id === id);
    $('memberId').value = m.id;
    $('memberUsername').value = m.username;
    $('memberUsername').disabled = true;
    $('memberPassword').value = '';
    $('memberPassword').placeholder = '不修改請留空';
    $('memberName').value = m.name || '';
    $('memberEmail').value = m.email || '';
    $('memberPhone').value = m.phone || '';
    $('memberLevel').value = m.level || '一般會員';
    $('memberStatus').value = m.status || '正常';
}

function resetMemberForm() {
    $('memberId').value = '';
    $('memberUsername').disabled = false;
    $('memberUsername').value = '';
    $('memberPassword').value = '';
    $('memberPassword').placeholder = '密碼';
    $('memberName').value = '';
    $('memberEmail').value = '';
    $('memberPhone').value = '';
    $('memberLevel').value = '一般會員';
    $('memberStatus').value = '正常';
}

async function toggleMemberStatus(id, status) {
    try {
        await request(`/api/members/${id}/status`, { method: 'PATCH', body: JSON.stringify({status}) });
        await loadMembers();
        showMessage('會員狀態已更新');
    } catch (err) { showMessage(err.message, 'danger'); }
}

async function loadCategories() {
    const categories = await request('/api/categories');
    $('productCategory').innerHTML = categories.map(c => `<option value="${c.id}">${escapeHtml(c.name)}</option>`).join('');
}

async function loadProducts() {
    await loadCategories();
    productsCache = await request('/api/products');
    $('productTable').innerHTML = productsCache.map(p => `
        <tr>
            <td>${p.id}</td><td>${escapeHtml(p.category?.name)}</td><td>${escapeHtml(p.name)}</td>
            <td>${money(p.price)}</td><td>${p.stock}</td><td><span class="badge ${p.status === '上架' ? 'text-bg-success' : 'text-bg-secondary'}">${p.status}</span></td>
            <td>${escapeHtml(p.description)}</td>
            <td><button class="btn btn-sm btn-outline-primary" onclick="editProduct(${p.id})">編輯</button></td>
        </tr>`).join('');
}

$('productForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    const id = $('productId').value;
    const payload = {
        categoryId: Number($('productCategory').value),
        name: $('productName').value,
        price: Number($('productPrice').value),
        stock: Number($('productStock').value),
        status: $('productStatus').value,
        description: $('productDescription').value
    };
    try {
        await request(id ? `/api/products/${id}` : '/api/products', { method: id ? 'PUT' : 'POST', body: JSON.stringify(payload) });
        resetProductForm();
        await loadProducts();
        showMessage('商品資料已儲存');
    } catch (err) { showMessage(err.message, 'danger'); }
});

function editProduct(id) {
    const p = productsCache.find(x => x.id === id);
    $('productId').value = p.id;
    $('productCategory').value = p.category.id;
    $('productName').value = p.name;
    $('productPrice').value = p.price;
    $('productStock').value = p.stock;
    $('productStatus').value = p.status;
    $('productDescription').value = p.description || '';
}

function resetProductForm() {
    $('productId').value = '';
    $('productName').value = '';
    $('productPrice').value = '';
    $('productStock').value = '';
    $('productStatus').value = '上架';
    $('productDescription').value = '';
}

function renderShoppingMemberSelect() {
    const select = $('shoppingMember');
    if (!select) return;
    select.innerHTML = membersCache.filter(m => m.status === '正常').map(m => `<option value="${m.id}">${escapeHtml(m.name)} / ${escapeHtml(m.username)}</option>`).join('');
    if (currentUser?.loginType === 'member') {
        select.value = currentUser.userId;
        select.disabled = true;
    } else {
        select.disabled = false;
    }
}

function getShoppingMemberId() {
    return currentUser?.loginType === 'member' ? currentUser.userId : Number($('shoppingMember').value || 1);
}

async function loadShop() {
    await loadMembers();
    const products = await request('/api/products/active');
    $('shopProducts').innerHTML = products.map(p => `
        <div class="col-md-4 col-xl-3">
            <div class="product-card">
                <div class="product-cover">${escapeHtml(p.name.substring(0, 2))}</div>
                <div class="p-3">
                    <span class="badge text-bg-light border mb-2">${escapeHtml(p.category?.name)}</span>
                    <h5 class="fw-bold">${escapeHtml(p.name)}</h5>
                    <p class="text-muted small mb-2">${escapeHtml(p.description)}</p>
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <div class="fw-bold text-danger">${money(p.price)}</div>
                            <small class="text-muted">庫存 ${p.stock}</small>
                        </div>
                        <button class="btn btn-gold btn-sm" onclick="addToCart(${p.id})">加入購物車</button>
                    </div>
                </div>
            </div>
        </div>`).join('');
}

async function addToCart(productId) {
    try {
        await request(`/api/cart/${getShoppingMemberId()}`, { method: 'POST', body: JSON.stringify({ productId, quantity: 1 }) });
        showMessage('已加入購物車');
        await loadCart();
    } catch (err) { showMessage(err.message, 'danger'); }
}

async function loadCart() {
    const memberId = getShoppingMemberId();
    const items = await request(`/api/cart/${memberId}`);
    let total = 0;
    $('cartTable').innerHTML = items.map(i => {
        const subtotal = Number(i.product.price) * Number(i.quantity);
        total += subtotal;
        return `<tr>
            <td>${escapeHtml(i.product.name)}</td>
            <td>${money(i.product.price)}</td>
            <td><input type="number" min="1" value="${i.quantity}" class="form-control form-control-sm" style="width:90px" onchange="updateCartQty(${i.id}, this.value)"></td>
            <td>${money(subtotal)}</td>
            <td><button class="btn btn-sm btn-outline-danger" onclick="removeCartItem(${i.id})">刪除</button></td>
        </tr>`;
    }).join('');
    $('cartTotal').textContent = money(total);
}

async function updateCartQty(id, quantity) {
    try {
        await request(`/api/cart/items/${id}`, { method: 'PATCH', body: JSON.stringify({ quantity: Number(quantity) }) });
        await loadCart();
    } catch (err) { showMessage(err.message, 'danger'); }
}

async function removeCartItem(id) {
    try {
        await request(`/api/cart/items/${id}`, { method: 'DELETE' });
        await loadCart();
        showMessage('已刪除購物車項目');
    } catch (err) { showMessage(err.message, 'danger'); }
}

async function checkout() {
    try {
        const order = await request('/api/orders/checkout', {
            method: 'POST',
            body: JSON.stringify({
                memberId: getShoppingMemberId(),
                paymentMethod: $('paymentMethod').value,
                shippingMethod: $('shippingMethod').value
            })
        });
        await loadCart();
        await loadOrders();
        await loadDashboard();
        showMessage(`訂單建立成功：${order.orderNo}`);
    } catch (err) { showMessage(err.message, 'danger'); }
}

async function loadOrders() {
    const url = currentUser?.loginType === 'member' ? `/api/orders/member/${currentUser.userId}` : '/api/orders';
    const orders = await request(url);
    $('orderTable').innerHTML = orders.map(o => `
        <tr>
            <td>${escapeHtml(o.orderNo)}</td><td>${escapeHtml(o.member?.name)}</td><td>${money(o.totalAmount)}</td>
            <td>${escapeHtml(o.paymentMethod)}</td><td>${escapeHtml(o.shippingMethod)}</td>
            <td><span class="badge text-bg-info">${escapeHtml(o.status)}</span></td><td>${escapeHtml(o.createdAt)}</td>
            <td>${currentUser?.loginType === 'admin' ? orderStatusButtons(o.id) : '<span class="text-muted">會員檢視</span>'}</td>
        </tr>`).join('');
}

function orderStatusButtons(id) {
    return `<div class="btn-group btn-group-sm">
        <button class="btn btn-outline-secondary" onclick="changeOrderStatus(${id}, '待出貨')">待出貨</button>
        <button class="btn btn-outline-primary" onclick="changeOrderStatus(${id}, '已出貨')">出貨</button>
        <button class="btn btn-outline-success" onclick="changeOrderStatus(${id}, '已完成')">完成</button>
        <button class="btn btn-outline-danger" onclick="changeOrderStatus(${id}, '取消')">取消</button>
    </div>`;
}

async function changeOrderStatus(id, status) {
    try {
        await request(`/api/orders/${id}/status`, { method: 'PATCH', body: JSON.stringify({ status }) });
        await loadOrders();
        showMessage('訂單狀態已更新');
    } catch (err) { showMessage(err.message, 'danger'); }
}

async function loadCoupons() {
    couponsCache = await request('/api/coupons');
    $('couponTable').innerHTML = couponsCache.map(c => `
        <tr>
            <td>${c.id}</td><td>${escapeHtml(c.code)}</td><td>${escapeHtml(c.name)}</td><td>${money(c.discountAmount)}</td>
            <td>${money(c.minSpend)}</td><td>${escapeHtml(c.startDate)} ~ ${escapeHtml(c.endDate)}</td>
            <td><span class="badge ${c.status === '啟用' ? 'text-bg-success' : 'text-bg-secondary'}">${escapeHtml(c.status)}</span></td>
            <td><button class="btn btn-sm btn-outline-primary" onclick="editCoupon(${c.id})">編輯</button></td>
        </tr>`).join('');
}

$('couponForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    const id = $('couponId').value;
    const payload = {
        code: $('couponCode').value,
        name: $('couponName').value,
        discountAmount: Number($('discountAmount').value),
        minSpend: Number($('minSpend').value),
        startDate: $('startDate').value,
        endDate: $('endDate').value,
        status: $('couponStatus').value
    };
    try {
        await request(id ? `/api/coupons/${id}` : '/api/coupons', { method: id ? 'PUT' : 'POST', body: JSON.stringify(payload) });
        resetCouponForm();
        await loadCoupons();
        showMessage('優惠券已儲存');
    } catch (err) { showMessage(err.message, 'danger'); }
});

function editCoupon(id) {
    const c = couponsCache.find(x => x.id === id);
    $('couponId').value = c.id;
    $('couponCode').value = c.code;
    $('couponName').value = c.name;
    $('discountAmount').value = c.discountAmount;
    $('minSpend').value = c.minSpend;
    $('startDate').value = c.startDate;
    $('endDate').value = c.endDate;
    $('couponStatus').value = c.status;
}

function resetCouponForm() {
    $('couponId').value = '';
    $('couponCode').value = '';
    $('couponName').value = '';
    $('discountAmount').value = '';
    $('minSpend').value = '';
    $('startDate').value = '';
    $('endDate').value = '';
    $('couponStatus').value = '啟用';
}

async function loadReports() {
    const rows = await request('/api/reports/product-sales');
    $('reportTable').innerHTML = rows.map(r => `<tr><td>${escapeHtml(r.productName)}</td><td>${r.quantity}</td><td>${money(r.amount)}</td></tr>`).join('');
}
