package com.codebyx.luxeshop.controller;

import com.codebyx.luxeshop.dto.CouponRequest;
import com.codebyx.luxeshop.model.Coupon;
import com.codebyx.luxeshop.service.CouponService;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/coupons")
@CrossOrigin
public class CouponController {
    private final CouponService couponService;

    public CouponController(CouponService couponService) {
        this.couponService = couponService;
    }

    @GetMapping
    public List<Coupon> findAll() { return couponService.findAll(); }

    @PostMapping
    public Coupon create(@RequestBody CouponRequest request) { return couponService.create(request); }

    @PutMapping("/{id}")
    public Coupon update(@PathVariable Integer id, @RequestBody CouponRequest request) { return couponService.update(id, request); }
}
