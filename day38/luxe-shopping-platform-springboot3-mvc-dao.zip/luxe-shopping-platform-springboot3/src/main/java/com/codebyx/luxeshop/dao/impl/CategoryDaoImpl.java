package com.codebyx.luxeshop.dao.impl;

import com.codebyx.luxeshop.dao.CategoryDao;
import com.codebyx.luxeshop.model.Category;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import org.springframework.stereotype.Repository;
import java.util.List;
import java.util.Optional;

@Repository
public class CategoryDaoImpl implements CategoryDao {
    @PersistenceContext
    private EntityManager em;

    @Override
    public List<Category> findAll() {
        return em.createQuery("select c from Category c order by c.id", Category.class).getResultList();
    }

    @Override
    public Optional<Category> findById(Integer id) {
        return Optional.ofNullable(em.find(Category.class, id));
    }

    @Override
    public Category save(Category category) {
        if (category.getId() == null) {
            em.persist(category);
            return category;
        }
        return em.merge(category);
    }
}
