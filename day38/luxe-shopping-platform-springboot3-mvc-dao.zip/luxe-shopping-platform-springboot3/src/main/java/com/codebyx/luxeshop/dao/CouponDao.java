package com.codebyx.luxeshop.dao;

import com.codebyx.luxeshop.model.Coupon;
import java.util.List;
import java.util.Optional;

public interface CouponDao {
    List<Coupon> findAll();
    Optional<Coupon> findById(Integer id);
    Coupon save(Coupon coupon);
}
