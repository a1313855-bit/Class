package com.codebyx.luxeshop.service;

import com.codebyx.luxeshop.model.CartItem;
import java.util.List;

public interface CartService {
    List<CartItem> findCart(Integer memberId);
    CartItem addItem(Integer memberId, Integer productId, Integer quantity);
    CartItem updateQuantity(Integer cartItemId, Integer quantity);
    void removeItem(Integer cartItemId);
}
