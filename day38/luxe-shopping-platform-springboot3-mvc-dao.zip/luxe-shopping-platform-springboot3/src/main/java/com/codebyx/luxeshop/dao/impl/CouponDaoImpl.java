package com.codebyx.luxeshop.dao.impl;

import com.codebyx.luxeshop.dao.CouponDao;
import com.codebyx.luxeshop.model.Coupon;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import org.springframework.stereotype.Repository;
import java.util.List;
import java.util.Optional;

@Repository
public class CouponDaoImpl implements CouponDao {
    @PersistenceContext
    private EntityManager em;

    @Override
    public List<Coupon> findAll() {
        return em.createQuery("select c from Coupon c order by c.id desc", Coupon.class).getResultList();
    }

    @Override
    public Optional<Coupon> findById(Integer id) {
        return Optional.ofNullable(em.find(Coupon.class, id));
    }

    @Override
    public Coupon save(Coupon coupon) {
        if (coupon.getId() == null) {
            em.persist(coupon);
            return coupon;
        }
        return em.merge(coupon);
    }
}
