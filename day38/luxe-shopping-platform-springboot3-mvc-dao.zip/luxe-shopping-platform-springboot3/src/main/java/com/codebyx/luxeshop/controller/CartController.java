package com.codebyx.luxeshop.controller;

import com.codebyx.luxeshop.dto.CartAddRequest;
import com.codebyx.luxeshop.model.CartItem;
import com.codebyx.luxeshop.service.CartService;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/cart")
@CrossOrigin
public class CartController {
    private final CartService cartService;

    public CartController(CartService cartService) {
        this.cartService = cartService;
    }

    @GetMapping("/{memberId}")
    public List<CartItem> findCart(@PathVariable Integer memberId) { return cartService.findCart(memberId); }

    @PostMapping("/{memberId}")
    public CartItem addItem(@PathVariable Integer memberId, @RequestBody CartAddRequest request) {
        return cartService.addItem(memberId, request.getProductId(), request.getQuantity());
    }

    @PatchMapping("/items/{cartItemId}")
    public CartItem updateQuantity(@PathVariable Integer cartItemId, @RequestBody Map<String, Integer> body) {
        return cartService.updateQuantity(cartItemId, body.get("quantity"));
    }

    @DeleteMapping("/items/{cartItemId}")
    public Map<String, Object> removeItem(@PathVariable Integer cartItemId) {
        cartService.removeItem(cartItemId);
        return Map.of("success", true);
    }
}
