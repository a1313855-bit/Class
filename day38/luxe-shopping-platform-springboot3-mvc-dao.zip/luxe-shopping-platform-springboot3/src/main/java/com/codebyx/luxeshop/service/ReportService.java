package com.codebyx.luxeshop.service;

import com.codebyx.luxeshop.model.DashboardStats;
import com.codebyx.luxeshop.model.ReportRow;
import java.util.List;

public interface ReportService {
    DashboardStats dashboardStats();
    List<ReportRow> productSales();
}
