package com.codebyx.luxeshop.dao;

import com.codebyx.luxeshop.model.Admin;
import java.util.Optional;

public interface AdminDao {
    Optional<Admin> findByUsername(String username);
}
