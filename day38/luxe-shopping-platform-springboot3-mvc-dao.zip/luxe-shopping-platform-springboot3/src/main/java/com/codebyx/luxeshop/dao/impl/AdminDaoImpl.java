package com.codebyx.luxeshop.dao.impl;

import com.codebyx.luxeshop.dao.AdminDao;
import com.codebyx.luxeshop.model.Admin;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import org.springframework.stereotype.Repository;
import java.util.Optional;

@Repository
public class AdminDaoImpl implements AdminDao {
    @PersistenceContext
    private EntityManager em;

    @Override
    public Optional<Admin> findByUsername(String username) {
        return em.createQuery("select a from Admin a where a.username = :username", Admin.class)
                .setParameter("username", username)
                .getResultStream()
                .findFirst();
    }
}
