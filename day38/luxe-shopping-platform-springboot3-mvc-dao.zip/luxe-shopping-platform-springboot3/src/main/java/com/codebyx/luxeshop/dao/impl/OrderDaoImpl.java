package com.codebyx.luxeshop.dao.impl;

import com.codebyx.luxeshop.dao.OrderDao;
import com.codebyx.luxeshop.model.OrderEntity;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import org.springframework.stereotype.Repository;
import java.util.List;
import java.util.Optional;

@Repository
public class OrderDaoImpl implements OrderDao {
    @PersistenceContext
    private EntityManager em;

    @Override
    public List<OrderEntity> findAll() {
        return em.createQuery("select distinct o from OrderEntity o left join fetch o.orderItems order by o.id desc", OrderEntity.class).getResultList();
    }

    @Override
    public List<OrderEntity> findByMemberId(Integer memberId) {
        return em.createQuery("select distinct o from OrderEntity o left join fetch o.orderItems where o.member.id = :memberId order by o.id desc", OrderEntity.class)
                .setParameter("memberId", memberId)
                .getResultList();
    }

    @Override
    public Optional<OrderEntity> findById(Integer id) {
        return Optional.ofNullable(em.find(OrderEntity.class, id));
    }

    @Override
    public OrderEntity save(OrderEntity order) {
        if (order.getId() == null) {
            em.persist(order);
            return order;
        }
        return em.merge(order);
    }

    @Override
    public long count() {
        return em.createQuery("select count(o) from OrderEntity o", Long.class).getSingleResult();
    }
}
