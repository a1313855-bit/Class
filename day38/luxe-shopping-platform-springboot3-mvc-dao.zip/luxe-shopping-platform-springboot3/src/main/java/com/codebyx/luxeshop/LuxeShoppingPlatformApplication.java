package com.codebyx.luxeshop;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LuxeShoppingPlatformApplication {
    public static void main(String[] args) {
        SpringApplication.run(LuxeShoppingPlatformApplication.class, args);
    }
}
