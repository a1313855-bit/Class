package com.codebyx.luxeshop.dao.impl;

import com.codebyx.luxeshop.dao.ProductDao;
import com.codebyx.luxeshop.model.Product;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import org.springframework.stereotype.Repository;
import java.util.List;
import java.util.Optional;

@Repository
public class ProductDaoImpl implements ProductDao {
    @PersistenceContext
    private EntityManager em;

    @Override
    public List<Product> findAll() {
        return em.createQuery("select p from Product p join fetch p.category order by p.id desc", Product.class).getResultList();
    }

    @Override
    public List<Product> findActive() {
        return em.createQuery("select p from Product p join fetch p.category where p.status = '上架' and p.stock > 0 order by p.id desc", Product.class).getResultList();
    }

    @Override
    public Optional<Product> findById(Integer id) {
        return Optional.ofNullable(em.find(Product.class, id));
    }

    @Override
    public Product save(Product product) {
        if (product.getId() == null) {
            em.persist(product);
            return product;
        }
        return em.merge(product);
    }

    @Override
    public long count() {
        return em.createQuery("select count(p) from Product p", Long.class).getSingleResult();
    }
}
