package com.codebyx.luxeshop.dao.impl;

import com.codebyx.luxeshop.dao.ReportDao;
import com.codebyx.luxeshop.model.DashboardStats;
import com.codebyx.luxeshop.model.ReportRow;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import org.springframework.stereotype.Repository;
import java.math.BigDecimal;
import java.util.List;

@Repository
public class ReportDaoImpl implements ReportDao {
    @PersistenceContext
    private EntityManager em;

    @Override
    public DashboardStats dashboardStats() {
        Long members = em.createQuery("select count(m) from Member m", Long.class).getSingleResult();
        Long products = em.createQuery("select count(p) from Product p", Long.class).getSingleResult();
        Long orders = em.createQuery("select count(o) from OrderEntity o", Long.class).getSingleResult();
        BigDecimal sales = em.createQuery("select sum(o.totalAmount) from OrderEntity o", BigDecimal.class).getSingleResult();
        return new DashboardStats(members, products, orders, sales);
    }

    @Override
    public List<ReportRow> productSales() {
        return em.createQuery("""
                select new com.codebyx.luxeshop.model.ReportRow(
                    i.productName,
                    sum(i.quantity),
                    sum(i.subtotal)
                )
                from OrderItem i
                group by i.productName
                order by sum(i.subtotal) desc
                """, ReportRow.class).getResultList();
    }
}
