package com.codebyx.luxeshop.model;

import java.math.BigDecimal;

public class ReportRow {
    private String productName;
    private long quantity;
    private BigDecimal amount;

    public ReportRow(String productName, long quantity, BigDecimal amount) {
        this.productName = productName;
        this.quantity = quantity;
        this.amount = amount == null ? BigDecimal.ZERO : amount;
    }

    public String getProductName() { return productName; }
    public long getQuantity() { return quantity; }
    public BigDecimal getAmount() { return amount; }
}
