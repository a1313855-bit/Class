package com.codebyx.luxeshop.controller;

import com.codebyx.luxeshop.dto.LoginRequest;
import com.codebyx.luxeshop.dto.LoginResponse;
import com.codebyx.luxeshop.service.AuthService;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/auth")
@CrossOrigin
public class AuthController {
    private final AuthService authService;

    public AuthController(AuthService authService) {
        this.authService = authService;
    }

    @PostMapping("/login")
    public LoginResponse login(@RequestBody LoginRequest request) {
        return authService.login(request.getLoginType(), request.getUsername(), request.getPassword());
    }
}
