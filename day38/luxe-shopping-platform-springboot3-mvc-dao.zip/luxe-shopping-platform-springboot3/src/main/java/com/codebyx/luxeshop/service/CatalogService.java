package com.codebyx.luxeshop.service;

import com.codebyx.luxeshop.dto.CategoryRequest;
import com.codebyx.luxeshop.dto.ProductRequest;
import com.codebyx.luxeshop.model.Category;
import com.codebyx.luxeshop.model.Product;
import java.util.List;

public interface CatalogService {
    List<Category> findCategories();
    Category createCategory(CategoryRequest request);
    List<Product> findAllProducts();
    List<Product> findActiveProducts();
    Product createProduct(ProductRequest request);
    Product updateProduct(Integer id, ProductRequest request);
}
