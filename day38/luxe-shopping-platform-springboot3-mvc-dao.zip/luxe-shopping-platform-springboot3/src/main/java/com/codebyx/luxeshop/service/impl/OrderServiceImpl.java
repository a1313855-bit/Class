package com.codebyx.luxeshop.service.impl;

import com.codebyx.luxeshop.dao.CartItemDao;
import com.codebyx.luxeshop.dao.MemberDao;
import com.codebyx.luxeshop.dao.OrderDao;
import com.codebyx.luxeshop.dao.ProductDao;
import com.codebyx.luxeshop.exception.AppException;
import com.codebyx.luxeshop.model.*;
import com.codebyx.luxeshop.service.OrderService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

@Service
@Transactional
public class OrderServiceImpl implements OrderService {
    private final OrderDao orderDao;
    private final CartItemDao cartItemDao;
    private final MemberDao memberDao;
    private final ProductDao productDao;

    public OrderServiceImpl(OrderDao orderDao, CartItemDao cartItemDao, MemberDao memberDao, ProductDao productDao) {
        this.orderDao = orderDao;
        this.cartItemDao = cartItemDao;
        this.memberDao = memberDao;
        this.productDao = productDao;
    }

    @Override
    public OrderEntity checkout(Integer memberId, String paymentMethod, String shippingMethod) {
        Member member = memberDao.findById(memberId).orElseThrow(() -> new AppException("找不到會員"));
        List<CartItem> cartItems = cartItemDao.findByMemberId(memberId);
        if (cartItems.isEmpty()) throw new AppException("購物車是空的，無法建立訂單");

        OrderEntity order = new OrderEntity();
        order.setOrderNo(buildOrderNo());
        order.setMember(member);
        order.setPaymentMethod(paymentMethod == null || paymentMethod.isBlank() ? "信用卡" : paymentMethod);
        order.setShippingMethod(shippingMethod == null || shippingMethod.isBlank() ? "宅配" : shippingMethod);
        order.setStatus("待出貨");

        BigDecimal total = BigDecimal.ZERO;
        for (CartItem cartItem : cartItems) {
            Product product = cartItem.getProduct();
            if (cartItem.getQuantity() > product.getStock()) {
                throw new AppException(product.getName() + " 庫存不足，目前庫存：" + product.getStock());
            }
            BigDecimal subtotal = product.getPrice().multiply(BigDecimal.valueOf(cartItem.getQuantity()));
            OrderItem item = new OrderItem();
            item.setProduct(product);
            item.setProductName(product.getName());
            item.setPrice(product.getPrice());
            item.setQuantity(cartItem.getQuantity());
            item.setSubtotal(subtotal);
            order.addItem(item);
            total = total.add(subtotal);

            product.setStock(product.getStock() - cartItem.getQuantity());
            productDao.save(product);
        }
        order.setTotalAmount(total);
        OrderEntity saved = orderDao.save(order);
        cartItemDao.deleteByMemberId(memberId);
        return saved;
    }

    @Override
    @Transactional(readOnly = true)
    public List<OrderEntity> findAll() { return orderDao.findAll(); }

    @Override
    @Transactional(readOnly = true)
    public List<OrderEntity> findByMemberId(Integer memberId) { return orderDao.findByMemberId(memberId); }

    @Override
    public OrderEntity changeStatus(Integer orderId, String status) {
        OrderEntity order = orderDao.findById(orderId).orElseThrow(() -> new AppException("找不到訂單"));
        order.setStatus(status == null || status.isBlank() ? "待出貨" : status);
        return orderDao.save(order);
    }

    private String buildOrderNo() {
        return "OD" + LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMddHHmmssSSS"));
    }
}
