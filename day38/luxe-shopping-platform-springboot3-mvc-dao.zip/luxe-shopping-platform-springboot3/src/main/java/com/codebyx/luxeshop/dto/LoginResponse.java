package com.codebyx.luxeshop.dto;

public class LoginResponse {
    private String loginType;
    private Integer userId;
    private String username;
    private String name;
    private String role;

    public LoginResponse(String loginType, Integer userId, String username, String name, String role) {
        this.loginType = loginType;
        this.userId = userId;
        this.username = username;
        this.name = name;
        this.role = role;
    }

    public String getLoginType() { return loginType; }
    public Integer getUserId() { return userId; }
    public String getUsername() { return username; }
    public String getName() { return name; }
    public String getRole() { return role; }
}
