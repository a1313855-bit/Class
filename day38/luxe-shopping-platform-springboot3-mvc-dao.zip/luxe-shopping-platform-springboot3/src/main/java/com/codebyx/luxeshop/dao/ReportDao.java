package com.codebyx.luxeshop.dao;

import com.codebyx.luxeshop.model.DashboardStats;
import com.codebyx.luxeshop.model.ReportRow;
import java.util.List;

public interface ReportDao {
    DashboardStats dashboardStats();
    List<ReportRow> productSales();
}
