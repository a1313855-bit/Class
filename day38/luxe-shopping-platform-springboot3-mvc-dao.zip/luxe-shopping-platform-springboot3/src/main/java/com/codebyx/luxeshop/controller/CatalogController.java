package com.codebyx.luxeshop.controller;

import com.codebyx.luxeshop.dto.CategoryRequest;
import com.codebyx.luxeshop.dto.ProductRequest;
import com.codebyx.luxeshop.model.Category;
import com.codebyx.luxeshop.model.Product;
import com.codebyx.luxeshop.service.CatalogService;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@CrossOrigin
public class CatalogController {
    private final CatalogService catalogService;

    public CatalogController(CatalogService catalogService) {
        this.catalogService = catalogService;
    }

    @GetMapping("/api/categories")
    public List<Category> findCategories() { return catalogService.findCategories(); }

    @PostMapping("/api/categories")
    public Category createCategory(@RequestBody CategoryRequest request) { return catalogService.createCategory(request); }

    @GetMapping("/api/products")
    public List<Product> findAllProducts() { return catalogService.findAllProducts(); }

    @GetMapping("/api/products/active")
    public List<Product> findActiveProducts() { return catalogService.findActiveProducts(); }

    @PostMapping("/api/products")
    public Product createProduct(@RequestBody ProductRequest request) { return catalogService.createProduct(request); }

    @PutMapping("/api/products/{id}")
    public Product updateProduct(@PathVariable Integer id, @RequestBody ProductRequest request) { return catalogService.updateProduct(id, request); }
}
