package com.codebyx.luxeshop.service;

import com.codebyx.luxeshop.dto.LoginResponse;

public interface AuthService {
    LoginResponse login(String loginType, String username, String password);
}
