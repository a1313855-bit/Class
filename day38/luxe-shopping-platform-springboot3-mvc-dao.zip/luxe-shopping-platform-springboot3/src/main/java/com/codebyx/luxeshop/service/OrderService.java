package com.codebyx.luxeshop.service;

import com.codebyx.luxeshop.model.OrderEntity;
import java.util.List;

public interface OrderService {
    OrderEntity checkout(Integer memberId, String paymentMethod, String shippingMethod);
    List<OrderEntity> findAll();
    List<OrderEntity> findByMemberId(Integer memberId);
    OrderEntity changeStatus(Integer orderId, String status);
}
