package com.codebyx.luxeshop.dto;

public class OrderStatusRequest {
    private String status;
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
}
