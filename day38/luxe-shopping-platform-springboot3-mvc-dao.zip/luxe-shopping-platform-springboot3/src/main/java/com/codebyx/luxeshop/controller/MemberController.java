package com.codebyx.luxeshop.controller;

import com.codebyx.luxeshop.dto.MemberRequest;
import com.codebyx.luxeshop.model.Member;
import com.codebyx.luxeshop.service.MemberService;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/members")
@CrossOrigin
public class MemberController {
    private final MemberService memberService;

    public MemberController(MemberService memberService) {
        this.memberService = memberService;
    }

    @GetMapping
    public List<Member> findAll() { return memberService.findAll(); }

    @GetMapping("/{id}")
    public Member findById(@PathVariable Integer id) { return memberService.findById(id); }

    @PostMapping
    public Member create(@RequestBody MemberRequest request) { return memberService.create(request); }

    @PutMapping("/{id}")
    public Member update(@PathVariable Integer id, @RequestBody MemberRequest request) { return memberService.update(id, request); }

    @PatchMapping("/{id}/status")
    public Member changeStatus(@PathVariable Integer id, @RequestBody Map<String, String> body) {
        return memberService.changeStatus(id, body.get("status"));
    }
}
