package com.codebyx.luxeshop.service;

import com.codebyx.luxeshop.dto.CouponRequest;
import com.codebyx.luxeshop.model.Coupon;
import java.util.List;

public interface CouponService {
    List<Coupon> findAll();
    Coupon create(CouponRequest request);
    Coupon update(Integer id, CouponRequest request);
}
