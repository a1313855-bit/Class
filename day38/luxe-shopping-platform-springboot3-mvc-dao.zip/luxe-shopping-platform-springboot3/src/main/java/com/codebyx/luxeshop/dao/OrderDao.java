package com.codebyx.luxeshop.dao;

import com.codebyx.luxeshop.model.OrderEntity;
import java.util.List;
import java.util.Optional;

public interface OrderDao {
    List<OrderEntity> findAll();
    List<OrderEntity> findByMemberId(Integer memberId);
    Optional<OrderEntity> findById(Integer id);
    OrderEntity save(OrderEntity order);
    long count();
}
