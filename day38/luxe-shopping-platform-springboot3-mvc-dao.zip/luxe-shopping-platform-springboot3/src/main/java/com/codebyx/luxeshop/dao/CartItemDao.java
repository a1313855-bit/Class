package com.codebyx.luxeshop.dao;

import com.codebyx.luxeshop.model.CartItem;
import java.util.List;
import java.util.Optional;

public interface CartItemDao {
    List<CartItem> findByMemberId(Integer memberId);
    Optional<CartItem> findByMemberIdAndProductId(Integer memberId, Integer productId);
    Optional<CartItem> findById(Integer id);
    CartItem save(CartItem cartItem);
    void delete(CartItem cartItem);
    void deleteByMemberId(Integer memberId);
}
