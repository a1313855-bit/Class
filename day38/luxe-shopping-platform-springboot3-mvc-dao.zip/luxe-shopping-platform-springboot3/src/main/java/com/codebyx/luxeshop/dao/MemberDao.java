package com.codebyx.luxeshop.dao;

import com.codebyx.luxeshop.model.Member;
import java.util.List;
import java.util.Optional;

public interface MemberDao {
    List<Member> findAll();
    Optional<Member> findById(Integer id);
    Optional<Member> findByUsername(String username);
    Member save(Member member);
    long count();
}
