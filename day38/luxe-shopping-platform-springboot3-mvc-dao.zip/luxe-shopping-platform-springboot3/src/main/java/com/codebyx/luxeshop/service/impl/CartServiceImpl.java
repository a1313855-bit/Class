package com.codebyx.luxeshop.service.impl;

import com.codebyx.luxeshop.dao.CartItemDao;
import com.codebyx.luxeshop.dao.MemberDao;
import com.codebyx.luxeshop.dao.ProductDao;
import com.codebyx.luxeshop.exception.AppException;
import com.codebyx.luxeshop.model.CartItem;
import com.codebyx.luxeshop.model.Member;
import com.codebyx.luxeshop.model.Product;
import com.codebyx.luxeshop.service.CartService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;

@Service
@Transactional
public class CartServiceImpl implements CartService {
    private final CartItemDao cartItemDao;
    private final MemberDao memberDao;
    private final ProductDao productDao;

    public CartServiceImpl(CartItemDao cartItemDao, MemberDao memberDao, ProductDao productDao) {
        this.cartItemDao = cartItemDao;
        this.memberDao = memberDao;
        this.productDao = productDao;
    }

    @Override
    @Transactional(readOnly = true)
    public List<CartItem> findCart(Integer memberId) {
        return cartItemDao.findByMemberId(memberId);
    }

    @Override
    public CartItem addItem(Integer memberId, Integer productId, Integer quantity) {
        if (quantity == null || quantity <= 0) throw new AppException("數量必須大於 0");
        Member member = memberDao.findById(memberId).orElseThrow(() -> new AppException("找不到會員"));
        Product product = productDao.findById(productId).orElseThrow(() -> new AppException("找不到商品"));
        if (!"上架".equals(product.getStatus())) throw new AppException("此商品目前未上架");
        CartItem item = cartItemDao.findByMemberIdAndProductId(memberId, productId).orElse(null);
        int newQuantity = quantity;
        if (item == null) {
            item = new CartItem();
            item.setMember(member);
            item.setProduct(product);
        } else {
            newQuantity += item.getQuantity();
        }
        if (newQuantity > product.getStock()) throw new AppException("庫存不足，目前庫存：" + product.getStock());
        item.setQuantity(newQuantity);
        return cartItemDao.save(item);
    }

    @Override
    public CartItem updateQuantity(Integer cartItemId, Integer quantity) {
        if (quantity == null || quantity <= 0) throw new AppException("數量必須大於 0");
        CartItem item = cartItemDao.findById(cartItemId).orElseThrow(() -> new AppException("找不到購物車項目"));
        if (quantity > item.getProduct().getStock()) throw new AppException("庫存不足，目前庫存：" + item.getProduct().getStock());
        item.setQuantity(quantity);
        return cartItemDao.save(item);
    }

    @Override
    public void removeItem(Integer cartItemId) {
        CartItem item = cartItemDao.findById(cartItemId).orElseThrow(() -> new AppException("找不到購物車項目"));
        cartItemDao.delete(item);
    }
}
