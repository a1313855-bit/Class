package com.codebyx.luxeshop.exception;

public class AppException extends RuntimeException {
    public AppException(String message) {
        super(message);
    }
}
