package com.codebyx.luxeshop.service.impl;

import com.codebyx.luxeshop.dao.CouponDao;
import com.codebyx.luxeshop.dto.CouponRequest;
import com.codebyx.luxeshop.exception.AppException;
import com.codebyx.luxeshop.model.Coupon;
import com.codebyx.luxeshop.service.CouponService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

@Service
@Transactional
public class CouponServiceImpl implements CouponService {
    private final CouponDao couponDao;

    public CouponServiceImpl(CouponDao couponDao) {
        this.couponDao = couponDao;
    }

    @Override
    @Transactional(readOnly = true)
    public List<Coupon> findAll() { return couponDao.findAll(); }

    @Override
    public Coupon create(CouponRequest request) {
        Coupon coupon = new Coupon();
        apply(coupon, request);
        return couponDao.save(coupon);
    }

    @Override
    public Coupon update(Integer id, CouponRequest request) {
        Coupon coupon = couponDao.findById(id).orElseThrow(() -> new AppException("找不到優惠券"));
        apply(coupon, request);
        return couponDao.save(coupon);
    }

    private void apply(Coupon coupon, CouponRequest request) {
        if (request.getCode() == null || request.getCode().isBlank()) throw new AppException("優惠券代碼不可空白");
        if (request.getName() == null || request.getName().isBlank()) throw new AppException("優惠券名稱不可空白");
        coupon.setCode(request.getCode());
        coupon.setName(request.getName());
        coupon.setDiscountAmount(request.getDiscountAmount() == null ? BigDecimal.ZERO : request.getDiscountAmount());
        coupon.setMinSpend(request.getMinSpend() == null ? BigDecimal.ZERO : request.getMinSpend());
        coupon.setStartDate(request.getStartDate() == null ? LocalDate.now() : request.getStartDate());
        coupon.setEndDate(request.getEndDate() == null ? LocalDate.now().plusMonths(1) : request.getEndDate());
        coupon.setStatus(request.getStatus() == null || request.getStatus().isBlank() ? "啟用" : request.getStatus());
    }
}
