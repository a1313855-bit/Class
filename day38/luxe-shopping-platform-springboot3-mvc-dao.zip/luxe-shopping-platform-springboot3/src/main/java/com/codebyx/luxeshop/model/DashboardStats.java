package com.codebyx.luxeshop.model;

import java.math.BigDecimal;

public class DashboardStats {
    private long memberCount;
    private long productCount;
    private long orderCount;
    private BigDecimal salesAmount;

    public DashboardStats(long memberCount, long productCount, long orderCount, BigDecimal salesAmount) {
        this.memberCount = memberCount;
        this.productCount = productCount;
        this.orderCount = orderCount;
        this.salesAmount = salesAmount == null ? BigDecimal.ZERO : salesAmount;
    }

    public long getMemberCount() { return memberCount; }
    public long getProductCount() { return productCount; }
    public long getOrderCount() { return orderCount; }
    public BigDecimal getSalesAmount() { return salesAmount; }
}
