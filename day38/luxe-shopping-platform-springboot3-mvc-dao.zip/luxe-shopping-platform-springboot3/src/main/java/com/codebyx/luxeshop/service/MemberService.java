package com.codebyx.luxeshop.service;

import com.codebyx.luxeshop.dto.MemberRequest;
import com.codebyx.luxeshop.model.Member;
import java.util.List;

public interface MemberService {
    List<Member> findAll();
    Member findById(Integer id);
    Member create(MemberRequest request);
    Member update(Integer id, MemberRequest request);
    Member changeStatus(Integer id, String status);
}
