package com.codebyx.luxeshop.dao.impl;

import com.codebyx.luxeshop.dao.MemberDao;
import com.codebyx.luxeshop.model.Member;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import org.springframework.stereotype.Repository;
import java.util.List;
import java.util.Optional;

@Repository
public class MemberDaoImpl implements MemberDao {
    @PersistenceContext
    private EntityManager em;

    @Override
    public List<Member> findAll() {
        return em.createQuery("select m from Member m order by m.id desc", Member.class).getResultList();
    }

    @Override
    public Optional<Member> findById(Integer id) {
        return Optional.ofNullable(em.find(Member.class, id));
    }

    @Override
    public Optional<Member> findByUsername(String username) {
        return em.createQuery("select m from Member m where m.username = :username", Member.class)
                .setParameter("username", username)
                .getResultStream()
                .findFirst();
    }

    @Override
    public Member save(Member member) {
        if (member.getId() == null) {
            em.persist(member);
            return member;
        }
        return em.merge(member);
    }

    @Override
    public long count() {
        return em.createQuery("select count(m) from Member m", Long.class).getSingleResult();
    }
}
