package com.codebyx.luxeshop.controller;

import com.codebyx.luxeshop.model.ReportRow;
import com.codebyx.luxeshop.service.ReportService;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/reports")
@CrossOrigin
public class ReportController {
    private final ReportService reportService;

    public ReportController(ReportService reportService) {
        this.reportService = reportService;
    }

    @GetMapping("/product-sales")
    public List<ReportRow> productSales() { return reportService.productSales(); }
}
