package com.codebyx.luxeshop.service.impl;

import com.codebyx.luxeshop.dao.MemberDao;
import com.codebyx.luxeshop.dto.MemberRequest;
import com.codebyx.luxeshop.exception.AppException;
import com.codebyx.luxeshop.model.Member;
import com.codebyx.luxeshop.service.MemberService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;

@Service
@Transactional
public class MemberServiceImpl implements MemberService {
    private final MemberDao memberDao;

    public MemberServiceImpl(MemberDao memberDao) {
        this.memberDao = memberDao;
    }

    @Override
    @Transactional(readOnly = true)
    public List<Member> findAll() {
        return memberDao.findAll();
    }

    @Override
    @Transactional(readOnly = true)
    public Member findById(Integer id) {
        return memberDao.findById(id).orElseThrow(() -> new AppException("找不到會員"));
    }

    @Override
    public Member create(MemberRequest request) {
        memberDao.findByUsername(request.getUsername()).ifPresent(m -> { throw new AppException("會員帳號已存在"); });
        Member member = new Member();
        apply(member, request, true);
        return memberDao.save(member);
    }

    @Override
    public Member update(Integer id, MemberRequest request) {
        Member member = findById(id);
        apply(member, request, false);
        return memberDao.save(member);
    }

    @Override
    public Member changeStatus(Integer id, String status) {
        Member member = findById(id);
        member.setStatus(status == null || status.isBlank() ? "正常" : status);
        return memberDao.save(member);
    }

    private void apply(Member member, MemberRequest request, boolean create) {
        if (create) {
            if (request.getUsername() == null || request.getUsername().isBlank()) throw new AppException("帳號不可空白");
            if (request.getPassword() == null || request.getPassword().isBlank()) throw new AppException("密碼不可空白");
            member.setUsername(request.getUsername());
            member.setPassword(request.getPassword());
        } else if (request.getPassword() != null && !request.getPassword().isBlank()) {
            member.setPassword(request.getPassword());
        }
        if (request.getName() == null || request.getName().isBlank()) throw new AppException("姓名不可空白");
        member.setName(request.getName());
        member.setEmail(request.getEmail());
        member.setPhone(request.getPhone());
        member.setLevel(request.getLevel() == null || request.getLevel().isBlank() ? "一般會員" : request.getLevel());
        member.setStatus(request.getStatus() == null || request.getStatus().isBlank() ? "正常" : request.getStatus());
    }
}
