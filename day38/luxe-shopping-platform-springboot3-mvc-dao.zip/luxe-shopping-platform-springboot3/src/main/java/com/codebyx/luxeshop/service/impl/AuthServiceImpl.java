package com.codebyx.luxeshop.service.impl;

import com.codebyx.luxeshop.dao.AdminDao;
import com.codebyx.luxeshop.dao.MemberDao;
import com.codebyx.luxeshop.dto.LoginResponse;
import com.codebyx.luxeshop.exception.AppException;
import com.codebyx.luxeshop.model.Admin;
import com.codebyx.luxeshop.model.Member;
import com.codebyx.luxeshop.service.AuthService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional(readOnly = true)
public class AuthServiceImpl implements AuthService {
    private final AdminDao adminDao;
    private final MemberDao memberDao;

    public AuthServiceImpl(AdminDao adminDao, MemberDao memberDao) {
        this.adminDao = adminDao;
        this.memberDao = memberDao;
    }

    @Override
    public LoginResponse login(String loginType, String username, String password) {
        if ("member".equalsIgnoreCase(loginType)) {
            Member member = memberDao.findByUsername(username)
                    .orElseThrow(() -> new AppException("會員帳號或密碼錯誤"));
            if (!member.getPassword().equals(password)) {
                throw new AppException("會員帳號或密碼錯誤");
            }
            if ("停權".equals(member.getStatus())) {
                throw new AppException("此會員已停權，無法登入");
            }
            return new LoginResponse("member", member.getId(), member.getUsername(), member.getName(), member.getLevel());
        }

        Admin admin = adminDao.findByUsername(username)
                .orElseThrow(() -> new AppException("管理員帳號或密碼錯誤"));
        if (!admin.getPassword().equals(password)) {
            throw new AppException("管理員帳號或密碼錯誤");
        }
        if (!"ACTIVE".equalsIgnoreCase(admin.getStatus())) {
            throw new AppException("此管理員帳號已停用");
        }
        return new LoginResponse("admin", admin.getId(), admin.getUsername(), admin.getName(), admin.getRole());
    }
}
