package com.codebyx.luxeshop.controller;

import com.codebyx.luxeshop.dto.CheckoutRequest;
import com.codebyx.luxeshop.dto.OrderStatusRequest;
import com.codebyx.luxeshop.model.OrderEntity;
import com.codebyx.luxeshop.service.OrderService;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/orders")
@CrossOrigin
public class OrderController {
    private final OrderService orderService;

    public OrderController(OrderService orderService) {
        this.orderService = orderService;
    }

    @GetMapping
    public List<OrderEntity> findAll() { return orderService.findAll(); }

    @GetMapping("/member/{memberId}")
    public List<OrderEntity> findByMember(@PathVariable Integer memberId) { return orderService.findByMemberId(memberId); }

    @PostMapping("/checkout")
    public OrderEntity checkout(@RequestBody CheckoutRequest request) {
        return orderService.checkout(request.getMemberId(), request.getPaymentMethod(), request.getShippingMethod());
    }

    @PatchMapping("/{orderId}/status")
    public OrderEntity changeStatus(@PathVariable Integer orderId, @RequestBody OrderStatusRequest request) {
        return orderService.changeStatus(orderId, request.getStatus());
    }
}
