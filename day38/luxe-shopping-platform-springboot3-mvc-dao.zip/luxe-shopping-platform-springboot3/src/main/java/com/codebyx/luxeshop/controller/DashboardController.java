package com.codebyx.luxeshop.controller;

import com.codebyx.luxeshop.model.DashboardStats;
import com.codebyx.luxeshop.service.ReportService;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/dashboard")
@CrossOrigin
public class DashboardController {
    private final ReportService reportService;

    public DashboardController(ReportService reportService) {
        this.reportService = reportService;
    }

    @GetMapping
    public DashboardStats dashboard() {
        return reportService.dashboardStats();
    }
}
