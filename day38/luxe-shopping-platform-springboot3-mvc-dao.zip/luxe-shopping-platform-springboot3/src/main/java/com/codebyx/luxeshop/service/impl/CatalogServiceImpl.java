package com.codebyx.luxeshop.service.impl;

import com.codebyx.luxeshop.dao.CategoryDao;
import com.codebyx.luxeshop.dao.ProductDao;
import com.codebyx.luxeshop.dto.CategoryRequest;
import com.codebyx.luxeshop.dto.ProductRequest;
import com.codebyx.luxeshop.exception.AppException;
import com.codebyx.luxeshop.model.Category;
import com.codebyx.luxeshop.model.Product;
import com.codebyx.luxeshop.service.CatalogService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.math.BigDecimal;
import java.util.List;

@Service
@Transactional
public class CatalogServiceImpl implements CatalogService {
    private final CategoryDao categoryDao;
    private final ProductDao productDao;

    public CatalogServiceImpl(CategoryDao categoryDao, ProductDao productDao) {
        this.categoryDao = categoryDao;
        this.productDao = productDao;
    }

    @Override
    @Transactional(readOnly = true)
    public List<Category> findCategories() { return categoryDao.findAll(); }

    @Override
    public Category createCategory(CategoryRequest request) {
        Category category = new Category();
        category.setName(request.getName());
        category.setDescription(request.getDescription());
        category.setStatus(request.getStatus() == null ? "啟用" : request.getStatus());
        return categoryDao.save(category);
    }

    @Override
    @Transactional(readOnly = true)
    public List<Product> findAllProducts() { return productDao.findAll(); }

    @Override
    @Transactional(readOnly = true)
    public List<Product> findActiveProducts() { return productDao.findActive(); }

    @Override
    public Product createProduct(ProductRequest request) {
        Product product = new Product();
        apply(product, request);
        return productDao.save(product);
    }

    @Override
    public Product updateProduct(Integer id, ProductRequest request) {
        Product product = productDao.findById(id).orElseThrow(() -> new AppException("找不到商品"));
        apply(product, request);
        return productDao.save(product);
    }

    private void apply(Product product, ProductRequest request) {
        if (request.getCategoryId() == null) throw new AppException("請選擇商品分類");
        Category category = categoryDao.findById(request.getCategoryId()).orElseThrow(() -> new AppException("找不到商品分類"));
        if (request.getName() == null || request.getName().isBlank()) throw new AppException("商品名稱不可空白");
        if (request.getPrice() == null || request.getPrice().compareTo(BigDecimal.ZERO) < 0) throw new AppException("商品價格不可小於 0");
        if (request.getStock() == null || request.getStock() < 0) throw new AppException("庫存不可小於 0");
        product.setCategory(category);
        product.setName(request.getName());
        product.setPrice(request.getPrice());
        product.setStock(request.getStock());
        product.setStatus(request.getStatus() == null || request.getStatus().isBlank() ? "上架" : request.getStatus());
        product.setDescription(request.getDescription());
    }
}
