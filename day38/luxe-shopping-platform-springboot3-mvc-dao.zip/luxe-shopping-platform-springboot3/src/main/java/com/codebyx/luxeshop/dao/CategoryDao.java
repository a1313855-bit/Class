package com.codebyx.luxeshop.dao;

import com.codebyx.luxeshop.model.Category;
import java.util.List;
import java.util.Optional;

public interface CategoryDao {
    List<Category> findAll();
    Optional<Category> findById(Integer id);
    Category save(Category category);
}
