package com.codebyx.luxeshop.service.impl;

import com.codebyx.luxeshop.dao.ReportDao;
import com.codebyx.luxeshop.model.DashboardStats;
import com.codebyx.luxeshop.model.ReportRow;
import com.codebyx.luxeshop.service.ReportService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;

@Service
@Transactional(readOnly = true)
public class ReportServiceImpl implements ReportService {
    private final ReportDao reportDao;

    public ReportServiceImpl(ReportDao reportDao) {
        this.reportDao = reportDao;
    }

    @Override
    public DashboardStats dashboardStats() { return reportDao.dashboardStats(); }

    @Override
    public List<ReportRow> productSales() { return reportDao.productSales(); }
}
