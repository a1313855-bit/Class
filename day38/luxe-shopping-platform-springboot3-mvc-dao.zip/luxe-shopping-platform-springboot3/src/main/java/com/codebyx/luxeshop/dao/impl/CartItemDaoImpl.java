package com.codebyx.luxeshop.dao.impl;

import com.codebyx.luxeshop.dao.CartItemDao;
import com.codebyx.luxeshop.model.CartItem;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import org.springframework.stereotype.Repository;
import java.util.List;
import java.util.Optional;

@Repository
public class CartItemDaoImpl implements CartItemDao {
    @PersistenceContext
    private EntityManager em;

    @Override
    public List<CartItem> findByMemberId(Integer memberId) {
        return em.createQuery("select c from CartItem c join fetch c.product p join fetch p.category where c.member.id = :memberId order by c.id", CartItem.class)
                .setParameter("memberId", memberId)
                .getResultList();
    }

    @Override
    public Optional<CartItem> findByMemberIdAndProductId(Integer memberId, Integer productId) {
        return em.createQuery("select c from CartItem c where c.member.id = :memberId and c.product.id = :productId", CartItem.class)
                .setParameter("memberId", memberId)
                .setParameter("productId", productId)
                .getResultStream()
                .findFirst();
    }

    @Override
    public Optional<CartItem> findById(Integer id) {
        return Optional.ofNullable(em.find(CartItem.class, id));
    }

    @Override
    public CartItem save(CartItem cartItem) {
        if (cartItem.getId() == null) {
            em.persist(cartItem);
            return cartItem;
        }
        return em.merge(cartItem);
    }

    @Override
    public void delete(CartItem cartItem) {
        em.remove(em.contains(cartItem) ? cartItem : em.merge(cartItem));
    }

    @Override
    public void deleteByMemberId(Integer memberId) {
        em.createQuery("delete from CartItem c where c.member.id = :memberId")
                .setParameter("memberId", memberId)
                .executeUpdate();
    }
}
