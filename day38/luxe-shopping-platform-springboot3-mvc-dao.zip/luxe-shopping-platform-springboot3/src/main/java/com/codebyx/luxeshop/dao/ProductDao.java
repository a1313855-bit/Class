package com.codebyx.luxeshop.dao;

import com.codebyx.luxeshop.model.Product;
import java.util.List;
import java.util.Optional;

public interface ProductDao {
    List<Product> findAll();
    List<Product> findActive();
    Optional<Product> findById(Integer id);
    Product save(Product product);
    long count();
}
