
package com.example.rpg.service;
import com.example.rpg.entity.*; import java.util.*;
public interface BagService { List<Equipment> allEquipment(); List<HeroEquipment> bag(Integer heroId); HeroEquipment addItem(Integer heroId, Integer equipmentId); }
