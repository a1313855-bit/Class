package com.example.rpg.dao;

import com.example.rpg.entity.HeroStats;
import java.util.*;

public interface HeroStatsDao { HeroStats save(HeroStats stats); Optional<HeroStats> findById(Integer heroId); }
