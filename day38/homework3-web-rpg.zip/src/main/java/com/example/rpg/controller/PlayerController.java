
package com.example.rpg.controller;
import com.example.rpg.dto.*; import com.example.rpg.service.PlayerService; import org.springframework.web.bind.annotation.*;
@RestController @RequestMapping("/api/players") public class PlayerController { private final PlayerService service; public PlayerController(PlayerService service){this.service=service;} @PostMapping("/register") public ApiResponse<?> register(@RequestBody RegisterRequest r){return ApiResponse.ok(service.register(r));} @PostMapping("/login") public ApiResponse<?> login(@RequestBody LoginRequest r){return ApiResponse.ok(service.login(r));} }
