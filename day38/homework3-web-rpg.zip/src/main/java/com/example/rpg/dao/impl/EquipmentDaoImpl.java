package com.example.rpg.dao.impl;

import com.example.rpg.dao.EquipmentDao;
import com.example.rpg.entity.Equipment;
import com.example.rpg.repository.EquipmentRepository;
import org.springframework.stereotype.Repository;
import java.util.*;

@Repository
public class EquipmentDaoImpl implements EquipmentDao {
    private final EquipmentRepository repository;
    public EquipmentDaoImpl(EquipmentRepository repository){this.repository=repository;}
    public List<Equipment> findAll(){return repository.findAll();} public Optional<Equipment> findById(Integer id){return repository.findById(id);}
}
