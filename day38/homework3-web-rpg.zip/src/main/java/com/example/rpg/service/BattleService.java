
package com.example.rpg.service;
import com.example.rpg.dto.BattleResult; import com.example.rpg.entity.Monster; import java.util.*;
public interface BattleService { List<Monster> monsters(Integer mapId); BattleResult fight(Integer heroId, Integer monsterId); }
