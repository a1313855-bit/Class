
package com.example.rpg.dto;
public record CreateHeroRequest(Integer playerId, String name, String gender) {}
