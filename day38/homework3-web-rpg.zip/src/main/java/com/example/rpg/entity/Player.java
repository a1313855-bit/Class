package com.example.rpg.entity;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "player")
public class Player {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    @Column(nullable = false, unique = true, length = 50)
    private String username;
    @Column(nullable = false, length = 100)
    private String password;
    @Column(name = "nick_name", nullable = false, length = 50)
    private String nickName;
    @Column(length = 100)
    private String mail;
    @Column(name = "create_time")
    private LocalDateTime createTime = LocalDateTime.now();
    public Integer getId(){return id;} public void setId(Integer id){this.id=id;}
    public String getUsername(){return username;} public void setUsername(String username){this.username=username;}
    public String getPassword(){return password;} public void setPassword(String password){this.password=password;}
    public String getNickName(){return nickName;} public void setNickName(String nickName){this.nickName=nickName;}
    public String getMail(){return mail;} public void setMail(String mail){this.mail=mail;}
    public LocalDateTime getCreateTime(){return createTime;} public void setCreateTime(LocalDateTime createTime){this.createTime=createTime;}
}
