
package com.example.rpg.dto;
public record BattleResult(String message, HeroView hero, String monsterName, int damage, boolean levelUp) {}
