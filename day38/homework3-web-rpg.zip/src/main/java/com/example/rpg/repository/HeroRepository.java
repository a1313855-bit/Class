package com.example.rpg.repository;

import com.example.rpg.entity.Hero;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.*;

public interface HeroRepository extends JpaRepository<Hero,Integer> {
    List<Hero> findByPlayerId(Integer playerId);
}
