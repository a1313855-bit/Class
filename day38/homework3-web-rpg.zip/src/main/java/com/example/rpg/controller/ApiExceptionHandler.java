
package com.example.rpg.controller;
import com.example.rpg.dto.ApiResponse; import com.example.rpg.exception.ServiceException; import org.springframework.web.bind.annotation.*;
@RestControllerAdvice public class ApiExceptionHandler { @ExceptionHandler(ServiceException.class) public ApiResponse<Void> service(ServiceException e){return ApiResponse.fail(e.getMessage());} @ExceptionHandler(Exception.class) public ApiResponse<Void> unknown(Exception e){return ApiResponse.fail("系統錯誤："+e.getMessage());} }
