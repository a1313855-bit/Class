package com.example.rpg.dao;

import com.example.rpg.entity.Hero;
import java.util.*;

public interface HeroDao { Hero save(Hero hero); Optional<Hero> findById(Integer id); List<Hero> findByPlayerId(Integer playerId); }
