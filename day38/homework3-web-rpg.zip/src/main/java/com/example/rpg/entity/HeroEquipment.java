package com.example.rpg.entity;
import jakarta.persistence.*;
import com.fasterxml.jackson.annotation.JsonIgnore;
@Entity @Table(name="hero_equipment")
public class HeroEquipment { @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Integer id; @JsonIgnore @ManyToOne(fetch=FetchType.LAZY) @JoinColumn(name="hero_id") private Hero hero; @ManyToOne(fetch=FetchType.EAGER) @JoinColumn(name="equipment_id") private Equipment equipment; @Column(name="is_equipped") private Boolean equipped=false; public Integer getId(){return id;} public void setId(Integer id){this.id=id;} public Hero getHero(){return hero;} public void setHero(Hero hero){this.hero=hero;} public Equipment getEquipment(){return equipment;} public void setEquipment(Equipment equipment){this.equipment=equipment;} public Boolean getEquipped(){return equipped;} public void setEquipped(Boolean equipped){this.equipped=equipped;} }
