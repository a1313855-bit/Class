package com.example.rpg.dao.impl;

import com.example.rpg.dao.HeroDao;
import com.example.rpg.entity.Hero;
import com.example.rpg.repository.HeroRepository;
import org.springframework.stereotype.Repository;
import java.util.*;

@Repository
public class HeroDaoImpl implements HeroDao {
    private final HeroRepository repository;
    public HeroDaoImpl(HeroRepository repository){this.repository=repository;}
    public Hero save(Hero hero){return repository.save(hero);} public Optional<Hero> findById(Integer id){return repository.findById(id);} public List<Hero> findByPlayerId(Integer playerId){return repository.findByPlayerId(playerId);}
}
