package com.example.rpg.entity;

import jakarta.persistence.*;

@Entity
@Table(name = "hero")
public class Hero {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "player_id", nullable = false)
    private Player player;
    @Column(nullable = false, unique = true, length = 50)
    private String name;
    @Column(nullable = false, length = 10)
    private String gender;
    @Column(name = "img_name", nullable = false, length = 50)
    private String imgName;
    @OneToOne(mappedBy = "hero", cascade = CascadeType.ALL, orphanRemoval = true, fetch = FetchType.EAGER)
    private HeroStats stats;
    public Integer getId(){return id;} public void setId(Integer id){this.id=id;}
    public Player getPlayer(){return player;} public void setPlayer(Player player){this.player=player;}
    public String getName(){return name;} public void setName(String name){this.name=name;}
    public String getGender(){return gender;} public void setGender(String gender){this.gender=gender;}
    public String getImgName(){return imgName;} public void setImgName(String imgName){this.imgName=imgName;}
    public HeroStats getStats(){return stats;} public void setStats(HeroStats stats){this.stats=stats;}
}
