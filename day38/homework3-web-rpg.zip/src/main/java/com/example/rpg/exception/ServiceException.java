
package com.example.rpg.exception;
public class ServiceException extends RuntimeException { public ServiceException(String message){super(message);} }
