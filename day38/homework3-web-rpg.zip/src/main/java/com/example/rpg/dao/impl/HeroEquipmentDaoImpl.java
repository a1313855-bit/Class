package com.example.rpg.dao.impl;

import com.example.rpg.dao.HeroEquipmentDao;
import com.example.rpg.entity.HeroEquipment;
import com.example.rpg.repository.HeroEquipmentRepository;
import org.springframework.stereotype.Repository;
import java.util.*;

@Repository
public class HeroEquipmentDaoImpl implements HeroEquipmentDao {
    private final HeroEquipmentRepository repository;
    public HeroEquipmentDaoImpl(HeroEquipmentRepository repository){this.repository=repository;}
    public HeroEquipment save(HeroEquipment item){return repository.save(item);} public List<HeroEquipment> findByHeroId(Integer heroId){return repository.findByHeroId(heroId);}
}
