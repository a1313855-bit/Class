
package com.example.rpg.dto;
public record HeroView(Integer id, Integer playerId, String name, String gender, String imgName, Integer level, Integer exp, Integer hp, Integer atk, Integer def, Integer speed, Integer statPoints) {}
