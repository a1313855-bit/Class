package com.example.rpg.repository;

import com.example.rpg.entity.HeroStats;
import org.springframework.data.jpa.repository.JpaRepository;

public interface HeroStatsRepository extends JpaRepository<HeroStats,Integer> {
}
