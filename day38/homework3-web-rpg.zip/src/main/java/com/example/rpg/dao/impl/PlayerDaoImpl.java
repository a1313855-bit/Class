package com.example.rpg.dao.impl;

import com.example.rpg.dao.PlayerDao;
import com.example.rpg.entity.Player;
import com.example.rpg.repository.PlayerRepository;
import org.springframework.stereotype.Repository;
import java.util.*;

@Repository
public class PlayerDaoImpl implements PlayerDao {
    private final PlayerRepository repository;
    public PlayerDaoImpl(PlayerRepository repository){this.repository=repository;}
    public Optional<Player> findByUsername(String username){return repository.findByUsername(username);} public boolean existsByUsername(String username){return repository.existsByUsername(username);} public Player save(Player player){return repository.save(player);} public Optional<Player> findById(Integer id){return repository.findById(id);}
}
