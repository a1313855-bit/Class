
package com.example.rpg.dto;
public record RegisterRequest(String username, String password, String nickName, String mail) {}
