package com.example.rpg.dao;

import com.example.rpg.entity.HeroEquipment;
import java.util.*;

public interface HeroEquipmentDao { HeroEquipment save(HeroEquipment item); List<HeroEquipment> findByHeroId(Integer heroId); }
