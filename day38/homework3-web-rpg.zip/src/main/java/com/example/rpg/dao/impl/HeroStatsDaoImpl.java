package com.example.rpg.dao.impl;

import com.example.rpg.dao.HeroStatsDao;
import com.example.rpg.entity.HeroStats;
import com.example.rpg.repository.HeroStatsRepository;
import org.springframework.stereotype.Repository;
import java.util.*;

@Repository
public class HeroStatsDaoImpl implements HeroStatsDao {
    private final HeroStatsRepository repository;
    public HeroStatsDaoImpl(HeroStatsRepository repository){this.repository=repository;}
    public HeroStats save(HeroStats stats){return repository.save(stats);} public Optional<HeroStats> findById(Integer heroId){return repository.findById(heroId);}
}
