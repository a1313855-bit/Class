package com.example.rpg.dao;

import com.example.rpg.entity.Player;
import java.util.*;

public interface PlayerDao { Optional<Player> findByUsername(String username); boolean existsByUsername(String username); Player save(Player player); Optional<Player> findById(Integer id); }
