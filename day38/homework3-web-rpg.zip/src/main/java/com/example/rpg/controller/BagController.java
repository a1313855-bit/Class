
package com.example.rpg.controller;
import com.example.rpg.dto.ApiResponse; import com.example.rpg.service.BagService; import org.springframework.web.bind.annotation.*;
@RestController @RequestMapping("/api/bag") public class BagController { private final BagService service; public BagController(BagService service){this.service=service;} @GetMapping("/equipment") public ApiResponse<?> equipment(){return ApiResponse.ok(service.allEquipment());} @GetMapping public ApiResponse<?> bag(@RequestParam Integer heroId){return ApiResponse.ok(service.bag(heroId));} @PostMapping public ApiResponse<?> add(@RequestParam Integer heroId,@RequestParam Integer equipmentId){service.addItem(heroId,equipmentId); return ApiResponse.ok("已加入背包");} }
