
package com.example.rpg.dto;
public record LoginRequest(String username, String password) {}
