
package com.example.rpg.controller;
import com.example.rpg.dto.ApiResponse; import com.example.rpg.service.BattleService; import org.springframework.web.bind.annotation.*;
@RestController @RequestMapping("/api/battle") public class BattleController { private final BattleService service; public BattleController(BattleService service){this.service=service;} @GetMapping("/monsters") public ApiResponse<?> monsters(@RequestParam(defaultValue="1") Integer mapId){return ApiResponse.ok(service.monsters(mapId));} @PostMapping("/fight") public ApiResponse<?> fight(@RequestParam Integer heroId,@RequestParam Integer monsterId){return ApiResponse.ok(service.fight(heroId,monsterId));} }
