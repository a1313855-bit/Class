package com.example.rpg.repository;

import com.example.rpg.entity.Monster;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.*;

public interface MonsterRepository extends JpaRepository<Monster,Integer> {
    List<Monster> findByMapIdOrderByLevelAsc(Integer mapId);
}
