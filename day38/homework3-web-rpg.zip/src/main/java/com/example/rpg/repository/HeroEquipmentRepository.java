package com.example.rpg.repository;

import com.example.rpg.entity.HeroEquipment;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.*;

public interface HeroEquipmentRepository extends JpaRepository<HeroEquipment,Integer> {
    List<HeroEquipment> findByHeroId(Integer heroId);
}
