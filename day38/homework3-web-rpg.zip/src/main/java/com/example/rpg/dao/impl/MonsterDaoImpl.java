package com.example.rpg.dao.impl;

import com.example.rpg.dao.MonsterDao;
import com.example.rpg.entity.Monster;
import com.example.rpg.repository.MonsterRepository;
import org.springframework.stereotype.Repository;
import java.util.*;

@Repository
public class MonsterDaoImpl implements MonsterDao {
    private final MonsterRepository repository;
    public MonsterDaoImpl(MonsterRepository repository){this.repository=repository;}
    public List<Monster> findByMapId(Integer mapId){return repository.findByMapIdOrderByLevelAsc(mapId);} public Optional<Monster> findById(Integer id){return repository.findById(id);}
}
