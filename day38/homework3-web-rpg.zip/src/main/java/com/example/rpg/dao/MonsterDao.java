package com.example.rpg.dao;

import com.example.rpg.entity.Monster;
import java.util.*;

public interface MonsterDao { List<Monster> findByMapId(Integer mapId); Optional<Monster> findById(Integer id); }
