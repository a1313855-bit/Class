package com.example.rpg.dao;

import com.example.rpg.entity.Equipment;
import java.util.*;

public interface EquipmentDao { List<Equipment> findAll(); Optional<Equipment> findById(Integer id); }
