package com.example.rpg.repository;

import com.example.rpg.entity.Player;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.*;

public interface PlayerRepository extends JpaRepository<Player,Integer> {
    Optional<Player> findByUsername(String username);
    boolean existsByUsername(String username);
}
