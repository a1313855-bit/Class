
package com.example.rpg.service;
import com.example.rpg.dto.*; import com.example.rpg.entity.Player;
public interface PlayerService { Player register(RegisterRequest request); Player login(LoginRequest request); }
