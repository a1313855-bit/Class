
package com.example.rpg.service;
import com.example.rpg.dto.*; import java.util.*;
public interface HeroService { HeroView create(CreateHeroRequest request); List<HeroView> findByPlayer(Integer playerId); HeroView findView(Integer heroId); HeroView addStat(Integer heroId, String stat); }
