package com.example.rpg.entity;

import jakarta.persistence.*;

@Entity
@Table(name = "hero_stats")
public class HeroStats {
    @Id @Column(name = "hero_id")
    private Integer heroId;
    @OneToOne(fetch = FetchType.LAZY) @MapsId @JoinColumn(name = "hero_id")
    private Hero hero;
    private Integer level = 1, exp = 0, hp = 100, atk = 10, def = 5, speed = 10;
    @Column(name = "stat_points") private Integer statPoints = 0;
    public Integer getHeroId(){return heroId;} public void setHeroId(Integer heroId){this.heroId=heroId;}
    public Hero getHero(){return hero;} public void setHero(Hero hero){this.hero=hero;}
    public Integer getLevel(){return level;} public void setLevel(Integer level){this.level=level;}
    public Integer getExp(){return exp;} public void setExp(Integer exp){this.exp=exp;}
    public Integer getHp(){return hp;} public void setHp(Integer hp){this.hp=hp;}
    public Integer getAtk(){return atk;} public void setAtk(Integer atk){this.atk=atk;}
    public Integer getDef(){return def;} public void setDef(Integer def){this.def=def;}
    public Integer getSpeed(){return speed;} public void setSpeed(Integer speed){this.speed=speed;}
    public Integer getStatPoints(){return statPoints;} public void setStatPoints(Integer statPoints){this.statPoints=statPoints;}
}
