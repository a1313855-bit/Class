# homework3 Web RPG

本版本已由原本 Java Swing 專案改成 Web 版：

- UI：HTML + CSS + JavaScript + Bootstrap
- 後端：Spring Boot 3 + Spring Data JPA + MySQL
- 架構：Controller / Service / DAO / Repository / Entity，保留 MVC + DAO Pattern 的分層概念

## 執行方式

1. 建立 MySQL 資料庫並匯入資料：

```sql
source homework3.0.sql;
```

2. 修改 `src/main/resources/application.properties` 的 MySQL 帳號密碼。

3. 執行：

```bash
mvn spring-boot:run
```

4. 開啟：

```text
http://localhost:8080
```

預設測試帳號：`testuser / 123456`

## 分層說明

- `controller`：接收 Web/API 請求，屬於 MVC 的 Controller。
- `service`：處理登入、角色、戰鬥、背包等商業邏輯。
- `dao` / `dao.impl`：資料存取抽象層，Service 不直接依賴 Repository。
- `repository`：Spring Data JPA 介面。
- `entity`：JPA Entity，對應 MySQL 資料表。
- `resources/static`：前端 HTML/CSS/JavaScript/Bootstrap UI。

## 備註

原本 Swing/JDBC 程式碼已備份在 `legacy-swing-source/`，方便對照改版前後差異。
