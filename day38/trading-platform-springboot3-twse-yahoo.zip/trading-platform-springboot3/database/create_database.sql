CREATE DATABASE IF NOT EXISTS trading_platform
  DEFAULT CHARACTER SET utf8mb4
  DEFAULT COLLATE utf8mb4_unicode_ci;

USE trading_platform;

-- Spring Boot JPA 會依 Entity 自動建立資料表。
-- 若要重建，請先 DROP DATABASE trading_platform; 再重新執行本檔。
