# REST API 清單

## Market

| Method | URL | 說明 |
|---|---|---|
| GET | /api/market/symbols | 取得商品代號 |
| GET | /api/market/bars?symbol=DEMO&limit=300 | 取得行情資料 |
| GET | /api/market/latest?symbol=DEMO | 取得最新行情 |
| GET | /api/market/indicators?symbol=DEMO | 取得最新技術指標摘要 |
| GET | /api/market/correlations?symbol=DEMO&target=profit | 取得相關性分析 |
| POST | /api/market/sample?symbol=DEMO&count=500 | 產生範例行情 |
| POST | /api/market/import-csv?symbol=DEMO | 匯入行情 CSV |
| POST | /api/market/fetch-twse?stockNo=2330&symbol=2330.TW&startMonth=2026-01&endMonth=2026-07 | 從 TWSE 台灣證券交易所抓取上市個股日成交資料 |
| POST | /api/market/fetch-yahoo?yahooSymbol=2330.TW&symbol=2330.TW&startDate=2024-01-01&endDate=2026-07-09&interval=1d | 從 Yahoo Finance chart JSON 抓取歷史 OHLCV |

## Trade Journal

| Method | URL | 說明 |
|---|---|---|
| GET | /api/trades?symbol=DEMO | 取得交易日誌 |
| POST | /api/trades | 新增交易日誌 |
| GET | /api/trades/stats?symbol=DEMO | 取得交易統計 |
| POST | /api/trades/sample?symbol=DEMO | 產生交易日誌範例 |

## Backtest

| Method | URL | 說明 |
|---|---|---|
| GET | /api/backtest?symbol=DEMO&strategy=MA&initialCapital=100000 | 執行策略回測 |

strategy 可用：MA、MACD、RSI、KD、BOLLINGER。

## Paper Trading

| Method | URL | 說明 |
|---|---|---|
| POST | /api/paper/reset?symbol=DEMO&initialCapital=100000 | 重設模擬帳戶 |
| GET | /api/paper/state?symbol=DEMO&date=2026-07-09 | 取得模擬帳戶狀態 |
| POST | /api/paper/order | 模擬下單 |
| GET | /api/paper/orders | 取得模擬交易紀錄 |
| GET | /api/paper/equity | 取得模擬帳戶資金曲線 |
