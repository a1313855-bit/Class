const state = {
    symbol: 'DEMO',
    bars: [],
    indicators: [],
    correlations: [],
    trades: [],
    tradeStats: [],
    backtest: null,
    paperState: null,
    paperOrders: [],
    paperEquity: []
};

document.addEventListener('DOMContentLoaded', () => {
    bindTabs();
    bindActions();
    setDefaultDates();
    loadAll();
});

function bindTabs() {
    document.querySelectorAll('.tab').forEach(btn => {
        btn.addEventListener('click', () => {
            document.querySelectorAll('.tab').forEach(b => b.classList.remove('active'));
            document.querySelectorAll('.panel').forEach(p => p.classList.remove('active-panel'));
            btn.classList.add('active');
            document.getElementById(btn.dataset.tab).classList.add('active-panel');
        });
    });
}

function bindActions() {
    document.getElementById('btnReload').addEventListener('click', loadAll);
    document.getElementById('btnSample').addEventListener('click', async () => {
        state.symbol = getSymbol();
        await api(`/api/market/sample?symbol=${encodeURIComponent(state.symbol)}&count=500`, { method: 'POST' });
        toast('已重新產生範例行情資料');
        await loadAll();
    });
    document.getElementById('csvForm').addEventListener('submit', importCsv);
    document.getElementById('twseForm').addEventListener('submit', fetchTwseData);
    document.getElementById('yahooForm').addEventListener('submit', fetchYahooData);
    document.getElementById('btnTradeSample').addEventListener('click', async () => {
        await api(`/api/trades/sample?symbol=${encodeURIComponent(getSymbol())}`, { method: 'POST' });
        toast('已產生交易日誌範例');
        await loadTrades();
    });
    document.getElementById('tradeForm').addEventListener('submit', saveTrade);
    document.getElementById('btnBacktest').addEventListener('click', runBacktest);
    document.getElementById('btnResetPaper').addEventListener('click', async () => {
        const capital = Number(document.getElementById('paperCapital').value || 100000);
        await api(`/api/paper/reset?symbol=${encodeURIComponent(getSymbol())}&initialCapital=${capital}`, { method: 'POST' });
        toast('模擬帳戶已重設');
        await loadPaper();
    });
    document.getElementById('paperForm').addEventListener('submit', placePaperOrder);
    document.getElementById('btnReport').addEventListener('click', loadReport);
}

function setDefaultDates() {
    const now = new Date();
    const today = now.toISOString().slice(0, 10);
    const month = today.slice(0, 7);
    document.querySelectorAll('input[type="date"]').forEach(input => {
        if (!input.value) input.value = today;
    });
    document.querySelectorAll('input[type="month"]').forEach(input => {
        if (!input.value) input.value = month;
    });
}

async function loadAll() {
    state.symbol = getSymbol();
    try {
        await Promise.all([loadMarket(), loadTrades(), runBacktest(), loadPaper(), loadReport(false)]);
        renderDashboard();
    } catch (e) {
        toast(e.message || String(e), true);
    }
}

async function loadMarket() {
    const symbol = getSymbol();
    state.bars = (await api(`/api/market/bars?symbol=${encodeURIComponent(symbol)}&limit=300`)).data || [];
    state.indicators = (await api(`/api/market/indicators?symbol=${encodeURIComponent(symbol)}`)).data || [];
    state.correlations = (await api(`/api/market/correlations?symbol=${encodeURIComponent(symbol)}&target=profit`)).data || [];
    renderMarket();
    renderCorrelation();
}

async function loadTrades() {
    const symbol = getSymbol();
    state.trades = (await api(`/api/trades?symbol=${encodeURIComponent(symbol)}`)).data || [];
    state.tradeStats = (await api(`/api/trades/stats?symbol=${encodeURIComponent(symbol)}`)).data || [];
    renderTrades();
}

async function loadPaper() {
    const symbol = getSymbol();
    const date = state.bars.length ? state.bars[state.bars.length - 1].barDate : new Date().toISOString().slice(0, 10);
    state.paperState = (await api(`/api/paper/state?symbol=${encodeURIComponent(symbol)}&date=${date}`)).data;
    state.paperOrders = (await api('/api/paper/orders')).data || [];
    state.paperEquity = (await api('/api/paper/equity')).data || [];
    renderPaper();
}

async function importCsv(e) {
    e.preventDefault();
    const file = document.getElementById('csvFile').files[0];
    if (!file) return toast('請先選擇 CSV 檔', true);
    const fd = new FormData();
    fd.append('file', file);
    await api(`/api/market/import-csv?symbol=${encodeURIComponent(getSymbol())}`, { method: 'POST', body: fd });
    toast('CSV 匯入完成');
    await loadAll();
}


async function fetchTwseData(e) {
    e.preventDefault();
    const form = new FormData(e.target);
    const stockNo = (form.get('stockNo') || '').trim();
    const symbol = (form.get('symbol') || stockNo + '.TW').trim().toUpperCase();
    const startMonth = form.get('startMonth') || new Date().toISOString().slice(0, 7);
    const endMonth = form.get('endMonth') || startMonth;
    document.getElementById('symbol').value = symbol;
    state.symbol = symbol;
    const url = `/api/market/fetch-twse?stockNo=${encodeURIComponent(stockNo)}&symbol=${encodeURIComponent(symbol)}&startMonth=${encodeURIComponent(startMonth)}&endMonth=${encodeURIComponent(endMonth)}`;
    const payload = await api(url, { method: 'POST' });
    toast(`${payload.message}，共 ${payload.data?.length || 0} 筆`);
    await loadAll();
}

async function fetchYahooData(e) {
    e.preventDefault();
    const form = new FormData(e.target);
    const yahooSymbol = (form.get('yahooSymbol') || '').trim();
    const symbol = (form.get('symbol') || yahooSymbol).trim().toUpperCase();
    const startDate = form.get('startDate');
    const endDate = form.get('endDate');
    const interval = form.get('interval') || '1d';
    document.getElementById('symbol').value = symbol;
    state.symbol = symbol;
    const url = `/api/market/fetch-yahoo?yahooSymbol=${encodeURIComponent(yahooSymbol)}&symbol=${encodeURIComponent(symbol)}&startDate=${encodeURIComponent(startDate)}&endDate=${encodeURIComponent(endDate)}&interval=${encodeURIComponent(interval)}`;
    const payload = await api(url, { method: 'POST' });
    toast(`${payload.message}，共 ${payload.data?.length || 0} 筆`);
    await loadAll();
}

async function saveTrade(e) {
    e.preventDefault();
    const form = new FormData(e.target);
    const payload = Object.fromEntries(form.entries());
    payload.symbol = getSymbol();
    ['entryPrice', 'exitPrice', 'quantity', 'fee', 'slippage'].forEach(k => payload[k] = Number(payload[k] || 0));
    await api('/api/trades', jsonPost(payload));
    toast('交易日誌已儲存');
    e.target.reset();
    setDefaultDates();
    await loadTrades();
}

async function runBacktest() {
    const strategy = document.getElementById('backtestStrategy').value;
    const capital = Number(document.getElementById('btCapital').value || 100000);
    const allowShort = document.getElementById('btShort').checked;
    const url = `/api/backtest?symbol=${encodeURIComponent(getSymbol())}&strategy=${strategy}&initialCapital=${capital}&allowShort=${allowShort}`;
    state.backtest = (await api(url)).data;
    renderBacktest();
    return state.backtest;
}

async function placePaperOrder(e) {
    e.preventDefault();
    const form = new FormData(e.target);
    const payload = Object.fromEntries(form.entries());
    payload.symbol = getSymbol();
    ['quantity', 'priceOverride', 'feeRatePct', 'slippageRatePct', 'multiplier'].forEach(k => {
        payload[k] = payload[k] === '' ? null : Number(payload[k]);
    });
    await api('/api/paper/order', jsonPost(payload));
    toast('模擬下單完成');
    await loadPaper();
}


async function loadReport(showToast = true) {
    const type = encodeURIComponent(document.getElementById('reportType').value || '盤前 + 盤後');
    const payload = await api(`/api/report/daily?symbol=${encodeURIComponent(getSymbol())}&reportType=${type}`);
    document.getElementById('reportText').value = payload.data || '';
    if (showToast) toast('每日報告已產生');
}

function renderDashboard() {
    const latest = state.bars[state.bars.length - 1] || {};
    const paper = state.paperState || {};
    const bt = state.backtest?.metrics || [];
    const btReturn = bt.find(x => x.metric === '策略總報酬')?.value || '--';
    setCards('dashboardCards', [
        { label: '最新日期', value: latest.barDate || '--', meaning: '目前資料最後一筆日期。' },
        { label: '收盤價', value: formatNumber(latest.closePrice), meaning: '最新行情收盤價。' },
        { label: '模擬帳戶權益', value: formatNumber(paper.equity), meaning: '現金 + 持倉市值。' },
        { label: '回測策略報酬', value: btReturn, meaning: '目前選定策略的回測結果。' }
    ]);
    drawLineChart('priceChart', state.bars.map(x => x.barDate), [{ name: 'Close', values: state.bars.map(x => x.closePrice) }]);
    drawLineChart('paperEquityChart', state.paperEquity.map(x => x.snapshotDate), [{ name: 'Equity', values: state.paperEquity.map(x => x.equity) }]);
}

function renderMarket() {
    renderMetricTable('indicatorTable', state.indicators);
    renderTable('marketTable', state.bars.slice(-120).reverse(), [
        ['barDate', '日期'], ['symbol', '商品'], ['dataSource', '來源'], ['sourceSymbol', '來源代號'], ['openPrice', '開盤'], ['highPrice', '最高'], ['lowPrice', '最低'], ['closePrice', '收盤'],
        ['volume', '量'], ['rsi', 'RSI'], ['macdHist', 'MACD Hist'], ['kdK', 'KD K'], ['kdD', 'KD D'], ['bbPosition', 'BB %B'], ['profit', 'Profit']
    ]);
    drawBarChart('volumeChart', state.bars.map(x => x.barDate), state.bars.map(x => x.volume || 0));
}

function renderCorrelation() {
    const negative = [...state.correlations].slice(0, 10);
    const positive = [...state.correlations].slice(-10).reverse();
    renderTable('negativeCorrTable', negative, [['feature', '欄位'], ['correlation', '相關係數'], ['direction', '方向']]);
    renderTable('positiveCorrTable', positive, [['feature', '欄位'], ['correlation', '相關係數'], ['direction', '方向']]);
    const show = [...negative, ...positive];
    drawBarChart('corrChart', show.map(x => x.feature), show.map(x => x.correlation || 0));
}

function renderTrades() {
    setCards('tradeStatsCards', state.tradeStats.map(x => ({ label: x.metric, value: x.value, meaning: x.meaning })));
    renderTable('tradeTable', state.trades.slice().reverse(), [
        ['entryDate', '進場日'], ['exitDate', '出場日'], ['side', '方向'], ['entryPrice', '進場價'], ['exitPrice', '出場價'],
        ['quantity', '數量'], ['strategy', '策略'], ['grossProfit', '毛損益'], ['netProfit', '淨損益'], ['returnPct', '報酬率'], ['cumulativeProfit', '累積損益'], ['drawdown', '回撤']
    ]);
}

function renderBacktest() {
    if (!state.backtest) return;
    setCards('backtestCards', state.backtest.metrics.map(x => ({ label: x.metric, value: x.value, meaning: x.meaning })));
    const points = state.backtest.points || [];
    drawLineChart('backtestEquityChart', points.map(x => x.date), [
        { name: '策略', values: points.map(x => x.equity) },
        { name: '買進持有', values: points.map(x => x.buyHoldEquity) }
    ]);
    drawLineChart('backtestDrawdownChart', points.map(x => x.date), [{ name: 'Drawdown', values: points.map(x => x.drawdownPct) }]);
}

function renderPaper() {
    const p = state.paperState || {};
    const acc = p.account || {};
    setCards('paperCards', [
        { label: '現金', value: formatNumber(acc.cash), meaning: '扣除模擬買賣與成本後的現金。' },
        { label: '持倉數量', value: formatNumber(acc.positionQty), meaning: '正數為多單，負數為空單。' },
        { label: '平均成本', value: formatNumber(acc.avgPrice), meaning: '目前持倉平均價格。' },
        { label: '帳戶權益', value: formatNumber(p.equity), meaning: '現金 + 持倉市值。' },
        { label: '已實現損益', value: formatNumber(acc.realizedPnl), meaning: '已平倉與交易成本後的損益。' },
        { label: '未實現損益', value: formatNumber(p.unrealizedPnl), meaning: '目前持倉依最新價估算的浮動損益。' },
        { label: '總報酬率', value: formatPercent(p.totalReturnPct), meaning: '帳戶權益 / 初始資金 - 1。' },
        { label: '估算價格日期', value: p.marketDate || '--', meaning: '用來估算帳戶權益的行情日期。' }
    ]);
    renderTable('paperOrderTable', state.paperOrders.slice().reverse(), [
        ['tradeDate', '日期'], ['side', '動作'], ['price', '成交價'], ['quantity', '數量'], ['fee', '手續費'], ['slippage', '滑價'],
        ['realizedPnl', '本次已實現'], ['cashAfter', '現金'], ['positionAfter', '持倉'], ['avgPriceAfter', '平均成本'], ['equityAfter', '權益']
    ]);
}

function renderTable(id, rows, columns) {
    const table = document.getElementById(id);
    if (!table) return;
    if (!rows || !rows.length) {
        table.innerHTML = '<tr><td>沒有資料</td></tr>';
        return;
    }
    const thead = `<thead><tr>${columns.map(c => `<th>${c[1]}</th>`).join('')}</tr></thead>`;
    const tbody = rows.map(row => `<tr>${columns.map(c => `<td>${formatCell(row[c[0]])}</td>`).join('')}</tr>`).join('');
    table.innerHTML = thead + `<tbody>${tbody}</tbody>`;
}

function renderMetricTable(id, rows) {
    const table = document.getElementById(id);
    if (!rows || !rows.length) { table.innerHTML = '<tr><td>沒有資料</td></tr>'; return; }
    table.innerHTML = '<thead><tr><th>指標</th><th>數值</th><th>說明</th></tr></thead>' +
        '<tbody>' + rows.map(x => `<tr><td>${x.metric}</td><td>${x.value}</td><td>${x.meaning}</td></tr>`).join('') + '</tbody>';
}

function setCards(id, cards) {
    const el = document.getElementById(id);
    el.innerHTML = (cards || []).map(c => `
        <article class="card metric-card">
            <div class="label">${c.label}</div>
            <div class="value">${c.value ?? '--'}</div>
            <div class="meaning">${c.meaning ?? ''}</div>
        </article>
    `).join('') || '<article class="card">沒有資料</article>';
}

async function api(url, options = {}) {
    const res = await fetch(url, options);
    const payload = await res.json().catch(() => ({}));
    if (!res.ok || payload.success === false) throw new Error(payload.message || `HTTP ${res.status}`);
    return payload;
}

function jsonPost(payload) {
    return { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) };
}

function getSymbol() { return (document.getElementById('symbol').value || 'DEMO').trim().toUpperCase(); }
function formatCell(v) {
    if (v === null || v === undefined) return '--';
    if (typeof v === 'number') return Number.isInteger(v) ? String(v) : formatNumber(v);
    if (typeof v === 'boolean') return v ? '是' : '否';
    return String(v);
}
function formatNumber(v) {
    if (v === null || v === undefined || !Number.isFinite(Number(v))) return '--';
    return Number(v).toLocaleString('zh-TW', { maximumFractionDigits: 4 });
}
function formatPercent(v) {
    if (v === null || v === undefined || !Number.isFinite(Number(v))) return '--';
    return (Number(v) * 100).toFixed(2) + '%';
}
function toast(message, error = false) {
    const el = document.getElementById('toast');
    el.textContent = message;
    el.style.borderColor = error ? '#ff7a7a' : 'rgba(255,255,255,.12)';
    el.classList.add('show');
    setTimeout(() => el.classList.remove('show'), 3600);
}
