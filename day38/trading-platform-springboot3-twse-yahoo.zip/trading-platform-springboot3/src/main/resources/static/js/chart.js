function drawLineChart(canvasId, labels, seriesList, options = {}) {
    const canvas = document.getElementById(canvasId);
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    const width = canvas.clientWidth || 800;
    const height = canvas.height || 220;
    canvas.width = width * devicePixelRatio;
    canvas.height = height * devicePixelRatio;
    ctx.scale(devicePixelRatio, devicePixelRatio);
    ctx.clearRect(0, 0, width, height);
    const pad = { left: 54, right: 22, top: 22, bottom: 34 };
    const all = seriesList.flatMap(s => s.values).filter(v => Number.isFinite(v));
    if (!all.length) {
        drawEmpty(ctx, width, height, '沒有資料');
        return;
    }
    let min = Math.min(...all);
    let max = Math.max(...all);
    if (min === max) { min *= .98; max *= 1.02; }
    drawGrid(ctx, width, height, pad, min, max);
    seriesList.forEach((series, index) => {
        ctx.beginPath();
        ctx.lineWidth = 2;
        ctx.strokeStyle = index === 0 ? '#63d7bd' : '#f2c16b';
        series.values.forEach((v, i) => {
            if (!Number.isFinite(v)) return;
            const x = pad.left + (width - pad.left - pad.right) * i / Math.max(series.values.length - 1, 1);
            const y = pad.top + (height - pad.top - pad.bottom) * (1 - (v - min) / (max - min));
            if (i === 0) ctx.moveTo(x, y); else ctx.lineTo(x, y);
        });
        ctx.stroke();
    });
    drawAxisText(ctx, labels, width, height, pad, min, max);
}

function drawBarChart(canvasId, labels, values, options = {}) {
    const canvas = document.getElementById(canvasId);
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    const width = canvas.clientWidth || 800;
    const height = canvas.height || 220;
    canvas.width = width * devicePixelRatio;
    canvas.height = height * devicePixelRatio;
    ctx.scale(devicePixelRatio, devicePixelRatio);
    ctx.clearRect(0, 0, width, height);
    const pad = { left: 54, right: 22, top: 22, bottom: 44 };
    const finite = values.filter(v => Number.isFinite(v));
    if (!finite.length) { drawEmpty(ctx, width, height, '沒有資料'); return; }
    const maxAbs = Math.max(...finite.map(v => Math.abs(v)), 1);
    const zeroY = pad.top + (height - pad.top - pad.bottom) / 2;
    ctx.strokeStyle = 'rgba(255,255,255,.18)';
    ctx.beginPath(); ctx.moveTo(pad.left, zeroY); ctx.lineTo(width - pad.right, zeroY); ctx.stroke();
    const barW = Math.max(4, (width - pad.left - pad.right) / values.length * 0.72);
    values.forEach((v, i) => {
        const x = pad.left + (width - pad.left - pad.right) * i / values.length + barW * .15;
        const h = (height - pad.top - pad.bottom) * Math.abs(v) / maxAbs / 2;
        ctx.fillStyle = v >= 0 ? '#63d7bd' : '#ff7a7a';
        ctx.fillRect(x, v >= 0 ? zeroY - h : zeroY, barW, h);
    });
    ctx.fillStyle = 'rgba(255,255,255,.7)';
    ctx.font = '12px Microsoft JhengHei, Arial';
    ctx.fillText(formatNumber(maxAbs), 8, pad.top + 8);
    ctx.fillText(formatNumber(-maxAbs), 8, height - pad.bottom + 4);
}

function drawGrid(ctx, width, height, pad, min, max) {
    ctx.strokeStyle = 'rgba(255,255,255,.10)';
    ctx.lineWidth = 1;
    for (let i = 0; i <= 4; i++) {
        const y = pad.top + (height - pad.top - pad.bottom) * i / 4;
        ctx.beginPath();
        ctx.moveTo(pad.left, y);
        ctx.lineTo(width - pad.right, y);
        ctx.stroke();
    }
}

function drawAxisText(ctx, labels, width, height, pad, min, max) {
    ctx.fillStyle = 'rgba(255,255,255,.72)';
    ctx.font = '12px Microsoft JhengHei, Arial';
    ctx.fillText(formatNumber(max), 8, pad.top + 5);
    ctx.fillText(formatNumber(min), 8, height - pad.bottom + 4);
    if (labels && labels.length) {
        ctx.fillText(String(labels[0]).slice(0, 10), pad.left, height - 10);
        ctx.fillText(String(labels[labels.length - 1]).slice(0, 10), Math.max(pad.left, width - 110), height - 10);
    }
}

function drawEmpty(ctx, width, height, text) {
    ctx.fillStyle = 'rgba(255,255,255,.65)';
    ctx.font = '15px Microsoft JhengHei, Arial';
    ctx.fillText(text, width / 2 - 32, height / 2);
}
