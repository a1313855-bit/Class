package com.codebyx.trading.controller;

import com.codebyx.trading.dto.ApiResponse;
import com.codebyx.trading.service.ExternalMarketDataService;
import com.codebyx.trading.service.MarketDataService;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

@RestController
@RequestMapping("/api/market")
@CrossOrigin
public class MarketDataController {
    private final MarketDataService marketDataService;
    private final ExternalMarketDataService externalMarketDataService;

    public MarketDataController(MarketDataService marketDataService,
                                ExternalMarketDataService externalMarketDataService) {
        this.marketDataService = marketDataService;
        this.externalMarketDataService = externalMarketDataService;
    }

    @GetMapping("/symbols")
    public ApiResponse symbols() {
        return ApiResponse.ok("symbols", marketDataService.symbols());
    }

    @GetMapping("/bars")
    public ApiResponse bars(@RequestParam(defaultValue = "DEMO") String symbol,
                            @RequestParam(defaultValue = "300") int limit) {
        return ApiResponse.ok("bars", marketDataService.findBars(symbol, limit));
    }

    @GetMapping("/latest")
    public ApiResponse latest(@RequestParam(defaultValue = "DEMO") String symbol) {
        return ApiResponse.ok("latest", marketDataService.latest(symbol));
    }

    @GetMapping("/indicators")
    public ApiResponse indicators(@RequestParam(defaultValue = "DEMO") String symbol) {
        return ApiResponse.ok("indicators", marketDataService.indicatorSummary(symbol));
    }

    @GetMapping("/correlations")
    public ApiResponse correlations(@RequestParam(defaultValue = "DEMO") String symbol,
                                    @RequestParam(defaultValue = "profit") String target) {
        return ApiResponse.ok("correlations", marketDataService.correlations(symbol, target));
    }

    @PostMapping("/sample")
    public ApiResponse sample(@RequestParam(defaultValue = "DEMO") String symbol,
                              @RequestParam(defaultValue = "500") int count) {
        return ApiResponse.ok("已重新產生範例行情資料", marketDataService.generateSample(symbol, count));
    }


    @PostMapping("/fetch-twse")
    public ApiResponse fetchTwse(@RequestParam String stockNo,
                                 @RequestParam(required = false) String symbol,
                                 @RequestParam(defaultValue = "2026-01") String startMonth,
                                 @RequestParam(defaultValue = "2026-07") String endMonth) {
        return ApiResponse.ok(
                "TWSE 台灣證券交易所資料匯入完成",
                externalMarketDataService.fetchTwseStockDay(
                        symbol,
                        stockNo,
                        java.time.YearMonth.parse(normalizeYearMonth(startMonth)),
                        java.time.YearMonth.parse(normalizeYearMonth(endMonth))
                )
        );
    }

    @PostMapping("/fetch-yahoo")
    public ApiResponse fetchYahoo(@RequestParam String yahooSymbol,
                                  @RequestParam(required = false) String symbol,
                                  @RequestParam(defaultValue = "1d") String interval,
                                  @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) java.time.LocalDate startDate,
                                  @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) java.time.LocalDate endDate) {
        return ApiResponse.ok(
                "Yahoo Finance 資料匯入完成",
                externalMarketDataService.fetchYahooChart(symbol, yahooSymbol, startDate, endDate, interval)
        );
    }

    private String normalizeYearMonth(String value) {
        if (value == null || value.isBlank()) return java.time.YearMonth.now().toString();
        String text = value.trim();
        if (text.matches("\\d{6}")) {
            return text.substring(0, 4) + "-" + text.substring(4, 6);
        }
        return text;
    }

    @PostMapping("/import-csv")
    public ApiResponse importCsv(@RequestParam(defaultValue = "DEMO") String symbol,
                                 @RequestPart("file") MultipartFile file) {
        return ApiResponse.ok("CSV 匯入完成", marketDataService.importCsv(symbol, file));
    }
}
