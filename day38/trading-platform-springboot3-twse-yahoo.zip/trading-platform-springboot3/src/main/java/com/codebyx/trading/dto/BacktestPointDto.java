package com.codebyx.trading.dto;

import java.time.LocalDate;

public record BacktestPointDto(
        LocalDate date,
        Double close,
        Integer signal,
        Integer position,
        Double marketReturn,
        Double strategyReturn,
        Double equity,
        Double buyHoldEquity,
        Double drawdownPct
) {}
