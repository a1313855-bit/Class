package com.codebyx.trading.service;

import com.codebyx.trading.dao.TradeJournalRepository;
import com.codebyx.trading.dto.MetricDto;
import com.codebyx.trading.model.MarketBar;
import com.codebyx.trading.model.TradeJournal;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.*;

@Service
public class TradeJournalService {
    private final TradeJournalRepository repository;
    private final MarketDataService marketDataService;

    public TradeJournalService(TradeJournalRepository repository, MarketDataService marketDataService) {
        this.repository = repository;
        this.marketDataService = marketDataService;
    }

    public List<TradeJournal> findAll(String symbol) {
        return recalc(repository.findBySymbolOrderByExitDateAscIdAsc(cleanSymbol(symbol)));
    }

    @Transactional
    public TradeJournal save(TradeJournal trade) {
        normalize(trade);
        TradeJournal saved = repository.save(trade);
        recalcAndPersist(cleanSymbol(saved.getSymbol()));
        return saved;
    }

    @Transactional
    public List<TradeJournal> generateSample(String symbol) {
        String targetSymbol = cleanSymbol(symbol);
        repository.findBySymbolOrderByExitDateAscIdAsc(targetSymbol).forEach(repository::delete);
        List<MarketBar> bars = marketDataService.findBars(targetSymbol, 120);
        Random random = new Random(123);
        List<TradeJournal> trades = new ArrayList<>();
        for (int i = 5; i < bars.size() - 5 && trades.size() < 30; i += 3 + random.nextInt(4)) {
            MarketBar entry = bars.get(i);
            MarketBar exit = bars.get(Math.min(i + 1 + random.nextInt(5), bars.size() - 1));
            TradeJournal t = new TradeJournal();
            t.setEntryDate(entry.getBarDate());
            t.setExitDate(exit.getBarDate());
            t.setSymbol(targetSymbol);
            t.setMarketType(random.nextBoolean() ? "股票" : "期貨");
            t.setSide(random.nextDouble() < 0.7 ? "Long" : "Short");
            t.setEntryPrice(entry.getClosePrice());
            t.setExitPrice(exit.getClosePrice());
            t.setQuantity((double) List.of(1, 2, 3, 5, 10, 100).get(random.nextInt(6)));
            t.setFee(20.0 + random.nextDouble() * 80.0);
            t.setSlippage(random.nextDouble() * 50.0);
            t.setStrategy(List.of("MA 趨勢", "RSI 反轉", "MACD 動能", "布林突破").get(random.nextInt(4)));
            t.setSetup(List.of("順勢突破", "拉回進場", "盤整突破", "超跌反彈").get(random.nextInt(4)));
            t.setEmotion(List.of("冷靜", "猶豫", "急躁", "紀律執行").get(random.nextInt(4)));
            t.setNotes("系統產生的教學交易日誌");
            normalize(t);
            trades.add(t);
        }
        repository.saveAll(trades);
        return recalcAndPersist(targetSymbol);
    }

    public List<MetricDto> stats(String symbol) {
        List<TradeJournal> trades = findAll(symbol).stream().filter(t -> t.getNetProfit() != null).toList();
        if (trades.isEmpty()) return List.of();
        int total = trades.size();
        double totalProfit = trades.stream().mapToDouble(t -> NumberUtil.nvl(t.getNetProfit())).sum();
        long winCount = trades.stream().filter(t -> Boolean.TRUE.equals(t.getWin())).count();
        double winRate = winCount * 1.0 / total;
        double avg = totalProfit / total;
        double grossWin = trades.stream().filter(t -> NumberUtil.nvl(t.getNetProfit()) > 0).mapToDouble(t -> t.getNetProfit()).sum();
        double grossLoss = Math.abs(trades.stream().filter(t -> NumberUtil.nvl(t.getNetProfit()) < 0).mapToDouble(t -> t.getNetProfit()).sum());
        Double profitFactor = grossLoss == 0 ? null : grossWin / grossLoss;
        double maxDd = trades.stream().mapToDouble(t -> NumberUtil.nvl(t.getDrawdown())).min().orElse(0);
        return List.of(
                new MetricDto("交易筆數", String.valueOf(total), "完成統計的交易總筆數。"),
                new MetricDto("總淨獲利", NumberUtil.num(totalProfit), "所有交易扣除成本後的損益總和。"),
                new MetricDto("勝率", NumberUtil.pct(winRate), "獲利交易筆數 / 全部交易筆數。"),
                new MetricDto("平均每筆損益", NumberUtil.num(avg), "每做一筆交易的平均期望值。"),
                new MetricDto("Profit Factor", NumberUtil.num(profitFactor), "總獲利 / 總虧損絕對值，大於 1 代表正期望。"),
                new MetricDto("最大回撤", NumberUtil.num(maxDd), "累積獲利從高點回落的最大金額。")
        );
    }

    private List<TradeJournal> recalcAndPersist(String symbol) {
        List<TradeJournal> rows = recalc(repository.findBySymbolOrderByExitDateAscIdAsc(symbol));
        return repository.saveAll(rows);
    }

    private List<TradeJournal> recalc(List<TradeJournal> rows) {
        rows.sort(Comparator.comparing(TradeJournal::getExitDate, Comparator.nullsLast(LocalDate::compareTo)));
        double cumulative = 0;
        double peak = 0;
        for (TradeJournal t : rows) {
            normalize(t);
            cumulative += NumberUtil.nvl(t.getNetProfit());
            peak = Math.max(peak, cumulative);
            t.setCumulativeProfit(cumulative);
            t.setDrawdown(cumulative - peak);
        }
        return rows;
    }

    private void normalize(TradeJournal t) {
        if (t.getSymbol() == null || t.getSymbol().isBlank()) t.setSymbol("DEMO");
        if (t.getMarketType() == null) t.setMarketType("股票");
        if (t.getSide() == null) t.setSide("Long");
        if (t.getQuantity() == null) t.setQuantity(1.0);
        if (t.getFee() == null) t.setFee(0.0);
        if (t.getSlippage() == null) t.setSlippage(0.0);
        if (t.getStrategy() == null) t.setStrategy("未分類");
        if (t.getSetup() == null) t.setSetup("未分類");
        if (t.getEmotion() == null) t.setEmotion("未記錄");
        if (t.getEntryDate() == null) t.setEntryDate(LocalDate.now());
        if (t.getExitDate() == null) t.setExitDate(t.getEntryDate());
        double entry = NumberUtil.nvl(t.getEntryPrice());
        double exit = NumberUtil.nvl(t.getExitPrice());
        double qty = NumberUtil.nvl(t.getQuantity());
        String side = t.getSide().trim().toLowerCase();
        boolean isShort = side.contains("short") || side.contains("空") || side.contains("sell");
        double gross = isShort ? (entry - exit) * qty : (exit - entry) * qty;
        double net = gross - NumberUtil.nvl(t.getFee()) - NumberUtil.nvl(t.getSlippage());
        t.setGrossProfit(gross);
        t.setNetProfit(net);
        t.setReturnPct(entry == 0 ? null : net / Math.abs(entry * qty));
        t.setWin(net > 0);
    }

    private String cleanSymbol(String symbol) {
        return symbol == null || symbol.isBlank() ? "DEMO" : symbol.trim().toUpperCase();
    }
}
