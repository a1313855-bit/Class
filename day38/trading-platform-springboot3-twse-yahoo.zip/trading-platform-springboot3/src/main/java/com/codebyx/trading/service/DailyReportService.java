package com.codebyx.trading.service;

import com.codebyx.trading.dto.CorrelationDto;
import com.codebyx.trading.dto.MetricDto;
import com.codebyx.trading.model.MarketBar;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Comparator;
import java.util.List;

@Service
public class DailyReportService {
    private final MarketDataService marketDataService;
    private final TradeJournalService tradeJournalService;

    public DailyReportService(MarketDataService marketDataService, TradeJournalService tradeJournalService) {
        this.marketDataService = marketDataService;
        this.tradeJournalService = tradeJournalService;
    }

    public String generate(String symbol, String reportType) {
        MarketBar latest = marketDataService.latest(symbol);
        List<MetricDto> indicators = marketDataService.indicatorSummary(symbol);
        List<MetricDto> tradeStats = tradeJournalService.stats(symbol);
        List<CorrelationDto> corr = marketDataService.correlations(symbol, "profit");
        String bias = trendBias(latest);
        StringBuilder sb = new StringBuilder();
        sb.append("# ").append(symbol.toUpperCase()).append(" 每日交易分析報告\n\n");
        sb.append("產生時間：").append(LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"))).append("\n\n");
        sb.append("報告類型：").append(reportType == null ? "盤前 + 盤後" : reportType).append("\n\n");
        sb.append("> 本報告為交易輔助與教學分析，不保證獲利，也不構成投資建議。\n\n");
        sb.append("## 一、市場狀態\n\n");
        sb.append("- 最新日期：").append(latest.getBarDate()).append("\n");
        sb.append("- 收盤價：").append(NumberUtil.num(latest.getClosePrice())).append("\n");
        sb.append("- 1 日報酬：").append(NumberUtil.pct(latest.getReturn1d())).append("\n");
        sb.append("- 5 日報酬：").append(NumberUtil.pct(latest.getReturn5d())).append("\n");
        sb.append("- 系統多空傾向：**").append(bias).append("**\n\n");

        sb.append("## 二、技術指標\n\n");
        for (MetricDto m : indicators) {
            sb.append("- ").append(m.metric()).append("：").append(m.value()).append("，").append(m.meaning()).append("\n");
        }

        sb.append("\n## 三、關鍵價位\n\n");
        sb.append("- 短期均線：").append(NumberUtil.num(latest.getMaShort())).append("\n");
        sb.append("- 長期均線：").append(NumberUtil.num(latest.getMaLong())).append("\n");
        sb.append("- 布林上軌：").append(NumberUtil.num(latest.getBbUpper())).append("\n");
        sb.append("- 布林中線：").append(NumberUtil.num(latest.getBbMid())).append("\n");
        sb.append("- 布林下軌：").append(NumberUtil.num(latest.getBbLower())).append("\n\n");

        sb.append("## 四、相關性觀察\n\n");
        sb.append("### 正相關較高\n");
        corr.stream().sorted(Comparator.comparing(CorrelationDto::correlation).reversed()).limit(5)
                .forEach(c -> sb.append("- ").append(c.feature()).append("：").append(NumberUtil.num(c.correlation())).append("\n"));
        sb.append("\n### 負相關較高\n");
        corr.stream().limit(5)
                .forEach(c -> sb.append("- ").append(c.feature()).append("：").append(NumberUtil.num(c.correlation())).append("\n"));

        sb.append("\n## 五、交易日誌績效\n\n");
        if (tradeStats.isEmpty()) {
            sb.append("目前沒有交易日誌統計資料。\n");
        } else {
            for (MetricDto m : tradeStats) sb.append("- ").append(m.metric()).append("：").append(m.value()).append("\n");
        }

        sb.append("\n## 六、交易計畫與風控\n\n");
        if ("偏多".equals(bias)) {
            sb.append("- 偏多情境：觀察價格是否站穩短期均線與布林中線，避免直接追高。\n");
            sb.append("- 中性情境：若 RSI 接近 50 且 MACD 動能縮小，降低交易頻率。\n");
            sb.append("- 偏空情境：若跌破長期均線或布林下軌，優先保護本金。\n");
        } else if ("偏空".equals(bias)) {
            sb.append("- 偏多情境：必須等價格重新站回短期均線，且 MACD / KD 同步轉強。\n");
            sb.append("- 中性情境：避免在區間中段追單，等待支撐或壓力確認。\n");
            sb.append("- 偏空情境：若反彈無量且跌破前低，應降低部位或停止交易。\n");
        } else {
            sb.append("- 偏多情境：突破區間上緣且量能放大時，才考慮順勢觀察。\n");
            sb.append("- 中性情境：以區間震盪處理，不追價。\n");
            sb.append("- 偏空情境：跌破布林下軌或長期均線時，停止逆勢接刀。\n");
        }
        sb.append("- 單筆風險建議控制在帳戶資金 0.5%～2%。\n");
        sb.append("- 連續虧損 2～3 筆後，應暫停交易並檢查策略是否失效。\n");
        return sb.toString();
    }

    private String trendBias(MarketBar latest) {
        int score = 0;
        if (NumberUtil.nvl(latest.getMaShort()) > NumberUtil.nvl(latest.getMaLong())) score++;
        if (NumberUtil.nvl(latest.getMacd()) > NumberUtil.nvl(latest.getMacdSignal())) score++;
        if (NumberUtil.nvl(latest.getRsi()) >= 55) score++;
        if (NumberUtil.nvl(latest.getKdK()) > NumberUtil.nvl(latest.getKdD())) score++;
        if (NumberUtil.nvl(latest.getBbPosition()) >= 0.55) score++;
        if (score >= 4) return "偏多";
        if (score <= 1) return "偏空";
        return "中性震盪";
    }
}
