package com.codebyx.trading.service;

public final class NumberUtil {
    private NumberUtil() {}
    public static double nvl(Double value) { return value == null || value.isNaN() || value.isInfinite() ? 0.0 : value; }
    public static Double safeDivide(Double n, Double d) {
        if (n == null || d == null || d == 0.0 || d.isNaN() || d.isInfinite()) return null;
        double v = n / d;
        return Double.isFinite(v) ? v : null;
    }
    public static String num(Double value) {
        if (value == null || value.isNaN() || value.isInfinite()) return "--";
        return String.format("%,.2f", value);
    }
    public static String pct(Double value) {
        if (value == null || value.isNaN() || value.isInfinite()) return "--";
        return String.format("%.2f%%", value * 100.0);
    }
}
