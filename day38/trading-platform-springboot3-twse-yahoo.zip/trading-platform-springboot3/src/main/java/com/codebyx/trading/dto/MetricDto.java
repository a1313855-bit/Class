package com.codebyx.trading.dto;

public record MetricDto(String metric, String value, String meaning) {}
