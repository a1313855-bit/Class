package com.codebyx.trading.dao;

import com.codebyx.trading.model.TradeJournal;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface TradeJournalRepository extends JpaRepository<TradeJournal, Long> {
    List<TradeJournal> findBySymbolOrderByExitDateAscIdAsc(String symbol);
}
