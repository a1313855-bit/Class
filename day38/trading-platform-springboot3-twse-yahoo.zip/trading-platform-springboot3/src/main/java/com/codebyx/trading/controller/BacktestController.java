package com.codebyx.trading.controller;

import com.codebyx.trading.dto.ApiResponse;
import com.codebyx.trading.service.BacktestService;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/backtest")
@CrossOrigin
public class BacktestController {
    private final BacktestService backtestService;

    public BacktestController(BacktestService backtestService) {
        this.backtestService = backtestService;
    }

    @GetMapping
    public ApiResponse run(@RequestParam(defaultValue = "DEMO") String symbol,
                           @RequestParam(defaultValue = "MA") String strategy,
                           @RequestParam(defaultValue = "100000") double initialCapital,
                           @RequestParam(defaultValue = "0.1425") double feeRatePct,
                           @RequestParam(defaultValue = "0.05") double slippageRatePct,
                           @RequestParam(defaultValue = "false") boolean allowShort) {
        return ApiResponse.ok("backtest", backtestService.run(symbol, strategy, initialCapital, feeRatePct, slippageRatePct, allowShort));
    }
}
