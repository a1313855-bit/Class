package com.codebyx.trading.dto;

public record CorrelationDto(String feature, Double correlation, String direction) {}
