package com.codebyx.trading.config;

import com.codebyx.trading.dao.MarketBarRepository;
import com.codebyx.trading.service.MarketDataService;
import com.codebyx.trading.service.PaperTradingService;
import com.codebyx.trading.service.TradeJournalService;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

@Component
public class DataInitializer implements CommandLineRunner {
    private final MarketBarRepository marketBarRepository;
    private final MarketDataService marketDataService;
    private final TradeJournalService tradeJournalService;
    private final PaperTradingService paperTradingService;

    public DataInitializer(MarketBarRepository marketBarRepository,
                           MarketDataService marketDataService,
                           TradeJournalService tradeJournalService,
                           PaperTradingService paperTradingService) {
        this.marketBarRepository = marketBarRepository;
        this.marketDataService = marketDataService;
        this.tradeJournalService = tradeJournalService;
        this.paperTradingService = paperTradingService;
    }

    @Override
    public void run(String... args) {
        if (marketBarRepository.count() == 0) {
            marketDataService.generateSample("DEMO", 500);
            tradeJournalService.generateSample("DEMO");
            paperTradingService.reset("DEMO", 100000.0);
        }
    }
}
