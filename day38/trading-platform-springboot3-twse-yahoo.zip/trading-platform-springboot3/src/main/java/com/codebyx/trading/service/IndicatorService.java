package com.codebyx.trading.service;

import com.codebyx.trading.model.MarketBar;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class IndicatorService {

    public List<MarketBar> addFeatures(List<MarketBar> bars, int futureDays, int maShortPeriod, int maLongPeriod,
                                       int rsiPeriod, int macdFast, int macdSlow, int macdSignalPeriod,
                                       int kdPeriod, int bbPeriod, double bbStdMult) {
        List<MarketBar> data = new ArrayList<>(bars);
        int n = data.size();
        if (n == 0) return data;

        double[] close = data.stream().mapToDouble(b -> NumberUtil.nvl(b.getClosePrice())).toArray();
        double[] open = data.stream().mapToDouble(b -> NumberUtil.nvl(b.getOpenPrice())).toArray();
        double[] high = data.stream().mapToDouble(b -> NumberUtil.nvl(b.getHighPrice())).toArray();
        double[] low = data.stream().mapToDouble(b -> NumberUtil.nvl(b.getLowPrice())).toArray();
        double[] volume = data.stream().mapToDouble(b -> b.getVolume() == null ? 0.0 : b.getVolume().doubleValue()).toArray();

        double[] maShort = sma(close, maShortPeriod);
        double[] maLong = sma(close, maLongPeriod);
        double[] volMa5 = sma(volume, 5);
        double[] rsi = rsi(close, rsiPeriod);
        double[] emaFast = ema(close, macdFast);
        double[] emaSlow = ema(close, macdSlow);
        double[] macd = new double[n];
        for (int i = 0; i < n; i++) macd[i] = emaFast[i] - emaSlow[i];
        double[] macdSignal = ema(macd, macdSignalPeriod);
        double[] kdK = stochasticK(close, high, low, kdPeriod);
        double[] kdD = emaWithAlpha(kdK, 1.0 / 3.0);
        double[] bbMid = sma(close, bbPeriod);
        double[] bbStd = rollingStd(close, bbPeriod);

        for (int i = 0; i < n; i++) {
            MarketBar b = data.get(i);
            b.setReturn1d(i >= 1 ? NumberUtil.safeDivide(close[i] - close[i - 1], close[i - 1]) : null);
            b.setReturn5d(i >= 5 ? NumberUtil.safeDivide(close[i] - close[i - 5], close[i - 5]) : null);
            b.setBodyPct(NumberUtil.safeDivide(close[i] - open[i], open[i]));
            b.setRangePct(NumberUtil.safeDivide(high[i] - low[i], open[i]));
            b.setVolumeRatio5(volMa5[i] == 0 ? null : NumberUtil.safeDivide(volume[i], volMa5[i]));
            b.setMaShort(nullIfNaN(maShort[i]));
            b.setMaLong(nullIfNaN(maLong[i]));
            b.setMaGapShortLong(NumberUtil.safeDivide(maShort[i] - maLong[i], maLong[i]));
            b.setRsi(nullIfNaN(rsi[i]));
            b.setMacd(nullIfNaN(macd[i]));
            b.setMacdSignal(nullIfNaN(macdSignal[i]));
            b.setMacdHist(nullIfNaN(macd[i] - macdSignal[i]));
            b.setKdK(nullIfNaN(kdK[i]));
            b.setKdD(nullIfNaN(kdD[i]));
            b.setKdJ(nullIfNaN(3 * kdK[i] - 2 * kdD[i]));

            double upper = Double.NaN;
            double lower = Double.NaN;
            if (!Double.isNaN(bbMid[i]) && !Double.isNaN(bbStd[i])) {
                upper = bbMid[i] + bbStdMult * bbStd[i];
                lower = bbMid[i] - bbStdMult * bbStd[i];
            }
            b.setBbMid(nullIfNaN(bbMid[i]));
            b.setBbUpper(nullIfNaN(upper));
            b.setBbLower(nullIfNaN(lower));
            b.setBbWidth(NumberUtil.safeDivide(upper - lower, bbMid[i]));
            b.setBbPosition(NumberUtil.safeDivide(close[i] - lower, upper - lower));

            if (i + futureDays < n) {
                Double futureReturn = NumberUtil.safeDivide(close[i + futureDays] - close[i], close[i]);
                b.setProfit(futureReturn == null ? null : futureReturn * 100.0);
            } else {
                b.setProfit(null);
            }
        }
        return data;
    }

    private double[] sma(double[] values, int period) {
        double[] out = new double[values.length];
        double sum = 0;
        for (int i = 0; i < values.length; i++) {
            sum += values[i];
            if (i >= period) sum -= values[i - period];
            out[i] = i >= period - 1 ? sum / period : Double.NaN;
        }
        return out;
    }

    private double[] rollingStd(double[] values, int period) {
        double[] out = new double[values.length];
        for (int i = 0; i < values.length; i++) {
            if (i < period - 1) { out[i] = Double.NaN; continue; }
            double sum = 0;
            for (int j = i - period + 1; j <= i; j++) sum += values[j];
            double mean = sum / period;
            double sq = 0;
            for (int j = i - period + 1; j <= i; j++) sq += Math.pow(values[j] - mean, 2);
            out[i] = Math.sqrt(sq / period);
        }
        return out;
    }

    private double[] ema(double[] values, int period) {
        double alpha = 2.0 / (period + 1.0);
        return emaWithAlpha(values, alpha);
    }

    private double[] emaWithAlpha(double[] values, double alpha) {
        double[] out = new double[values.length];
        if (values.length == 0) return out;
        out[0] = values[0];
        for (int i = 1; i < values.length; i++) {
            double v = Double.isNaN(values[i]) ? out[i - 1] : values[i];
            out[i] = alpha * v + (1.0 - alpha) * out[i - 1];
        }
        return out;
    }

    private double[] rsi(double[] close, int period) {
        double[] out = new double[close.length];
        for (int i = 0; i < out.length; i++) out[i] = Double.NaN;
        if (close.length <= period) return out;
        double gain = 0;
        double loss = 0;
        for (int i = 1; i <= period; i++) {
            double diff = close[i] - close[i - 1];
            if (diff >= 0) gain += diff; else loss -= diff;
        }
        double avgGain = gain / period;
        double avgLoss = loss / period;
        out[period] = calcRsi(avgGain, avgLoss);
        for (int i = period + 1; i < close.length; i++) {
            double diff = close[i] - close[i - 1];
            double g = Math.max(diff, 0);
            double l = Math.max(-diff, 0);
            avgGain = (avgGain * (period - 1) + g) / period;
            avgLoss = (avgLoss * (period - 1) + l) / period;
            out[i] = calcRsi(avgGain, avgLoss);
        }
        return out;
    }

    private double calcRsi(double avgGain, double avgLoss) {
        if (avgLoss == 0 && avgGain == 0) return 50;
        if (avgLoss == 0) return 100;
        double rs = avgGain / avgLoss;
        return 100.0 - 100.0 / (1.0 + rs);
    }

    private double[] stochasticK(double[] close, double[] high, double[] low, int period) {
        double[] rsv = new double[close.length];
        for (int i = 0; i < close.length; i++) {
            if (i < period - 1) { rsv[i] = Double.NaN; continue; }
            double hh = -Double.MAX_VALUE;
            double ll = Double.MAX_VALUE;
            for (int j = i - period + 1; j <= i; j++) {
                hh = Math.max(hh, high[j]);
                ll = Math.min(ll, low[j]);
            }
            rsv[i] = hh == ll ? 50 : (close[i] - ll) / (hh - ll) * 100.0;
        }
        return emaWithAlpha(rsv, 1.0 / 3.0);
    }

    private Double nullIfNaN(double v) {
        return Double.isFinite(v) ? v : null;
    }
}
