package com.codebyx.trading.dto;

import java.util.List;

public record BacktestResultDto(
        String strategy,
        List<MetricDto> metrics,
        List<BacktestPointDto> points
) {}
