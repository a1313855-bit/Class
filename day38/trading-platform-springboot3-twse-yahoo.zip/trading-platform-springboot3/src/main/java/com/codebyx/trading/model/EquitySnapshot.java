package com.codebyx.trading.model;

import jakarta.persistence.*;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Entity
@Table(name = "equity_snapshots")
public class EquitySnapshot {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private Long accountId;
    private String symbol;
    private LocalDate snapshotDate;
    private Double closePrice;
    private Double cash;
    private Double positionQty;
    private Double positionValue;
    private Double realizedPnl;
    private Double unrealizedPnl;
    private Double equity;
    private LocalDateTime createdAt;

    public EquitySnapshot() {}

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public Long getAccountId() { return accountId; }
    public void setAccountId(Long accountId) { this.accountId = accountId; }
    public String getSymbol() { return symbol; }
    public void setSymbol(String symbol) { this.symbol = symbol; }
    public LocalDate getSnapshotDate() { return snapshotDate; }
    public void setSnapshotDate(LocalDate snapshotDate) { this.snapshotDate = snapshotDate; }
    public Double getClosePrice() { return closePrice; }
    public void setClosePrice(Double closePrice) { this.closePrice = closePrice; }
    public Double getCash() { return cash; }
    public void setCash(Double cash) { this.cash = cash; }
    public Double getPositionQty() { return positionQty; }
    public void setPositionQty(Double positionQty) { this.positionQty = positionQty; }
    public Double getPositionValue() { return positionValue; }
    public void setPositionValue(Double positionValue) { this.positionValue = positionValue; }
    public Double getRealizedPnl() { return realizedPnl; }
    public void setRealizedPnl(Double realizedPnl) { this.realizedPnl = realizedPnl; }
    public Double getUnrealizedPnl() { return unrealizedPnl; }
    public void setUnrealizedPnl(Double unrealizedPnl) { this.unrealizedPnl = unrealizedPnl; }
    public Double getEquity() { return equity; }
    public void setEquity(Double equity) { this.equity = equity; }
    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }
}
