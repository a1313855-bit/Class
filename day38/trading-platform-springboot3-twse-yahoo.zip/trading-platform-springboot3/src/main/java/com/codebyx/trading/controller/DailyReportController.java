package com.codebyx.trading.controller;

import com.codebyx.trading.dto.ApiResponse;
import com.codebyx.trading.service.DailyReportService;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/report")
@CrossOrigin
public class DailyReportController {
    private final DailyReportService dailyReportService;

    public DailyReportController(DailyReportService dailyReportService) {
        this.dailyReportService = dailyReportService;
    }

    @GetMapping("/daily")
    public ApiResponse daily(@RequestParam(defaultValue = "DEMO") String symbol,
                             @RequestParam(defaultValue = "盤前 + 盤後") String reportType) {
        return ApiResponse.ok("daily report", dailyReportService.generate(symbol, reportType));
    }
}
