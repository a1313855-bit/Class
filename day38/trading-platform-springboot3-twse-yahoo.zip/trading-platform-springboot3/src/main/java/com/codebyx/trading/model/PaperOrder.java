package com.codebyx.trading.model;

import jakarta.persistence.*;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Entity
@Table(name = "paper_orders")
public class PaperOrder {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private Long accountId;
    private String symbol;
    private LocalDate tradeDate;
    private String side;
    private Double price;
    private Double quantity;
    private Double fee;
    private Double slippage;
    private Double realizedPnl;
    private Double cashAfter;
    private Double positionAfter;
    private Double avgPriceAfter;
    private Double equityAfter;
    private LocalDateTime createdAt;

    public PaperOrder() {}

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public Long getAccountId() { return accountId; }
    public void setAccountId(Long accountId) { this.accountId = accountId; }
    public String getSymbol() { return symbol; }
    public void setSymbol(String symbol) { this.symbol = symbol; }
    public LocalDate getTradeDate() { return tradeDate; }
    public void setTradeDate(LocalDate tradeDate) { this.tradeDate = tradeDate; }
    public String getSide() { return side; }
    public void setSide(String side) { this.side = side; }
    public Double getPrice() { return price; }
    public void setPrice(Double price) { this.price = price; }
    public Double getQuantity() { return quantity; }
    public void setQuantity(Double quantity) { this.quantity = quantity; }
    public Double getFee() { return fee; }
    public void setFee(Double fee) { this.fee = fee; }
    public Double getSlippage() { return slippage; }
    public void setSlippage(Double slippage) { this.slippage = slippage; }
    public Double getRealizedPnl() { return realizedPnl; }
    public void setRealizedPnl(Double realizedPnl) { this.realizedPnl = realizedPnl; }
    public Double getCashAfter() { return cashAfter; }
    public void setCashAfter(Double cashAfter) { this.cashAfter = cashAfter; }
    public Double getPositionAfter() { return positionAfter; }
    public void setPositionAfter(Double positionAfter) { this.positionAfter = positionAfter; }
    public Double getAvgPriceAfter() { return avgPriceAfter; }
    public void setAvgPriceAfter(Double avgPriceAfter) { this.avgPriceAfter = avgPriceAfter; }
    public Double getEquityAfter() { return equityAfter; }
    public void setEquityAfter(Double equityAfter) { this.equityAfter = equityAfter; }
    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }
}
