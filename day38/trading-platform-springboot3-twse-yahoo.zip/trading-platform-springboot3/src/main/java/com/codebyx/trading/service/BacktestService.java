package com.codebyx.trading.service;

import com.codebyx.trading.dto.BacktestPointDto;
import com.codebyx.trading.dto.BacktestResultDto;
import com.codebyx.trading.dto.MetricDto;
import com.codebyx.trading.model.MarketBar;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class BacktestService {
    private final MarketDataService marketDataService;

    public BacktestService(MarketDataService marketDataService) {
        this.marketDataService = marketDataService;
    }

    public BacktestResultDto run(String symbol, String strategy, double initialCapital, double feeRatePct, double slippageRatePct, boolean allowShort) {
        List<MarketBar> bars = marketDataService.findBars(symbol, 0);
        if (bars.size() < 50) throw new IllegalArgumentException("行情資料不足，至少需要 50 筆以上。請先產生範例資料。");

        double feeCost = (feeRatePct + slippageRatePct) / 100.0;
        List<BacktestPointDto> points = new ArrayList<>();
        double equity = initialCapital;
        double buyHold = initialCapital;
        double peak = initialCapital;
        int previousPosition = 0;
        double totalCost = 0;
        int trades = 0;
        List<Double> returns = new ArrayList<>();

        for (int i = 0; i < bars.size(); i++) {
            MarketBar b = bars.get(i);
            int signal = signal(b, strategy, allowShort);
            int position = i == 0 ? 0 : signal(bars.get(i - 1), strategy, allowShort); // 延遲一天執行，避免未來函數
            double marketReturn = 0;
            if (i > 0 && bars.get(i - 1).getClosePrice() != null && bars.get(i - 1).getClosePrice() != 0) {
                marketReturn = (b.getClosePrice() - bars.get(i - 1).getClosePrice()) / bars.get(i - 1).getClosePrice();
            }
            double costRate = 0;
            if (position != previousPosition) {
                costRate = Math.abs(position - previousPosition) * feeCost;
                trades++;
            }
            double strategyReturn = position * marketReturn - costRate;
            equity = equity * (1 + strategyReturn);
            buyHold = buyHold * (1 + marketReturn);
            peak = Math.max(peak, equity);
            double drawdownPct = equity / peak - 1;
            totalCost += costRate * initialCapital;
            returns.add(strategyReturn);
            previousPosition = position;

            points.add(new BacktestPointDto(
                    b.getBarDate(), b.getClosePrice(), signal, position,
                    marketReturn, strategyReturn, equity, buyHold, drawdownPct
            ));
        }

        double totalReturn = equity / initialCapital - 1;
        double buyHoldReturn = buyHold / initialCapital - 1;
        double maxDd = points.stream().mapToDouble(BacktestPointDto::drawdownPct).min().orElse(0);
        double exposure = points.stream().filter(p -> p.position() != 0).count() * 1.0 / points.size();
        double volatility = std(returns) * Math.sqrt(252);
        double annualReturn = Math.pow(1 + totalReturn, 252.0 / Math.max(points.size(), 1)) - 1;
        Double sharpe = volatility == 0 ? null : annualReturn / volatility;
        long positiveDays = points.stream().filter(p -> p.position() != 0 && p.strategyReturn() > 0).count();
        long activeDays = points.stream().filter(p -> p.position() != 0).count();
        Double winRate = activeDays == 0 ? null : positiveDays * 1.0 / activeDays;

        List<MetricDto> metrics = List.of(
                new MetricDto("期末資金", NumberUtil.num(equity), "回測期結束後的策略資金。"),
                new MetricDto("策略總報酬", NumberUtil.pct(totalReturn), "策略期末資金 / 初始資金 - 1。"),
                new MetricDto("買進持有報酬", NumberUtil.pct(buyHoldReturn), "同期間單純持有標的的報酬。"),
                new MetricDto("年化報酬", NumberUtil.pct(annualReturn), "將回測期間報酬換算成年化。"),
                new MetricDto("年化波動", NumberUtil.pct(volatility), "策略每日報酬的年化標準差。"),
                new MetricDto("Sharpe Ratio", NumberUtil.num(sharpe), "年化報酬 / 年化波動，未扣無風險利率。"),
                new MetricDto("最大回撤", NumberUtil.pct(maxDd), "資金曲線從高點回落的最大比例。"),
                new MetricDto("日勝率", NumberUtil.pct(winRate), "有持倉的交易日中，策略日報酬為正的比例。"),
                new MetricDto("曝險比例", NumberUtil.pct(exposure), "有持倉天數 / 全部回測天數。"),
                new MetricDto("交易次數", String.valueOf(trades), "部位變化次數，含進場、出場與多空反轉。"),
                new MetricDto("估計交易成本", NumberUtil.num(totalCost), "依手續費與滑價估算的總成本。")
        );

        return new BacktestResultDto(strategy, metrics, points);
    }

    private int signal(MarketBar b, String strategy, boolean allowShort) {
        String s = strategy == null ? "MA" : strategy;
        boolean longCond;
        boolean shortCond;
        switch (s) {
            case "MACD" -> {
                longCond = NumberUtil.nvl(b.getMacd()) > NumberUtil.nvl(b.getMacdSignal());
                shortCond = NumberUtil.nvl(b.getMacd()) < NumberUtil.nvl(b.getMacdSignal());
            }
            case "RSI" -> {
                if (b.getRsi() == null) return 0;
                if (b.getRsi() <= 30) return 1;
                if (b.getRsi() >= 70) return allowShort ? -1 : 0;
                return 0;
            }
            case "KD" -> {
                longCond = NumberUtil.nvl(b.getKdK()) > NumberUtil.nvl(b.getKdD());
                shortCond = NumberUtil.nvl(b.getKdK()) < NumberUtil.nvl(b.getKdD());
            }
            case "BOLLINGER" -> {
                if (b.getBbPosition() == null) return 0;
                if (b.getBbPosition() <= 0.15) return 1;
                if (b.getBbPosition() >= 0.85) return allowShort ? -1 : 0;
                return 0;
            }
            default -> {
                longCond = NumberUtil.nvl(b.getMaShort()) > NumberUtil.nvl(b.getMaLong());
                shortCond = NumberUtil.nvl(b.getMaShort()) < NumberUtil.nvl(b.getMaLong());
            }
        }
        if (longCond) return 1;
        if (allowShort && shortCond) return -1;
        return 0;
    }

    private double std(List<Double> values) {
        if (values.size() < 2) return 0;
        double mean = values.stream().mapToDouble(Double::doubleValue).average().orElse(0);
        double sum = values.stream().mapToDouble(v -> Math.pow(v - mean, 2)).sum();
        return Math.sqrt(sum / (values.size() - 1));
    }
}
