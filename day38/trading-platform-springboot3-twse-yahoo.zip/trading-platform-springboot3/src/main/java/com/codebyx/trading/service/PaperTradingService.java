package com.codebyx.trading.service;

import com.codebyx.trading.dao.EquitySnapshotRepository;
import com.codebyx.trading.dao.PaperAccountRepository;
import com.codebyx.trading.dao.PaperOrderRepository;
import com.codebyx.trading.dto.OrderRequest;
import com.codebyx.trading.dto.PaperStateDto;
import com.codebyx.trading.model.EquitySnapshot;
import com.codebyx.trading.model.MarketBar;
import com.codebyx.trading.model.PaperAccount;
import com.codebyx.trading.model.PaperOrder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

@Service
public class PaperTradingService {
    private static final String DEFAULT_ACCOUNT_NAME = "DEMO_ACCOUNT";

    private final PaperAccountRepository accountRepository;
    private final PaperOrderRepository orderRepository;
    private final EquitySnapshotRepository snapshotRepository;
    private final MarketDataService marketDataService;

    public PaperTradingService(PaperAccountRepository accountRepository,
                               PaperOrderRepository orderRepository,
                               EquitySnapshotRepository snapshotRepository,
                               MarketDataService marketDataService) {
        this.accountRepository = accountRepository;
        this.orderRepository = orderRepository;
        this.snapshotRepository = snapshotRepository;
        this.marketDataService = marketDataService;
    }

    @Transactional
    public PaperAccount reset(String symbol, double initialCapital) {
        PaperAccount account = accountRepository.findByName(DEFAULT_ACCOUNT_NAME).orElseGet(PaperAccount::new);
        if (account.getId() != null) {
            orderRepository.deleteByAccountId(account.getId());
            snapshotRepository.deleteByAccountId(account.getId());
        }
        account.setName(DEFAULT_ACCOUNT_NAME);
        account.setSymbol(cleanSymbol(symbol));
        account.setInitialCapital(initialCapital);
        account.setCash(initialCapital);
        account.setPositionQty(0.0);
        account.setAvgPrice(0.0);
        account.setRealizedPnl(0.0);
        account.setCreatedAt(account.getCreatedAt() == null ? LocalDateTime.now() : account.getCreatedAt());
        account.setUpdatedAt(LocalDateTime.now());
        return accountRepository.save(account);
    }

    public PaperAccount account(String symbol) {
        return accountRepository.findByName(DEFAULT_ACCOUNT_NAME)
                .orElseGet(() -> reset(symbol, 100000.0));
    }

    public PaperStateDto state(String symbol, LocalDate date) {
        PaperAccount account = account(symbol);
        MarketBar bar = marketDataService.findBarOnOrBefore(cleanSymbol(symbol), date == null ? LocalDate.now() : date);
        return buildState(account, bar);
    }

    @Transactional
    public PaperOrder placeOrder(OrderRequest req) {
        String symbol = cleanSymbol(req.getSymbol());
        PaperAccount account = account(symbol);
        if (!symbol.equalsIgnoreCase(account.getSymbol())) {
            account = reset(symbol, NumberUtil.nvl(account.getInitialCapital()) == 0 ? 100000.0 : account.getInitialCapital());
        }
        MarketBar bar = marketDataService.findBarOnOrBefore(symbol, req.getTradeDate());
        double marketPrice = NumberUtil.nvl(bar.getClosePrice());
        double price = req.getPriceOverride() != null && req.getPriceOverride() > 0 ? req.getPriceOverride() : marketPrice;
        double qty = Math.abs(NumberUtil.nvl(req.getQuantity()));
        if (qty <= 0) throw new IllegalArgumentException("交易數量必須大於 0。 ");
        double multiplier = req.getMultiplier() == null || req.getMultiplier() <= 0 ? 1.0 : req.getMultiplier();
        double notional = price * qty * multiplier;
        double fee = notional * NumberUtil.nvl(req.getFeeRatePct()) / 100.0;
        double slippage = notional * NumberUtil.nvl(req.getSlippageRatePct()) / 100.0;
        double cost = fee + slippage;

        String side = req.getSide().trim().toUpperCase();
        double oldQty = NumberUtil.nvl(account.getPositionQty());
        double oldAvg = NumberUtil.nvl(account.getAvgPrice());
        double cash = NumberUtil.nvl(account.getCash());
        double realized = 0.0;
        double newQty = oldQty;
        double newAvg = oldAvg;

        switch (side) {
            case "BUY" -> {
                cash -= notional + cost;
                if (oldQty >= 0) {
                    newQty = oldQty + qty;
                    newAvg = newQty == 0 ? 0 : ((oldAvg * oldQty) + price * qty) / newQty;
                } else {
                    double closingQty = Math.min(qty, Math.abs(oldQty));
                    realized += (oldAvg - price) * closingQty * multiplier;
                    newQty = oldQty + qty;
                    newAvg = newQty < 0 ? oldAvg : (newQty > 0 ? price : 0);
                }
            }
            case "SELL" -> {
                cash += notional - cost;
                if (oldQty <= 0) throw new IllegalArgumentException("目前沒有多單可平倉。若要放空請選 SHORT。 ");
                double closingQty = Math.min(qty, oldQty);
                realized += (price - oldAvg) * closingQty * multiplier;
                newQty = oldQty - qty;
                if (newQty < 0) throw new IllegalArgumentException("賣出數量不可大於目前多單持倉。 ");
                newAvg = newQty == 0 ? 0 : oldAvg;
            }
            case "SHORT" -> {
                cash += notional - cost;
                if (oldQty <= 0) {
                    newQty = oldQty - qty;
                    newAvg = newQty == 0 ? 0 : ((oldAvg * Math.abs(oldQty)) + price * qty) / Math.abs(newQty);
                } else {
                    double closingQty = Math.min(qty, oldQty);
                    realized += (price - oldAvg) * closingQty * multiplier;
                    newQty = oldQty - qty;
                    newAvg = newQty > 0 ? oldAvg : (newQty < 0 ? price : 0);
                }
            }
            case "COVER" -> {
                cash -= notional + cost;
                if (oldQty >= 0) throw new IllegalArgumentException("目前沒有空單可回補。 ");
                double closingQty = Math.min(qty, Math.abs(oldQty));
                realized += (oldAvg - price) * closingQty * multiplier;
                newQty = oldQty + qty;
                if (newQty > 0) throw new IllegalArgumentException("回補數量不可大於目前空單持倉。 ");
                newAvg = newQty == 0 ? 0 : oldAvg;
            }
            default -> throw new IllegalArgumentException("side 僅支援 BUY、SELL、SHORT、COVER。 ");
        }

        account.setCash(cash);
        account.setPositionQty(newQty);
        account.setAvgPrice(newAvg);
        account.setRealizedPnl(NumberUtil.nvl(account.getRealizedPnl()) + realized - cost);
        account.setUpdatedAt(LocalDateTime.now());
        accountRepository.save(account);

        double equity = calcEquity(account, price, multiplier);
        PaperOrder order = new PaperOrder();
        order.setAccountId(account.getId());
        order.setSymbol(symbol);
        order.setTradeDate(bar.getBarDate());
        order.setSide(side);
        order.setPrice(price);
        order.setQuantity(qty);
        order.setFee(fee);
        order.setSlippage(slippage);
        order.setRealizedPnl(realized - cost);
        order.setCashAfter(account.getCash());
        order.setPositionAfter(account.getPositionQty());
        order.setAvgPriceAfter(account.getAvgPrice());
        order.setEquityAfter(equity);
        order.setCreatedAt(LocalDateTime.now());
        PaperOrder saved = orderRepository.save(order);
        saveSnapshot(account, bar, multiplier);
        return saved;
    }

    public List<PaperOrder> orders() {
        PaperAccount account = account("DEMO");
        return orderRepository.findByAccountIdOrderByTradeDateAscIdAsc(account.getId());
    }

    public List<EquitySnapshot> equityCurve() {
        PaperAccount account = account("DEMO");
        return snapshotRepository.findByAccountIdOrderBySnapshotDateAscIdAsc(account.getId());
    }

    private PaperStateDto buildState(PaperAccount account, MarketBar bar) {
        double price = NumberUtil.nvl(bar.getClosePrice());
        double qty = NumberUtil.nvl(account.getPositionQty());
        double positionValue = qty * price;
        double unrealized = 0;
        if (qty > 0) unrealized = (price - NumberUtil.nvl(account.getAvgPrice())) * qty;
        if (qty < 0) unrealized = (NumberUtil.nvl(account.getAvgPrice()) - price) * Math.abs(qty);
        double equity = NumberUtil.nvl(account.getCash()) + positionValue;
        double totalReturnPct = NumberUtil.nvl(account.getInitialCapital()) == 0 ? 0 : equity / account.getInitialCapital() - 1;
        return new PaperStateDto(account, bar.getBarDate(), price, positionValue, unrealized, equity, totalReturnPct);
    }

    private double calcEquity(PaperAccount account, double price, double multiplier) {
        return NumberUtil.nvl(account.getCash()) + NumberUtil.nvl(account.getPositionQty()) * price * multiplier;
    }

    private void saveSnapshot(PaperAccount account, MarketBar bar, double multiplier) {
        double price = NumberUtil.nvl(bar.getClosePrice());
        EquitySnapshot s = new EquitySnapshot();
        s.setAccountId(account.getId());
        s.setSymbol(account.getSymbol());
        s.setSnapshotDate(bar.getBarDate());
        s.setClosePrice(price);
        s.setCash(account.getCash());
        s.setPositionQty(account.getPositionQty());
        s.setPositionValue(NumberUtil.nvl(account.getPositionQty()) * price * multiplier);
        s.setRealizedPnl(account.getRealizedPnl());
        double unrealized = 0;
        if (NumberUtil.nvl(account.getPositionQty()) > 0) unrealized = (price - NumberUtil.nvl(account.getAvgPrice())) * account.getPositionQty() * multiplier;
        if (NumberUtil.nvl(account.getPositionQty()) < 0) unrealized = (NumberUtil.nvl(account.getAvgPrice()) - price) * Math.abs(account.getPositionQty()) * multiplier;
        s.setUnrealizedPnl(unrealized);
        s.setEquity(calcEquity(account, price, multiplier));
        s.setCreatedAt(LocalDateTime.now());
        snapshotRepository.save(s);
    }

    private String cleanSymbol(String symbol) {
        return symbol == null || symbol.isBlank() ? "DEMO" : symbol.trim().toUpperCase();
    }
}
