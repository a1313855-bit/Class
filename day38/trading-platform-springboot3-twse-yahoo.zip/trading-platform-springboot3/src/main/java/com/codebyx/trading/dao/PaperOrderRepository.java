package com.codebyx.trading.dao;

import com.codebyx.trading.model.PaperOrder;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface PaperOrderRepository extends JpaRepository<PaperOrder, Long> {
    List<PaperOrder> findByAccountIdOrderByTradeDateAscIdAsc(Long accountId);
    void deleteByAccountId(Long accountId);
}
