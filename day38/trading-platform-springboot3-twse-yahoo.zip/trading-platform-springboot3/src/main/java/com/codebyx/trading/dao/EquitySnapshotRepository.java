package com.codebyx.trading.dao;

import com.codebyx.trading.model.EquitySnapshot;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface EquitySnapshotRepository extends JpaRepository<EquitySnapshot, Long> {
    List<EquitySnapshot> findByAccountIdOrderBySnapshotDateAscIdAsc(Long accountId);
    void deleteByAccountId(Long accountId);
}
