package com.codebyx.trading.model;

import jakarta.persistence.*;
import java.time.LocalDate;

@Entity
@Table(name = "market_bars", uniqueConstraints = {
        @UniqueConstraint(name = "uk_symbol_bar_date", columnNames = {"symbol", "bar_date"})
})
public class MarketBar {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, length = 40)
    private String symbol = "DEMO";

    @Column(name = "bar_date", nullable = false)
    private LocalDate barDate;

    @Column(name = "open_price")
    private Double openPrice;
    @Column(name = "high_price")
    private Double highPrice;
    @Column(name = "low_price")
    private Double lowPrice;
    @Column(name = "close_price")
    private Double closePrice;
    private Long volume;

    @Column(name = "data_source", length = 30)
    private String dataSource = "SYSTEM";

    @Column(name = "source_symbol", length = 60)
    private String sourceSymbol = "DEMO";

    private Double return1d;
    private Double return5d;
    private Double bodyPct;
    private Double rangePct;
    private Double volumeRatio5;
    private Double maShort;
    private Double maLong;
    private Double maGapShortLong;
    private Double rsi;
    private Double macd;
    private Double macdSignal;
    private Double macdHist;
    private Double kdK;
    private Double kdD;
    private Double kdJ;
    private Double bbMid;
    private Double bbUpper;
    private Double bbLower;
    private Double bbPosition;
    private Double bbWidth;
    private Double profit;

    public MarketBar() {}

    public MarketBar(String symbol, LocalDate barDate, Double openPrice, Double highPrice, Double lowPrice, Double closePrice, Long volume) {
        this.symbol = symbol;
        this.barDate = barDate;
        this.openPrice = openPrice;
        this.highPrice = highPrice;
        this.lowPrice = lowPrice;
        this.closePrice = closePrice;
        this.volume = volume;
    }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public String getSymbol() { return symbol; }
    public void setSymbol(String symbol) { this.symbol = symbol; }
    public LocalDate getBarDate() { return barDate; }
    public void setBarDate(LocalDate barDate) { this.barDate = barDate; }
    public Double getOpenPrice() { return openPrice; }
    public void setOpenPrice(Double openPrice) { this.openPrice = openPrice; }
    public Double getHighPrice() { return highPrice; }
    public void setHighPrice(Double highPrice) { this.highPrice = highPrice; }
    public Double getLowPrice() { return lowPrice; }
    public void setLowPrice(Double lowPrice) { this.lowPrice = lowPrice; }
    public Double getClosePrice() { return closePrice; }
    public void setClosePrice(Double closePrice) { this.closePrice = closePrice; }
    public Long getVolume() { return volume; }
    public void setVolume(Long volume) { this.volume = volume; }
    public String getDataSource() { return dataSource; }
    public void setDataSource(String dataSource) { this.dataSource = dataSource; }
    public String getSourceSymbol() { return sourceSymbol; }
    public void setSourceSymbol(String sourceSymbol) { this.sourceSymbol = sourceSymbol; }
    public Double getReturn1d() { return return1d; }
    public void setReturn1d(Double return1d) { this.return1d = return1d; }
    public Double getReturn5d() { return return5d; }
    public void setReturn5d(Double return5d) { this.return5d = return5d; }
    public Double getBodyPct() { return bodyPct; }
    public void setBodyPct(Double bodyPct) { this.bodyPct = bodyPct; }
    public Double getRangePct() { return rangePct; }
    public void setRangePct(Double rangePct) { this.rangePct = rangePct; }
    public Double getVolumeRatio5() { return volumeRatio5; }
    public void setVolumeRatio5(Double volumeRatio5) { this.volumeRatio5 = volumeRatio5; }
    public Double getMaShort() { return maShort; }
    public void setMaShort(Double maShort) { this.maShort = maShort; }
    public Double getMaLong() { return maLong; }
    public void setMaLong(Double maLong) { this.maLong = maLong; }
    public Double getMaGapShortLong() { return maGapShortLong; }
    public void setMaGapShortLong(Double maGapShortLong) { this.maGapShortLong = maGapShortLong; }
    public Double getRsi() { return rsi; }
    public void setRsi(Double rsi) { this.rsi = rsi; }
    public Double getMacd() { return macd; }
    public void setMacd(Double macd) { this.macd = macd; }
    public Double getMacdSignal() { return macdSignal; }
    public void setMacdSignal(Double macdSignal) { this.macdSignal = macdSignal; }
    public Double getMacdHist() { return macdHist; }
    public void setMacdHist(Double macdHist) { this.macdHist = macdHist; }
    public Double getKdK() { return kdK; }
    public void setKdK(Double kdK) { this.kdK = kdK; }
    public Double getKdD() { return kdD; }
    public void setKdD(Double kdD) { this.kdD = kdD; }
    public Double getKdJ() { return kdJ; }
    public void setKdJ(Double kdJ) { this.kdJ = kdJ; }
    public Double getBbMid() { return bbMid; }
    public void setBbMid(Double bbMid) { this.bbMid = bbMid; }
    public Double getBbUpper() { return bbUpper; }
    public void setBbUpper(Double bbUpper) { this.bbUpper = bbUpper; }
    public Double getBbLower() { return bbLower; }
    public void setBbLower(Double bbLower) { this.bbLower = bbLower; }
    public Double getBbPosition() { return bbPosition; }
    public void setBbPosition(Double bbPosition) { this.bbPosition = bbPosition; }
    public Double getBbWidth() { return bbWidth; }
    public void setBbWidth(Double bbWidth) { this.bbWidth = bbWidth; }
    public Double getProfit() { return profit; }
    public void setProfit(Double profit) { this.profit = profit; }
}
