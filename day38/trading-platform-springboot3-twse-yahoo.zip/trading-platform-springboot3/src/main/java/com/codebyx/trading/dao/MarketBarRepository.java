package com.codebyx.trading.dao;

import com.codebyx.trading.model.MarketBar;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

public interface MarketBarRepository extends JpaRepository<MarketBar, Long> {
    List<MarketBar> findBySymbolOrderByBarDateAsc(String symbol);
    List<MarketBar> findBySymbolOrderByBarDateDesc(String symbol, Pageable pageable);
    Optional<MarketBar> findFirstBySymbolOrderByBarDateDesc(String symbol);
    Optional<MarketBar> findFirstBySymbolAndBarDateLessThanEqualOrderByBarDateDesc(String symbol, LocalDate barDate);
    void deleteBySymbol(String symbol);

    @Query("select distinct m.symbol from MarketBar m order by m.symbol")
    List<String> findAllSymbols();
}
