package com.codebyx.trading.dto;

import com.codebyx.trading.model.PaperAccount;
import java.time.LocalDate;

public record PaperStateDto(
        PaperAccount account,
        LocalDate marketDate,
        Double closePrice,
        Double positionValue,
        Double unrealizedPnl,
        Double equity,
        Double totalReturnPct
) {}
