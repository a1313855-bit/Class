package com.codebyx.trading.service;

import com.codebyx.trading.dao.MarketBarRepository;
import com.codebyx.trading.model.MarketBar;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.io.IOException;
import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Instant;
import java.time.LocalDate;
import java.time.YearMonth;
import java.time.ZoneId;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@Service
public class ExternalMarketDataService {
    private static final DateTimeFormatter TWSE_MONTH_PARAM = DateTimeFormatter.ofPattern("yyyyMM01");

    private final MarketBarRepository marketBarRepository;
    private final IndicatorService indicatorService;
    private final ObjectMapper objectMapper;
    private final HttpClient httpClient;

    public ExternalMarketDataService(MarketBarRepository marketBarRepository,
                                     IndicatorService indicatorService,
                                     ObjectMapper objectMapper) {
        this.marketBarRepository = marketBarRepository;
        this.indicatorService = indicatorService;
        this.objectMapper = objectMapper;
        this.httpClient = HttpClient.newBuilder()
                .connectTimeout(java.time.Duration.ofSeconds(20))
                .followRedirects(HttpClient.Redirect.NORMAL)
                .build();
    }

    @Transactional
    public List<MarketBar> fetchTwseStockDay(String targetSymbol, String stockNo, YearMonth startMonth, YearMonth endMonth) {
        String saveSymbol = cleanSymbol(targetSymbol == null || targetSymbol.isBlank() ? stockNo + ".TW" : targetSymbol);
        String code = stockNo == null ? "" : stockNo.trim();
        if (code.isBlank()) throw new IllegalArgumentException("TWSE 股票代號不可空白，例如 2330。 ");
        if (startMonth == null || endMonth == null) throw new IllegalArgumentException("請輸入開始月份與結束月份。 ");
        if (endMonth.isBefore(startMonth)) throw new IllegalArgumentException("結束月份不可早於開始月份。 ");

        List<MarketBar> rows = new ArrayList<>();
        YearMonth cursor = startMonth;
        while (!cursor.isAfter(endMonth)) {
            rows.addAll(fetchTwseOneMonth(saveSymbol, code, cursor));
            cursor = cursor.plusMonths(1);
        }
        if (rows.isEmpty()) throw new IllegalArgumentException("TWSE 沒有回傳可用資料，請確認股票代號與月份。 ");
        rows.sort(Comparator.comparing(MarketBar::getBarDate));
        rows = mergeSameDate(rows);
        rows = indicatorService.addFeatures(rows, 5, 5, 20, 14, 12, 26, 9, 9, 20, 2.0);
        marketBarRepository.deleteBySymbol(saveSymbol);
        return marketBarRepository.saveAll(rows);
    }

    @Transactional
    public List<MarketBar> fetchYahooChart(String targetSymbol, String yahooSymbol, LocalDate startDate, LocalDate endDate, String interval) {
        String sourceSymbol = yahooSymbol == null ? "" : yahooSymbol.trim();
        if (sourceSymbol.isBlank()) throw new IllegalArgumentException("Yahoo Finance 代號不可空白，例如 2330.TW、AAPL、BTC-USD。 ");
        String saveSymbol = cleanSymbol(targetSymbol == null || targetSymbol.isBlank() ? sourceSymbol : targetSymbol);
        LocalDate start = startDate == null ? LocalDate.now().minusYears(2) : startDate;
        LocalDate end = endDate == null ? LocalDate.now() : endDate;
        if (end.isBefore(start)) throw new IllegalArgumentException("結束日期不可早於開始日期。 ");
        String intervalValue = (interval == null || interval.isBlank()) ? "1d" : interval.trim();

        long period1 = start.atStartOfDay(ZoneOffset.UTC).toEpochSecond();
        long period2 = end.plusDays(1).atStartOfDay(ZoneOffset.UTC).toEpochSecond();
        String encodedSymbol = URLEncoder.encode(sourceSymbol, StandardCharsets.UTF_8);
        String url = "https://query1.finance.yahoo.com/v8/finance/chart/" + encodedSymbol
                + "?period1=" + period1
                + "&period2=" + period2
                + "&interval=" + URLEncoder.encode(intervalValue, StandardCharsets.UTF_8)
                + "&events=history&includeAdjustedClose=true";

        JsonNode root = readJson(url);
        JsonNode chart = root.path("chart");
        JsonNode error = chart.path("error");
        if (!error.isMissingNode() && !error.isNull()) {
            throw new IllegalArgumentException("Yahoo Finance 回傳錯誤：" + error.toString());
        }
        JsonNode result = chart.path("result");
        if (!result.isArray() || result.size() == 0) throw new IllegalArgumentException("Yahoo Finance 沒有回傳資料。 ");
        JsonNode item = result.get(0);
        JsonNode timestamps = item.path("timestamp");
        JsonNode quote = item.path("indicators").path("quote").path(0);
        if (!timestamps.isArray() || quote.isMissingNode()) throw new IllegalArgumentException("Yahoo Finance 回傳格式不完整。 ");

        ZoneId marketZone = zoneFromYahooMeta(item.path("meta"));
        JsonNode opens = quote.path("open");
        JsonNode highs = quote.path("high");
        JsonNode lows = quote.path("low");
        JsonNode closes = quote.path("close");
        JsonNode volumes = quote.path("volume");

        List<MarketBar> rows = new ArrayList<>();
        for (int i = 0; i < timestamps.size(); i++) {
            Double open = asNullableDouble(opens.path(i));
            Double high = asNullableDouble(highs.path(i));
            Double low = asNullableDouble(lows.path(i));
            Double close = asNullableDouble(closes.path(i));
            if (open == null || high == null || low == null || close == null) continue;
            long ts = timestamps.path(i).asLong();
            LocalDate date = Instant.ofEpochSecond(ts).atZone(marketZone).toLocalDate();
            Long volume = volumes.path(i).isNumber() ? volumes.path(i).asLong() : 0L;
            MarketBar bar = new MarketBar(saveSymbol, date, open, high, low, close, volume);
            bar.setDataSource("YAHOO");
            bar.setSourceSymbol(sourceSymbol);
            rows.add(bar);
        }
        if (rows.isEmpty()) throw new IllegalArgumentException("Yahoo Finance 沒有可用 OHLCV 資料。 ");
        rows.sort(Comparator.comparing(MarketBar::getBarDate));
        rows = mergeSameDate(rows);
        rows = indicatorService.addFeatures(rows, 5, 5, 20, 14, 12, 26, 9, 9, 20, 2.0);
        marketBarRepository.deleteBySymbol(saveSymbol);
        return marketBarRepository.saveAll(rows);
    }

    private List<MarketBar> fetchTwseOneMonth(String saveSymbol, String stockNo, YearMonth month) {
        String dateParam = month.atDay(1).format(TWSE_MONTH_PARAM);
        List<String> candidates = List.of(
                "https://www.twse.com.tw/rwd/zh/afterTrading/STOCK_DAY?date=" + dateParam + "&stockNo=" + stockNo + "&response=json",
                "https://www.twse.com.tw/exchangeReport/STOCK_DAY?response=json&date=" + dateParam + "&stockNo=" + stockNo
        );
        RuntimeException lastError = null;
        for (String url : candidates) {
            try {
                JsonNode root = readJson(url);
                JsonNode data = root.path("data");
                if (!data.isArray() || data.size() == 0) continue;
                List<MarketBar> bars = new ArrayList<>();
                for (JsonNode row : data) {
                    if (!row.isArray() || row.size() < 7) continue;
                    LocalDate date = parseTwseDate(row.path(0).asText());
                    Double open = parseNumber(row.path(3).asText());
                    Double high = parseNumber(row.path(4).asText());
                    Double low = parseNumber(row.path(5).asText());
                    Double close = parseNumber(row.path(6).asText());
                    Long volume = parseLong(row.path(1).asText());
                    if (date == null || open == null || high == null || low == null || close == null) continue;
                    MarketBar bar = new MarketBar(saveSymbol, date, open, high, low, close, volume == null ? 0L : volume);
                    bar.setDataSource("TWSE");
                    bar.setSourceSymbol(stockNo);
                    bars.add(bar);
                }
                if (!bars.isEmpty()) return bars;
            } catch (RuntimeException ex) {
                lastError = ex;
            }
        }
        if (lastError != null) throw lastError;
        return List.of();
    }

    private JsonNode readJson(String url) {
        HttpRequest request = HttpRequest.newBuilder(URI.create(url))
                .timeout(java.time.Duration.ofSeconds(30))
                .header("Accept", "application/json,text/plain,*/*")
                .header("User-Agent", "Mozilla/5.0 CodeByX-Trading-Platform/1.0")
                .GET()
                .build();
        try {
            HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString(StandardCharsets.UTF_8));
            if (response.statusCode() < 200 || response.statusCode() >= 300) {
                throw new IllegalArgumentException("外部資料讀取失敗 HTTP " + response.statusCode() + "：" + url);
            }
            return objectMapper.readTree(response.body());
        } catch (IOException ex) {
            throw new IllegalArgumentException("外部資料 JSON 解析失敗：" + ex.getMessage(), ex);
        } catch (InterruptedException ex) {
            Thread.currentThread().interrupt();
            throw new IllegalArgumentException("外部資料讀取中斷：" + ex.getMessage(), ex);
        }
    }

    private ZoneId zoneFromYahooMeta(JsonNode meta) {
        if (meta != null && meta.path("gmtoffset").isNumber()) {
            return ZoneOffset.ofTotalSeconds(meta.path("gmtoffset").asInt());
        }
        return ZoneOffset.UTC;
    }

    private List<MarketBar> mergeSameDate(List<MarketBar> rows) {
        Map<LocalDate, MarketBar> map = new LinkedHashMap<>();
        for (MarketBar row : rows) map.put(row.getBarDate(), row);
        return new ArrayList<>(map.values());
    }

    private LocalDate parseTwseDate(String text) {
        if (text == null || text.isBlank()) return null;
        String value = text.trim();
        String[] parts = value.split("/");
        if (parts.length == 3) {
            int year = Integer.parseInt(parts[0].trim());
            if (year < 1911) year += 1911;
            int month = Integer.parseInt(parts[1].trim());
            int day = Integer.parseInt(parts[2].trim());
            return LocalDate.of(year, month, day);
        }
        return LocalDate.parse(value.substring(0, Math.min(value.length(), 10)));
    }

    private Double parseNumber(String text) {
        if (text == null) return null;
        String value = text.replace(",", "").replace("--", "").replace("X", "").trim();
        if (value.isBlank()) return null;
        return Double.parseDouble(value);
    }

    private Long parseLong(String text) {
        Double value = parseNumber(text);
        return value == null ? null : Math.round(value);
    }

    private Double asNullableDouble(JsonNode node) {
        if (node == null || node.isMissingNode() || node.isNull() || !node.isNumber()) return null;
        double value = node.asDouble();
        return Double.isFinite(value) ? value : null;
    }

    private String cleanSymbol(String symbol) {
        return symbol == null || symbol.isBlank() ? "DEMO" : symbol.trim().toUpperCase();
    }
}
