package com.codebyx.trading.dto;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import java.time.LocalDate;

public class OrderRequest {
    @NotBlank
    private String symbol = "DEMO";
    @NotNull
    private LocalDate tradeDate;
    @NotBlank
    private String side;
    @NotNull @Min(1)
    private Double quantity;
    private Double priceOverride;
    private Double feeRatePct = 0.1425;
    private Double slippageRatePct = 0.05;
    private Double multiplier = 1.0;

    public String getSymbol() { return symbol; }
    public void setSymbol(String symbol) { this.symbol = symbol; }
    public LocalDate getTradeDate() { return tradeDate; }
    public void setTradeDate(LocalDate tradeDate) { this.tradeDate = tradeDate; }
    public String getSide() { return side; }
    public void setSide(String side) { this.side = side; }
    public Double getQuantity() { return quantity; }
    public void setQuantity(Double quantity) { this.quantity = quantity; }
    public Double getPriceOverride() { return priceOverride; }
    public void setPriceOverride(Double priceOverride) { this.priceOverride = priceOverride; }
    public Double getFeeRatePct() { return feeRatePct; }
    public void setFeeRatePct(Double feeRatePct) { this.feeRatePct = feeRatePct; }
    public Double getSlippageRatePct() { return slippageRatePct; }
    public void setSlippageRatePct(Double slippageRatePct) { this.slippageRatePct = slippageRatePct; }
    public Double getMultiplier() { return multiplier; }
    public void setMultiplier(Double multiplier) { this.multiplier = multiplier; }
}
