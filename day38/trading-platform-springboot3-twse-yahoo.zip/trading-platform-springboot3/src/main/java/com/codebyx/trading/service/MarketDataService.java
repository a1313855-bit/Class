package com.codebyx.trading.service;

import com.codebyx.trading.dao.MarketBarRepository;
import com.codebyx.trading.dto.CorrelationDto;
import com.codebyx.trading.dto.MetricDto;
import com.codebyx.trading.model.MarketBar;
import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.function.Function;

@Service
public class MarketDataService {
    private final MarketBarRepository marketBarRepository;
    private final IndicatorService indicatorService;

    public MarketDataService(MarketBarRepository marketBarRepository, IndicatorService indicatorService) {
        this.marketBarRepository = marketBarRepository;
        this.indicatorService = indicatorService;
    }

    @Transactional
    public List<MarketBar> generateSample(String symbol, int count) {
        String targetSymbol = cleanSymbol(symbol);
        marketBarRepository.deleteBySymbol(targetSymbol);
        Random random = new Random(42);
        List<MarketBar> rows = new ArrayList<>();
        LocalDate start = LocalDate.now().minusDays(count + 80L);
        double close = 100.0;
        int generated = 0;
        LocalDate date = start;
        while (generated < count) {
            if (date.getDayOfWeek().getValue() <= 5) {
                double ret = 0.0005 + random.nextGaussian() * 0.015;
                double previousClose = close;
                close = close * (1 + ret);
                double open = previousClose * (1 + random.nextGaussian() * 0.003);
                double high = Math.max(open, close) * (1 + Math.abs(random.nextGaussian() * 0.005 + 0.006));
                double low = Math.min(open, close) * (1 - Math.abs(random.nextGaussian() * 0.005 + 0.006));
                long volume = Math.round(Math.exp(12 + random.nextGaussian() * 0.4));
                MarketBar bar = new MarketBar(targetSymbol, date, round(open), round(high), round(low), round(close), volume);
                bar.setDataSource("SAMPLE");
                bar.setSourceSymbol(targetSymbol);
                rows.add(bar);
                generated++;
            }
            date = date.plusDays(1);
        }
        rows = indicatorService.addFeatures(rows, 5, 5, 20, 14, 12, 26, 9, 9, 20, 2.0);
        return marketBarRepository.saveAll(rows);
    }

    @Transactional
    public List<MarketBar> importCsv(String symbol, MultipartFile file) {
        String targetSymbol = cleanSymbol(symbol);
        List<MarketBar> rows = new ArrayList<>();
        try (CSVParser parser = CSVParser.parse(
                new InputStreamReader(file.getInputStream(), StandardCharsets.UTF_8),
                CSVFormat.DEFAULT.builder().setHeader().setSkipHeaderRecord(true).setTrim(true).build())) {
            Map<String, Integer> headers = lowercaseHeaders(parser.getHeaderMap());
            for (CSVRecord record : parser) {
                LocalDate date = parseDate(get(record, headers, "date"));
                double open = parseDouble(get(record, headers, "open"));
                double high = parseDouble(get(record, headers, "high"));
                double low = parseDouble(get(record, headers, "low"));
                double close = parseDouble(get(record, headers, "close"));
                long volume = Math.round(parseDouble(get(record, headers, "volume")));
                MarketBar bar = new MarketBar(targetSymbol, date, open, high, low, close, volume);
                bar.setDataSource("CSV");
                bar.setSourceSymbol(targetSymbol);
                rows.add(bar);
            }
        } catch (Exception ex) {
            throw new IllegalArgumentException("CSV 匯入失敗，請確認欄位為 date, open, high, low, close, volume。原因：" + ex.getMessage(), ex);
        }
        if (rows.isEmpty()) throw new IllegalArgumentException("CSV 沒有可匯入資料。");
        marketBarRepository.deleteBySymbol(targetSymbol);
        rows.sort(Comparator.comparing(MarketBar::getBarDate));
        rows = indicatorService.addFeatures(rows, 5, 5, 20, 14, 12, 26, 9, 9, 20, 2.0);
        return marketBarRepository.saveAll(rows);
    }

    public List<String> symbols() {
        List<String> symbols = marketBarRepository.findAllSymbols();
        return symbols.isEmpty() ? List.of("DEMO") : symbols;
    }

    public List<MarketBar> findBars(String symbol, int limit) {
        String targetSymbol = cleanSymbol(symbol);
        if (limit <= 0) return marketBarRepository.findBySymbolOrderByBarDateAsc(targetSymbol);
        List<MarketBar> desc = marketBarRepository.findBySymbolOrderByBarDateDesc(targetSymbol, PageRequest.of(0, limit));
        desc.sort(Comparator.comparing(MarketBar::getBarDate));
        return desc;
    }

    public MarketBar latest(String symbol) {
        return marketBarRepository.findFirstBySymbolOrderByBarDateDesc(cleanSymbol(symbol))
                .orElseThrow(() -> new NoSuchElementException("找不到行情資料，請先產生範例資料或匯入 CSV。"));
    }

    public List<MetricDto> indicatorSummary(String symbol) {
        MarketBar latest = latest(symbol);
        return List.of(
                new MetricDto("收盤價", NumberUtil.num(latest.getClosePrice()), "最新一筆行情收盤價。"),
                new MetricDto("RSI", NumberUtil.num(latest.getRsi()), rsiState(latest.getRsi())),
                new MetricDto("MACD Histogram", NumberUtil.num(latest.getMacdHist()), "正值偏多，負值偏空，接近 0 代表轉折或盤整。"),
                new MetricDto("KD", "K " + NumberUtil.num(latest.getKdK()) + " / D " + NumberUtil.num(latest.getKdD()), "K>D 偏多，K<D 偏弱。"),
                new MetricDto("布林位置 %B", NumberUtil.num(latest.getBbPosition()), "接近 1 代表靠近上軌，接近 0 代表靠近下軌。")
        );
    }

    public List<CorrelationDto> correlations(String symbol, String target) {
        List<MarketBar> bars = findBars(symbol, 0);
        Map<String, Function<MarketBar, Double>> features = numericFeatureMap();
        Function<MarketBar, Double> targetGetter = features.getOrDefault(target, MarketBar::getProfit);
        List<CorrelationDto> result = new ArrayList<>();
        for (Map.Entry<String, Function<MarketBar, Double>> entry : features.entrySet()) {
            if (entry.getKey().equals(target)) continue;
            Double corr = pearson(bars, entry.getValue(), targetGetter);
            if (corr != null) result.add(new CorrelationDto(entry.getKey(), corr, corr >= 0 ? "正相關" : "負相關"));
        }
        result.sort(Comparator.comparing(CorrelationDto::correlation));
        return result;
    }

    public MarketBar findBarOnOrBefore(String symbol, LocalDate date) {
        return marketBarRepository.findFirstBySymbolAndBarDateLessThanEqualOrderByBarDateDesc(cleanSymbol(symbol), date)
                .orElseThrow(() -> new NoSuchElementException("找不到指定日期以前的行情資料。"));
    }

    private String rsiState(Double rsi) {
        if (rsi == null) return "資料不足。";
        if (rsi >= 70) return "RSI 偏熱，注意追高風險。";
        if (rsi <= 30) return "RSI 偏冷，可能接近超跌區。";
        if (rsi >= 50) return "RSI 偏多。";
        return "RSI 偏弱。";
    }

    private Map<String, Function<MarketBar, Double>> numericFeatureMap() {
        Map<String, Function<MarketBar, Double>> map = new LinkedHashMap<>();
        map.put("return1d", MarketBar::getReturn1d);
        map.put("return5d", MarketBar::getReturn5d);
        map.put("bodyPct", MarketBar::getBodyPct);
        map.put("rangePct", MarketBar::getRangePct);
        map.put("volumeRatio5", MarketBar::getVolumeRatio5);
        map.put("maGapShortLong", MarketBar::getMaGapShortLong);
        map.put("rsi", MarketBar::getRsi);
        map.put("macd", MarketBar::getMacd);
        map.put("macdSignal", MarketBar::getMacdSignal);
        map.put("macdHist", MarketBar::getMacdHist);
        map.put("kdK", MarketBar::getKdK);
        map.put("kdD", MarketBar::getKdD);
        map.put("kdJ", MarketBar::getKdJ);
        map.put("bbPosition", MarketBar::getBbPosition);
        map.put("bbWidth", MarketBar::getBbWidth);
        map.put("profit", MarketBar::getProfit);
        return map;
    }

    private Double pearson(List<MarketBar> bars, Function<MarketBar, Double> xGetter, Function<MarketBar, Double> yGetter) {
        List<double[]> pairs = new ArrayList<>();
        for (MarketBar b : bars) {
            Double x = xGetter.apply(b);
            Double y = yGetter.apply(b);
            if (x != null && y != null && Double.isFinite(x) && Double.isFinite(y)) pairs.add(new double[]{x, y});
        }
        if (pairs.size() < 5) return null;
        double meanX = pairs.stream().mapToDouble(p -> p[0]).average().orElse(0);
        double meanY = pairs.stream().mapToDouble(p -> p[1]).average().orElse(0);
        double cov = 0, varX = 0, varY = 0;
        for (double[] p : pairs) {
            cov += (p[0] - meanX) * (p[1] - meanY);
            varX += Math.pow(p[0] - meanX, 2);
            varY += Math.pow(p[1] - meanY, 2);
        }
        if (varX == 0 || varY == 0) return null;
        return cov / Math.sqrt(varX * varY);
    }

    private Map<String, Integer> lowercaseHeaders(Map<String, Integer> original) {
        Map<String, Integer> map = new HashMap<>();
        original.forEach((k, v) -> map.put(k.trim().toLowerCase(), v));
        return map;
    }

    private String get(CSVRecord record, Map<String, Integer> headers, String name) {
        Integer index = headers.get(name);
        if (index == null) throw new IllegalArgumentException("缺少欄位：" + name);
        return record.get(index);
    }

    private LocalDate parseDate(String text) {
        String value = text.trim();
        if (value.length() >= 10) value = value.substring(0, 10);
        return LocalDate.parse(value, DateTimeFormatter.ISO_LOCAL_DATE);
    }

    private double parseDouble(String text) {
        if (text == null || text.isBlank()) return 0.0;
        return Double.parseDouble(text.replace(",", "").trim());
    }

    private String cleanSymbol(String symbol) {
        return symbol == null || symbol.isBlank() ? "DEMO" : symbol.trim().toUpperCase();
    }

    private double round(double value) {
        return Math.round(value * 10000.0) / 10000.0;
    }
}
