package com.codebyx.trading.model;

import jakarta.persistence.*;
import java.time.LocalDate;

@Entity
@Table(name = "trade_journals")
public class TradeJournal {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private LocalDate entryDate;
    private LocalDate exitDate;
    private String symbol;
    private String marketType;
    private String side;
    private Double entryPrice;
    private Double exitPrice;
    private Double quantity;
    private Double fee;
    private Double slippage;
    private String strategy;
    private String setup;
    private String emotion;
    @Column(length = 1000)
    private String notes;

    private Double grossProfit;
    private Double netProfit;
    private Double returnPct;
    private Boolean win;
    private Double cumulativeProfit;
    private Double drawdown;

    public TradeJournal() {}

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public LocalDate getEntryDate() { return entryDate; }
    public void setEntryDate(LocalDate entryDate) { this.entryDate = entryDate; }
    public LocalDate getExitDate() { return exitDate; }
    public void setExitDate(LocalDate exitDate) { this.exitDate = exitDate; }
    public String getSymbol() { return symbol; }
    public void setSymbol(String symbol) { this.symbol = symbol; }
    public String getMarketType() { return marketType; }
    public void setMarketType(String marketType) { this.marketType = marketType; }
    public String getSide() { return side; }
    public void setSide(String side) { this.side = side; }
    public Double getEntryPrice() { return entryPrice; }
    public void setEntryPrice(Double entryPrice) { this.entryPrice = entryPrice; }
    public Double getExitPrice() { return exitPrice; }
    public void setExitPrice(Double exitPrice) { this.exitPrice = exitPrice; }
    public Double getQuantity() { return quantity; }
    public void setQuantity(Double quantity) { this.quantity = quantity; }
    public Double getFee() { return fee; }
    public void setFee(Double fee) { this.fee = fee; }
    public Double getSlippage() { return slippage; }
    public void setSlippage(Double slippage) { this.slippage = slippage; }
    public String getStrategy() { return strategy; }
    public void setStrategy(String strategy) { this.strategy = strategy; }
    public String getSetup() { return setup; }
    public void setSetup(String setup) { this.setup = setup; }
    public String getEmotion() { return emotion; }
    public void setEmotion(String emotion) { this.emotion = emotion; }
    public String getNotes() { return notes; }
    public void setNotes(String notes) { this.notes = notes; }
    public Double getGrossProfit() { return grossProfit; }
    public void setGrossProfit(Double grossProfit) { this.grossProfit = grossProfit; }
    public Double getNetProfit() { return netProfit; }
    public void setNetProfit(Double netProfit) { this.netProfit = netProfit; }
    public Double getReturnPct() { return returnPct; }
    public void setReturnPct(Double returnPct) { this.returnPct = returnPct; }
    public Boolean getWin() { return win; }
    public void setWin(Boolean win) { this.win = win; }
    public Double getCumulativeProfit() { return cumulativeProfit; }
    public void setCumulativeProfit(Double cumulativeProfit) { this.cumulativeProfit = cumulativeProfit; }
    public Double getDrawdown() { return drawdown; }
    public void setDrawdown(Double drawdown) { this.drawdown = drawdown; }
}
