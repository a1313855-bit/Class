package com.codebyx.trading.controller;

import com.codebyx.trading.dto.ApiResponse;
import com.codebyx.trading.dto.OrderRequest;
import com.codebyx.trading.service.PaperTradingService;
import jakarta.validation.Valid;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;

@RestController
@RequestMapping("/api/paper")
@CrossOrigin
public class PaperTradingController {
    private final PaperTradingService paperTradingService;

    public PaperTradingController(PaperTradingService paperTradingService) {
        this.paperTradingService = paperTradingService;
    }

    @PostMapping("/reset")
    public ApiResponse reset(@RequestParam(defaultValue = "DEMO") String symbol,
                             @RequestParam(defaultValue = "100000") double initialCapital) {
        return ApiResponse.ok("模擬帳戶已重設", paperTradingService.reset(symbol, initialCapital));
    }

    @GetMapping("/state")
    public ApiResponse state(@RequestParam(defaultValue = "DEMO") String symbol,
                             @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate date) {
        return ApiResponse.ok("paper state", paperTradingService.state(symbol, date));
    }

    @PostMapping("/order")
    public ApiResponse order(@Valid @RequestBody OrderRequest request) {
        return ApiResponse.ok("模擬交易已送出", paperTradingService.placeOrder(request));
    }

    @GetMapping("/orders")
    public ApiResponse orders() {
        return ApiResponse.ok("paper orders", paperTradingService.orders());
    }

    @GetMapping("/equity")
    public ApiResponse equity() {
        return ApiResponse.ok("paper equity", paperTradingService.equityCurve());
    }
}
