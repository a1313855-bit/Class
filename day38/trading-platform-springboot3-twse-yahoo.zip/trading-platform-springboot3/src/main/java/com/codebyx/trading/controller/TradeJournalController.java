package com.codebyx.trading.controller;

import com.codebyx.trading.dto.ApiResponse;
import com.codebyx.trading.model.TradeJournal;
import com.codebyx.trading.service.TradeJournalService;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/trades")
@CrossOrigin
public class TradeJournalController {
    private final TradeJournalService tradeJournalService;

    public TradeJournalController(TradeJournalService tradeJournalService) {
        this.tradeJournalService = tradeJournalService;
    }

    @GetMapping
    public ApiResponse list(@RequestParam(defaultValue = "DEMO") String symbol) {
        return ApiResponse.ok("trades", tradeJournalService.findAll(symbol));
    }

    @PostMapping
    public ApiResponse save(@RequestBody TradeJournal trade) {
        return ApiResponse.ok("交易日誌已儲存", tradeJournalService.save(trade));
    }

    @GetMapping("/stats")
    public ApiResponse stats(@RequestParam(defaultValue = "DEMO") String symbol) {
        return ApiResponse.ok("trade stats", tradeJournalService.stats(symbol));
    }

    @PostMapping("/sample")
    public ApiResponse sample(@RequestParam(defaultValue = "DEMO") String symbol) {
        return ApiResponse.ok("已產生交易日誌範例", tradeJournalService.generateSample(symbol));
    }
}
