# Spring Boot 3 交易分析平台 Demo

這份專案是把原本 Python + Streamlit 交易分析平台改成：

- Spring Boot 3
- Spring Data JPA
- MySQL 8.0
- HTML + CSS + JavaScript
- REST API 架構
- MVC + DAO Pattern

功能主軸：

1. 行情資料管理
2. CSV 匯入：date, open, high, low, close, volume
3. 技術指標計算：MA、RSI、MACD、KD、Bollinger Band
4. 相關性分析：各欄位與 profit 的正負相關
5. 交易日誌：Long / Short、手續費、滑價、淨損益、累積損益、回撤
6. 策略回測：MA、MACD、RSI、KD、布林策略
7. 模擬交易 / Paper Trading：虛擬資金、買進、賣出、放空、回補、持倉、已實現/未實現損益
8. 前端 Dashboard：純 HTML/CSS/JavaScript 呼叫 REST API

---

## 一、開發環境

建議環境：

- JDK 17 或以上
- Maven 3.9+
- MySQL 8.0
- Eclipse IDE for Enterprise Java and Web Developers 或 IntelliJ IDEA

Spring Boot 3 需要 Java 17 起跳。

---

## 二、建立資料庫

請先啟動 MySQL，然後執行：

```sql
CREATE DATABASE IF NOT EXISTS trading_platform
  DEFAULT CHARACTER SET utf8mb4
  DEFAULT COLLATE utf8mb4_unicode_ci;
```

或直接執行：

```text
database/create_database.sql
```

---

## 三、修改 MySQL 連線

打開：

```text
src/main/resources/application.properties
```

依照你的 MySQL 帳密修改：

```properties
spring.datasource.url=jdbc:mysql://localhost:3306/trading_platform?useSSL=false&serverTimezone=Asia/Taipei&allowPublicKeyRetrieval=true&characterEncoding=utf8
spring.datasource.username=root
spring.datasource.password=1234
```

---

## 四、啟動專案

### 方法 1：命令列

```bash
mvn spring-boot:run
```

### 方法 2：Windows 批次檔

直接執行：

```text
run_windows.bat
```

### 方法 3：Eclipse

1. File → Import
2. Maven → Existing Maven Projects
3. 選擇本專案資料夾
4. 等 Maven 下載套件
5. 執行 `TradingPlatformApplication.java`

---

## 五、開啟畫面

啟動後打開瀏覽器：

```text
http://localhost:8080
```

第一次啟動時，如果資料庫是空的，系統會自動產生：

- DEMO 行情資料 500 筆
- 交易日誌範例
- 模擬交易帳戶

---

## 六、前端頁面功能

### 1. 總覽

顯示：

- 最新日期
- 收盤價
- 模擬帳戶權益
- 回測策略報酬
- 收盤價走勢
- 模擬帳戶資金曲線

### 2. 行情與指標

顯示：

- RSI
- MACD Histogram
- KD
- 布林位置 %B
- 行情表格
- 成交量圖

可匯入 CSV。

必要欄位：

```csv
date,open,high,low,close,volume
```

### 3. 相關性分析

分析各技術欄位與 `profit` 的相關性。

`profit` 預設為未來 5 日報酬百分比。

### 4. 交易日誌

可新增交易紀錄，系統會自動計算：

- grossProfit
- netProfit
- returnPct
- cumulativeProfit
- drawdown

### 5. 策略回測

內建策略：

- MA 均線策略
- MACD 策略
- RSI 均值回歸
- KD 交叉策略
- Bollinger Band 均值回歸

可比較策略資金曲線與買進持有。

### 6. 模擬交易 / Paper Trading

支援：

- BUY：買進 / 做多
- SELL：賣出 / 平多
- SHORT：放空
- COVER：回補空單

會計算：

- 現金
- 持倉數量
- 平均成本
- 已實現損益
- 未實現損益
- 帳戶權益
- 總報酬率

---

## 七、主要資料夾結構

```text
src/main/java/com/codebyx/trading
├── config      # 啟動時建立 Demo 資料
├── controller  # REST Controller
├── dao         # Spring Data JPA Repository，DAO Pattern
├── dto         # API 回傳資料物件
├── exception   # 全域例外處理
├── model       # JPA Entity
└── service     # 商業邏輯：指標、交易日誌、回測、模擬交易

src/main/resources/static
├── index.html
├── css/style.css
└── js/app.js, chart.js
```

---

## 八、課堂講解順序建議

1. 先展示原本 Python Streamlit 版的功能方向。
2. 說明為什麼企業版常改成 Spring Boot + MySQL。
3. 解釋 Entity 對應資料表。
4. 解釋 Repository 就是 DAO 層。
5. 解釋 Service 負責商業邏輯。
6. 解釋 Controller 提供 REST API。
7. 前端 JavaScript 用 fetch 呼叫 API。
8. 示範交易日誌與回測。
9. 最後示範 Paper Trading 模擬下單。

---

## 九、實務提醒

這是教學與原型展示專案，不是實盤交易系統。正式交易前仍需加入：

- 真實券商 API
- 權限控管
- 交易風控
- 下單確認
- 錯單處理
- 實際稅費與滑價模型
- 樣本外測試
- Walk-forward analysis
- 日誌與稽核紀錄

---

## 十、外部資料來源：TWSE + Yahoo

本版已加入兩個外部資料抓取功能，位置在前端「行情與指標」分頁。

### 1. TWSE 台灣證券交易所

用途：抓取台灣上市股票的「個股日成交資訊」。

前端輸入範例：

```text
股票代號：2330
儲存代號：2330.TW
開始月份：2026-01
結束月份：2026-07
```

後端 API：

```http
POST /api/market/fetch-twse?stockNo=2330&symbol=2330.TW&startMonth=2026-01&endMonth=2026-07
```

程式位置：

```text
src/main/java/com/codebyx/trading/service/ExternalMarketDataService.java
src/main/java/com/codebyx/trading/controller/MarketDataController.java
```

抓取後會寫入 `market_bars`，並重新計算 MA、RSI、MACD、KD、布林通道與 profit。

### 2. Yahoo Finance

用途：抓取 Yahoo Finance chart JSON 歷史資料。可用於台股、美股、ETF、外匯、加密貨幣等代號。

前端輸入範例：

```text
Yahoo 代號：2330.TW
儲存代號：2330.TW
開始日期：2024-01-01
結束日期：2026-07-09
週期：1d
```

常用代號：

```text
台股：2330.TW、0050.TW、0056.TW、00878.TW
美股：AAPL、TSLA、MSFT、NVDA
加密貨幣：BTC-USD、ETH-USD、SOL-USD
外匯：EURUSD=X、JPY=X
```

後端 API：

```http
POST /api/market/fetch-yahoo?yahooSymbol=2330.TW&symbol=2330.TW&startDate=2024-01-01&endDate=2026-07-09&interval=1d
```

注意：Yahoo Finance chart endpoint 是教學與展示用的免 Key 資料來源，可能受連線頻率、區域或服務調整影響；正式商用或實盤交易請改用交易所授權資料、券商 API 或付費行情供應商。
