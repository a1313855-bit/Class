@echo off
chcp 65001
cd /d %~dp0
echo 啟動 Spring Boot 3 交易分析平台...
echo 請先確認 MySQL 已啟動，並已執行 database\create_database.sql
mvn spring-boot:run
pause
