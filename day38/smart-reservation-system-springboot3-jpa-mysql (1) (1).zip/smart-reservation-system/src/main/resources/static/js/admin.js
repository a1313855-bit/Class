const adminBranchSelect = document.querySelector('#adminBranchId');
const adminTimeSlotSelect = document.querySelector('#adminTimeSlotId');
const adminDate = document.querySelector('#adminDate');
const adminFloorPlan = document.querySelector('#adminFloorPlan');
const reservationTable = document.querySelector('#reservationTable tbody');
const waitlistTable = document.querySelector('#waitlistTable tbody');
const aiTable = document.querySelector('#aiTable tbody');

adminDate.value = todayString();

async function initAdmin() {
    await loadSummary();
    await loadAdminBranches();
    await loadReservations();
    await loadWaitlist();
    await loadAiPredictions();
}

async function loadSummary() {
    const s = await api.get('/api/dashboard/summary');
    document.querySelector('#todayReservations').textContent = s.todayReservations;
    document.querySelector('#todayPeople').textContent = s.todayPeople;
    document.querySelector('#checkedInCount').textContent = s.checkedInCount;
    document.querySelector('#waitlistCount').textContent = s.waitlistCount;
    document.querySelector('#tableUsageRate').textContent = `${s.tableUsageRate}%`;
}

async function loadAdminBranches() {
    const branches = await api.get('/api/branches');
    adminBranchSelect.innerHTML = branches.map(b => `<option value="${b.id}">${b.branchName}</option>`).join('');
    await loadAdminTimeSlots();
}

async function loadAdminTimeSlots() {
    const slots = await api.get(`/api/time-slots?branchId=${adminBranchSelect.value}`);
    adminTimeSlotSelect.innerHTML = slots.map(s => `<option value="${s.id}">${s.slotName} ${s.startTime} - ${s.endTime}</option>`).join('');
    await loadAdminFloorPlan();
}

async function loadAdminFloorPlan() {
    const tables = await api.get(`/api/tables/floor-plan?branchId=${adminBranchSelect.value}&date=${adminDate.value}&timeSlotId=${adminTimeSlotSelect.value}`);
    renderFloorPlan(adminFloorPlan, tables);
}

async function loadReservations() {
    const rows = await api.get('/api/reservations');
    reservationTable.innerHTML = rows.map(r => `
        <tr>
            <td>${r.id}</td>
            <td>${r.customerName}</td>
            <td>${r.phone}</td>
            <td>${r.branchName}</td>
            <td>${r.reservationDate}</td>
            <td>${r.timeSlot}</td>
            <td>${r.peopleCount}</td>
            <td>${r.tableNo}</td>
            <td><span class="badge bg-secondary table-status-badge">${statusText(r.status)}</span></td>
            <td>
                <button class="btn btn-sm btn-outline-success" onclick="checkin(${r.id})">報到</button>
                <button class="btn btn-sm btn-outline-danger" onclick="cancelReservation(${r.id})">取消</button>
            </td>
        </tr>
    `).join('');
}

async function loadWaitlist() {
    const rows = await api.get('/api/waitlist');
    waitlistTable.innerHTML = rows.map(w => `
        <tr>
            <td>${w.id}</td>
            <td>${w.customer.name}</td>
            <td>${w.customer.phone}</td>
            <td>${w.branch.branchName}</td>
            <td>${w.waitDate}</td>
            <td>${w.timeSlot.slotName}</td>
            <td>${w.peopleCount}</td>
            <td><span class="badge bg-warning text-dark">${statusText(w.status)}</span></td>
        </tr>
    `).join('');
}

async function loadAiPredictions() {
    const rows = await api.get('/api/ai/predictions/popular-time');
    aiTable.innerHTML = rows.map(a => `
        <tr>
            <td>${a.predictDate}</td>
            <td>${a.timeRange}</td>
            <td>${a.predictedReservationCount}</td>
            <td>${a.predictedRate}%</td>
            <td>${a.riskLevel}</td>
            <td>${a.suggestion}</td>
        </tr>
    `).join('');
}

async function cancelReservation(id) {
    if (!confirm('確定取消此訂位？')) return;
    await api.put(`/api/reservations/${id}/cancel`);
    await refreshAll();
}

async function checkin(id) {
    await api.put(`/api/reservations/${id}/checkin`);
    await refreshAll();
}

async function refreshAll() {
    await loadSummary();
    await loadAdminFloorPlan();
    await loadReservations();
    await loadWaitlist();
    await loadAiPredictions();
}

adminBranchSelect.addEventListener('change', loadAdminTimeSlots);
adminTimeSlotSelect.addEventListener('change', loadAdminFloorPlan);
adminDate.addEventListener('change', loadAdminFloorPlan);
document.querySelector('#adminRefreshBtn').addEventListener('click', refreshAll);

initAdmin().catch(err => alert('後台初始化失敗：' + err.message));
