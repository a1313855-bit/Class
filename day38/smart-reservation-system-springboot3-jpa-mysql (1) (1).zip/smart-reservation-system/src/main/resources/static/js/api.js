const api = {
    async get(url) {
        const res = await fetch(url);
        if (!res.ok) throw await parseError(res);
        return res.json();
    },
    async post(url, body) {
        const res = await fetch(url, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(body)
        });
        if (!res.ok) throw await parseError(res);
        return res.json();
    },
    async put(url) {
        const res = await fetch(url, { method: 'PUT' });
        if (!res.ok) throw await parseError(res);
        return res.json();
    }
};

async function parseError(res) {
    try {
        const data = await res.json();
        return new Error(data.message || '系統錯誤');
    } catch (e) {
        return new Error('系統錯誤');
    }
}

function todayString() {
    return new Date().toISOString().slice(0, 10);
}

function statusText(status) {
    const map = {
        AVAILABLE: '可用',
        RESERVED: '已訂',
        DISABLED: '停用',
        CONFIRMED: '已訂位',
        CHECKED_IN: '已報到',
        CANCELLED: '已取消',
        WAITING: '候補中',
        NO_SHOW: '未到場'
    };
    return map[status] || status;
}

function statusClass(status) {
    if (status === 'AVAILABLE') return 'table-available';
    if (status === 'RESERVED') return 'table-reserved';
    return 'table-disabled';
}

function renderFloorPlan(container, tables) {
    container.innerHTML = `
        <div class="floor-kitchen">廚房 / 吧台</div>
        <div class="floor-door">入口</div>
        <div class="floor-label">桌位平面圖</div>
    `;

    tables.forEach(t => {
        const div = document.createElement('div');
        div.className = `table-box ${statusClass(t.status)}`;
        div.style.left = `${t.floorX}px`;
        div.style.top = `${t.floorY}px`;
        div.style.width = `${t.floorW}px`;
        div.style.height = `${t.floorH}px`;
        div.title = `${t.tableNo}｜${t.capacity} 人｜${statusText(t.status)}｜${t.zone}`;
        div.innerHTML = `
            <div class="table-no">${t.tableNo}</div>
            <div class="table-capacity">${t.capacity} 人｜${statusText(t.status)}</div>
        `;
        container.appendChild(div);
    });
}
