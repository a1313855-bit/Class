const branchSelect = document.querySelector('#branchId');
const timeSlotSelect = document.querySelector('#timeSlotId');
const reservationDate = document.querySelector('#reservationDate');
const floorPlan = document.querySelector('#floorPlan');
const resultBox = document.querySelector('#resultBox');
const reservationForm = document.querySelector('#reservationForm');

reservationDate.value = todayString();

async function loadBranches() {
    const branches = await api.get('/api/branches');
    branchSelect.innerHTML = branches.map(b => `<option value="${b.id}">${b.branchName}</option>`).join('');
    await loadTimeSlots();
}

async function loadTimeSlots() {
    const branchId = branchSelect.value;
    const slots = await api.get(`/api/time-slots?branchId=${branchId}`);
    timeSlotSelect.innerHTML = slots.map(s => `<option value="${s.id}">${s.slotName} ${s.startTime} - ${s.endTime}</option>`).join('');
    await loadFloorPlan();
}

async function loadFloorPlan() {
    if (!branchSelect.value || !timeSlotSelect.value || !reservationDate.value) return;
    const tables = await api.get(`/api/tables/floor-plan?branchId=${branchSelect.value}&date=${reservationDate.value}&timeSlotId=${timeSlotSelect.value}`);
    renderFloorPlan(floorPlan, tables);
}

reservationForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    const body = {
        branchId: Number(branchSelect.value),
        timeSlotId: Number(timeSlotSelect.value),
        reservationDate: reservationDate.value,
        peopleCount: Number(document.querySelector('#peopleCount').value),
        name: document.querySelector('#name').value,
        phone: document.querySelector('#phone').value,
        email: document.querySelector('#email').value,
        note: document.querySelector('#note').value
    };

    try {
        const data = await api.post('/api/reservations', body);
        resultBox.className = data.status === 'WAITING' ? 'alert alert-warning' : 'alert alert-success';
        resultBox.innerHTML = `
            <strong>${data.message || '處理完成'}</strong><br>
            狀態：${statusText(data.status)}<br>
            分店：${data.branchName}<br>
            日期：${data.reservationDate}<br>
            時段：${data.timeSlot}<br>
            人數：${data.peopleCount}<br>
            桌號：${data.tableNo || '候補未分配'}<br>
            QR Code Token：${data.checkinToken || '候補中尚未產生'}
        `;
        resultBox.classList.remove('d-none');
        await loadFloorPlan();
    } catch (err) {
        resultBox.className = 'alert alert-danger';
        resultBox.textContent = err.message;
        resultBox.classList.remove('d-none');
    }
});

branchSelect.addEventListener('change', loadTimeSlots);
timeSlotSelect.addEventListener('change', loadFloorPlan);
reservationDate.addEventListener('change', loadFloorPlan);
document.querySelector('#refreshFloorBtn').addEventListener('click', loadFloorPlan);

loadBranches().catch(err => {
    resultBox.className = 'alert alert-danger';
    resultBox.textContent = '初始化失敗：' + err.message;
    resultBox.classList.remove('d-none');
});
