package tw.com.codebyx.reservation.controller;

import org.springframework.web.bind.annotation.*;
import tw.com.codebyx.reservation.dto.ReservationRequest;
import tw.com.codebyx.reservation.dto.ReservationResponse;
import tw.com.codebyx.reservation.service.ReservationService;
import java.util.List;

@RestController
@RequestMapping("/api/reservations")
public class ReservationController {
    private final ReservationService reservationService;

    public ReservationController(ReservationService reservationService) {
        this.reservationService = reservationService;
    }

    @PostMapping
    public ReservationResponse create(@RequestBody ReservationRequest request) {
        return reservationService.createReservation(request);
    }

    @GetMapping
    public List<ReservationResponse> findAll() {
        return reservationService.findAll();
    }

    @PutMapping("/{id}/cancel")
    public ReservationResponse cancel(@PathVariable Long id) {
        return reservationService.cancel(id);
    }

    @PutMapping("/{id}/checkin")
    public ReservationResponse checkin(@PathVariable Long id) {
        return reservationService.checkin(id);
    }
}
