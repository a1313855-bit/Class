package tw.com.codebyx.reservation.service.impl;

import org.springframework.stereotype.Service;
import tw.com.codebyx.reservation.dao.WaitlistDao;
import tw.com.codebyx.reservation.model.Waitlist;
import tw.com.codebyx.reservation.service.WaitlistService;
import java.util.List;

@Service
public class WaitlistServiceImpl implements WaitlistService {
    private final WaitlistDao waitlistDao;

    public WaitlistServiceImpl(WaitlistDao waitlistDao) {
        this.waitlistDao = waitlistDao;
    }

    @Override
    public List<Waitlist> findAll() {
        return waitlistDao.findAll();
    }
}
