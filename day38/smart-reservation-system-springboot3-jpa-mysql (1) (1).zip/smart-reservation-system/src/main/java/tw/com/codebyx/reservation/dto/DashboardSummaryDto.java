package tw.com.codebyx.reservation.dto;

public class DashboardSummaryDto {
    private long todayReservations;
    private long todayPeople;
    private long checkedInCount;
    private long waitlistCount;
    private long noShowCount;
    private double tableUsageRate;

    public long getTodayReservations() { return todayReservations; }
    public void setTodayReservations(long todayReservations) { this.todayReservations = todayReservations; }
    public long getTodayPeople() { return todayPeople; }
    public void setTodayPeople(long todayPeople) { this.todayPeople = todayPeople; }
    public long getCheckedInCount() { return checkedInCount; }
    public void setCheckedInCount(long checkedInCount) { this.checkedInCount = checkedInCount; }
    public long getWaitlistCount() { return waitlistCount; }
    public void setWaitlistCount(long waitlistCount) { this.waitlistCount = waitlistCount; }
    public long getNoShowCount() { return noShowCount; }
    public void setNoShowCount(long noShowCount) { this.noShowCount = noShowCount; }
    public double getTableUsageRate() { return tableUsageRate; }
    public void setTableUsageRate(double tableUsageRate) { this.tableUsageRate = tableUsageRate; }
}
