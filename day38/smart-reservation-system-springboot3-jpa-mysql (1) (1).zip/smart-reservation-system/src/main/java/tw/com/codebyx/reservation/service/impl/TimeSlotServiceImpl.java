package tw.com.codebyx.reservation.service.impl;

import org.springframework.stereotype.Service;
import tw.com.codebyx.reservation.dao.TimeSlotDao;
import tw.com.codebyx.reservation.model.TimeSlot;
import tw.com.codebyx.reservation.service.TimeSlotService;
import java.util.List;

@Service
public class TimeSlotServiceImpl implements TimeSlotService {
    private final TimeSlotDao timeSlotDao;

    public TimeSlotServiceImpl(TimeSlotDao timeSlotDao) {
        this.timeSlotDao = timeSlotDao;
    }

    @Override
    public List<TimeSlot> findOpenSlots(Long branchId) {
        return timeSlotDao.findOpenSlots(branchId);
    }
}
