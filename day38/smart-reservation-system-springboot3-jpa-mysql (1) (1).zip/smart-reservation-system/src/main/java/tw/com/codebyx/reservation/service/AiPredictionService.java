package tw.com.codebyx.reservation.service;

import tw.com.codebyx.reservation.dto.AiPredictionDto;
import java.util.List;

public interface AiPredictionService {
    List<AiPredictionDto> predictPopularTime();
}
