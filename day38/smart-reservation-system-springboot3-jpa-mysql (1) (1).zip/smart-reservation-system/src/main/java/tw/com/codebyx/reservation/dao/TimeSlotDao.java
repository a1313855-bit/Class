package tw.com.codebyx.reservation.dao;

import tw.com.codebyx.reservation.model.TimeSlot;
import java.util.List;
import java.util.Optional;

public interface TimeSlotDao {
    List<TimeSlot> findOpenSlots(Long branchId);
    Optional<TimeSlot> findById(Long id);
    TimeSlot save(TimeSlot timeSlot);
}
