package tw.com.codebyx.reservation.dao;

import tw.com.codebyx.reservation.model.Customer;
import java.util.Optional;

public interface CustomerDao {
    Optional<Customer> findByPhone(String phone);
    Customer save(Customer customer);
}
