package tw.com.codebyx.reservation.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import tw.com.codebyx.reservation.model.TimeSlot;
import tw.com.codebyx.reservation.service.TimeSlotService;
import java.util.List;

@RestController
@RequestMapping("/api/time-slots")
public class TimeSlotController {
    private final TimeSlotService timeSlotService;

    public TimeSlotController(TimeSlotService timeSlotService) {
        this.timeSlotService = timeSlotService;
    }

    @GetMapping
    public List<TimeSlot> findOpenSlots(@RequestParam Long branchId) {
        return timeSlotService.findOpenSlots(branchId);
    }
}
