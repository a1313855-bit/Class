package tw.com.codebyx.reservation.dao.impl;

import org.springframework.stereotype.Repository;
import tw.com.codebyx.reservation.dao.WaitlistDao;
import tw.com.codebyx.reservation.model.Waitlist;
import tw.com.codebyx.reservation.repository.WaitlistRepository;
import java.util.List;

@Repository
public class WaitlistDaoImpl implements WaitlistDao {
    private final WaitlistRepository waitlistRepository;

    public WaitlistDaoImpl(WaitlistRepository waitlistRepository) {
        this.waitlistRepository = waitlistRepository;
    }

    @Override
    public Waitlist save(Waitlist waitlist) {
        return waitlistRepository.save(waitlist);
    }

    @Override
    public List<Waitlist> findAll() {
        return waitlistRepository.findAllByOrderByCreatedAtAsc();
    }

    @Override
    public long countWaiting() {
        return waitlistRepository.countByStatus("WAITING");
    }
}
