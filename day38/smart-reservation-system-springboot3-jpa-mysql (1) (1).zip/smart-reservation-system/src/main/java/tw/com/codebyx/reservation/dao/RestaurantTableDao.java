package tw.com.codebyx.reservation.dao;

import tw.com.codebyx.reservation.model.RestaurantTable;
import java.util.List;
import java.util.Optional;

public interface RestaurantTableDao {
    List<RestaurantTable> findByBranchId(Long branchId);
    List<RestaurantTable> findAvailableByBranchId(Long branchId);
    Optional<RestaurantTable> findById(Long id);
    RestaurantTable save(RestaurantTable table);
    long countByBranchId(Long branchId);
}
