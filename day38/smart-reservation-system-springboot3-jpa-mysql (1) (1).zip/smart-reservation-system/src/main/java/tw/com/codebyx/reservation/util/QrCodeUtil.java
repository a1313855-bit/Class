package tw.com.codebyx.reservation.util;

public class QrCodeUtil {
    private QrCodeUtil() {}

    public static String buildCheckinText(String token) {
        return "reservation_checkin_token=" + token;
    }
}
