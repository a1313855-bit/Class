package tw.com.codebyx.reservation.dao;

import tw.com.codebyx.reservation.model.Branch;
import java.util.List;
import java.util.Optional;

public interface BranchDao {
    List<Branch> findOpenBranches();
    Optional<Branch> findById(Long id);
    Branch save(Branch branch);
}
