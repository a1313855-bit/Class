package tw.com.codebyx.reservation.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import tw.com.codebyx.reservation.model.Waitlist;
import tw.com.codebyx.reservation.service.WaitlistService;
import java.util.List;

@RestController
@RequestMapping("/api/waitlist")
public class WaitlistController {
    private final WaitlistService waitlistService;

    public WaitlistController(WaitlistService waitlistService) {
        this.waitlistService = waitlistService;
    }

    @GetMapping
    public List<Waitlist> findAll() {
        return waitlistService.findAll();
    }
}
