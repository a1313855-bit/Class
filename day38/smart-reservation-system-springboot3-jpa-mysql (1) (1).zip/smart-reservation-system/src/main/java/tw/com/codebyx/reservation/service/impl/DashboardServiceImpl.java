package tw.com.codebyx.reservation.service.impl;

import org.springframework.stereotype.Service;
import tw.com.codebyx.reservation.dao.ReservationDao;
import tw.com.codebyx.reservation.dao.RestaurantTableDao;
import tw.com.codebyx.reservation.dao.WaitlistDao;
import tw.com.codebyx.reservation.dto.DashboardSummaryDto;
import tw.com.codebyx.reservation.model.Reservation;
import tw.com.codebyx.reservation.service.DashboardService;

import java.time.LocalDate;
import java.util.List;

@Service
public class DashboardServiceImpl implements DashboardService {
    private final ReservationDao reservationDao;
    private final WaitlistDao waitlistDao;
    private final RestaurantTableDao tableDao;

    public DashboardServiceImpl(ReservationDao reservationDao, WaitlistDao waitlistDao, RestaurantTableDao tableDao) {
        this.reservationDao = reservationDao;
        this.waitlistDao = waitlistDao;
        this.tableDao = tableDao;
    }

    @Override
    public DashboardSummaryDto getSummary() {
        List<Reservation> today = reservationDao.findByDate(LocalDate.now());
        DashboardSummaryDto dto = new DashboardSummaryDto();
        dto.setTodayReservations(today.stream().filter(r -> !"CANCELLED".equals(r.getStatus())).count());
        dto.setTodayPeople(today.stream().filter(r -> !"CANCELLED".equals(r.getStatus())).mapToLong(Reservation::getPeopleCount).sum());
        dto.setCheckedInCount(today.stream().filter(r -> "CHECKED_IN".equals(r.getStatus())).count());
        dto.setNoShowCount(today.stream().filter(r -> "NO_SHOW".equals(r.getStatus())).count());
        dto.setWaitlistCount(waitlistDao.countWaiting());

        long totalTables = tableDao.countByBranchId(1L);
        long usedTables = today.stream().filter(r -> r.getTable() != null && !"CANCELLED".equals(r.getStatus())).count();
        dto.setTableUsageRate(totalTables == 0 ? 0 : Math.round((usedTables * 10000.0 / totalTables)) / 100.0);
        return dto;
    }
}
