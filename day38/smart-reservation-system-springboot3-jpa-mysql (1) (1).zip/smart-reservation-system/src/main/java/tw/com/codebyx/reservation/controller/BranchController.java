package tw.com.codebyx.reservation.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import tw.com.codebyx.reservation.model.Branch;
import tw.com.codebyx.reservation.service.BranchService;
import java.util.List;

@RestController
@RequestMapping("/api/branches")
public class BranchController {
    private final BranchService branchService;

    public BranchController(BranchService branchService) {
        this.branchService = branchService;
    }

    @GetMapping
    public List<Branch> findOpenBranches() {
        return branchService.findOpenBranches();
    }
}
