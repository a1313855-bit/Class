package tw.com.codebyx.reservation.dao.impl;

import org.springframework.stereotype.Repository;
import tw.com.codebyx.reservation.dao.CustomerDao;
import tw.com.codebyx.reservation.model.Customer;
import tw.com.codebyx.reservation.repository.CustomerRepository;
import java.util.Optional;

@Repository
public class CustomerDaoImpl implements CustomerDao {
    private final CustomerRepository customerRepository;

    public CustomerDaoImpl(CustomerRepository customerRepository) {
        this.customerRepository = customerRepository;
    }

    @Override
    public Optional<Customer> findByPhone(String phone) {
        return customerRepository.findByPhone(phone);
    }

    @Override
    public Customer save(Customer customer) {
        return customerRepository.save(customer);
    }
}
