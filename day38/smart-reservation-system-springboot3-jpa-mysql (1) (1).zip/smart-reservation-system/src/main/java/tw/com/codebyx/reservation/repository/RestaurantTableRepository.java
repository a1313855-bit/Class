package tw.com.codebyx.reservation.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import tw.com.codebyx.reservation.model.RestaurantTable;
import java.util.List;

public interface RestaurantTableRepository extends JpaRepository<RestaurantTable, Long> {
    List<RestaurantTable> findByBranchIdOrderByTableNoAsc(Long branchId);
    List<RestaurantTable> findByBranchIdAndStatusOrderByCapacityAsc(Long branchId, String status);
    long countByBranchId(Long branchId);
}
