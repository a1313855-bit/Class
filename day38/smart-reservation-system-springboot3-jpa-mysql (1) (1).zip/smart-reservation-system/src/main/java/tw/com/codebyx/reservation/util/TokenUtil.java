package tw.com.codebyx.reservation.util;

import java.util.UUID;

public class TokenUtil {
    private TokenUtil() {}

    public static String shortToken() {
        return UUID.randomUUID().toString().replace("-", "").substring(0, 10).toUpperCase();
    }
}
