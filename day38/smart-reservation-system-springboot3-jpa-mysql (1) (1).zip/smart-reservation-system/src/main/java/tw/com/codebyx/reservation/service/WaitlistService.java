package tw.com.codebyx.reservation.service;

import tw.com.codebyx.reservation.model.Waitlist;
import java.util.List;

public interface WaitlistService {
    List<Waitlist> findAll();
}
