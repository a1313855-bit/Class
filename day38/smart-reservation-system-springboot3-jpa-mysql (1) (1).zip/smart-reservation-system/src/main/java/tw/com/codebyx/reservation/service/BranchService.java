package tw.com.codebyx.reservation.service;

import tw.com.codebyx.reservation.model.Branch;
import java.util.List;

public interface BranchService {
    List<Branch> findOpenBranches();
}
