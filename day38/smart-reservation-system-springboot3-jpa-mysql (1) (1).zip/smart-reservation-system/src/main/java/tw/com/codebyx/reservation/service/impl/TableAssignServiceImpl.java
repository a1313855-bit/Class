package tw.com.codebyx.reservation.service.impl;

import org.springframework.stereotype.Service;
import tw.com.codebyx.reservation.dao.ReservationDao;
import tw.com.codebyx.reservation.dao.RestaurantTableDao;
import tw.com.codebyx.reservation.dto.FloorTableDto;
import tw.com.codebyx.reservation.model.Reservation;
import tw.com.codebyx.reservation.model.RestaurantTable;
import tw.com.codebyx.reservation.service.TableAssignService;

import java.time.LocalDate;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;

@Service
public class TableAssignServiceImpl implements TableAssignService {
    private final RestaurantTableDao tableDao;
    private final ReservationDao reservationDao;

    public TableAssignServiceImpl(RestaurantTableDao tableDao, ReservationDao reservationDao) {
        this.tableDao = tableDao;
        this.reservationDao = reservationDao;
    }

    @Override
    public Optional<RestaurantTable> autoAssignTable(Long branchId, LocalDate reservationDate, Long timeSlotId, Integer peopleCount) {
        Set<Long> occupiedTableIds = getOccupiedTableIds(branchId, reservationDate, timeSlotId);
        return tableDao.findAvailableByBranchId(branchId)
                .stream()
                .filter(table -> table.getCapacity() >= peopleCount)
                .filter(table -> !occupiedTableIds.contains(table.getId()))
                .sorted((a, b) -> {
                    int cap = a.getCapacity().compareTo(b.getCapacity());
                    return cap != 0 ? cap : a.getTableNo().compareTo(b.getTableNo());
                })
                .findFirst();
    }

    @Override
    public List<FloorTableDto> getFloorPlan(Long branchId, LocalDate reservationDate, Long timeSlotId) {
        Set<Long> occupiedTableIds = getOccupiedTableIds(branchId, reservationDate, timeSlotId);
        return tableDao.findByBranchId(branchId)
                .stream()
                .map(table -> {
                    String status = table.getStatus();
                    if (occupiedTableIds.contains(table.getId())) {
                        status = "RESERVED";
                    }
                    if (!"AVAILABLE".equals(table.getStatus())) {
                        status = "DISABLED";
                    }
                    return new FloorTableDto(
                            table.getId(), table.getTableNo(), table.getCapacity(), status,
                            table.getFloorX(), table.getFloorY(), table.getFloorW(), table.getFloorH(), table.getZone()
                    );
                })
                .toList();
    }

    private Set<Long> getOccupiedTableIds(Long branchId, LocalDate reservationDate, Long timeSlotId) {
        List<Reservation> reservations = reservationDao.findActiveReservations(branchId, reservationDate, timeSlotId);
        Set<Long> occupiedTableIds = new HashSet<>();
        for (Reservation reservation : reservations) {
            if (reservation.getTable() != null) {
                occupiedTableIds.add(reservation.getTable().getId());
            }
        }
        return occupiedTableIds;
    }
}
