package tw.com.codebyx.reservation.dao;

import tw.com.codebyx.reservation.model.Waitlist;
import java.util.List;

public interface WaitlistDao {
    Waitlist save(Waitlist waitlist);
    List<Waitlist> findAll();
    long countWaiting();
}
