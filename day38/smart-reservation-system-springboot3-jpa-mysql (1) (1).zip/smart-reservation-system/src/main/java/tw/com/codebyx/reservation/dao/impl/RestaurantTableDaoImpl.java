package tw.com.codebyx.reservation.dao.impl;

import org.springframework.stereotype.Repository;
import tw.com.codebyx.reservation.dao.RestaurantTableDao;
import tw.com.codebyx.reservation.model.RestaurantTable;
import tw.com.codebyx.reservation.repository.RestaurantTableRepository;
import java.util.List;
import java.util.Optional;

@Repository
public class RestaurantTableDaoImpl implements RestaurantTableDao {
    private final RestaurantTableRepository restaurantTableRepository;

    public RestaurantTableDaoImpl(RestaurantTableRepository restaurantTableRepository) {
        this.restaurantTableRepository = restaurantTableRepository;
    }

    @Override
    public List<RestaurantTable> findByBranchId(Long branchId) {
        return restaurantTableRepository.findByBranchIdOrderByTableNoAsc(branchId);
    }

    @Override
    public List<RestaurantTable> findAvailableByBranchId(Long branchId) {
        return restaurantTableRepository.findByBranchIdAndStatusOrderByCapacityAsc(branchId, "AVAILABLE");
    }

    @Override
    public Optional<RestaurantTable> findById(Long id) {
        return restaurantTableRepository.findById(id);
    }

    @Override
    public RestaurantTable save(RestaurantTable table) {
        return restaurantTableRepository.save(table);
    }

    @Override
    public long countByBranchId(Long branchId) {
        return restaurantTableRepository.countByBranchId(branchId);
    }
}
