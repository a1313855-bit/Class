package tw.com.codebyx.reservation.service;

import tw.com.codebyx.reservation.dto.ReservationRequest;
import tw.com.codebyx.reservation.dto.ReservationResponse;
import java.util.List;

public interface ReservationService {
    ReservationResponse createReservation(ReservationRequest request);
    List<ReservationResponse> findAll();
    ReservationResponse cancel(Long id);
    ReservationResponse checkin(Long id);
}
