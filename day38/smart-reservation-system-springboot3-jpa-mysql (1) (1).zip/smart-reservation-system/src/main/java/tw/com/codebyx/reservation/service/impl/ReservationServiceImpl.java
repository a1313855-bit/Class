package tw.com.codebyx.reservation.service.impl;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import tw.com.codebyx.reservation.dao.*;
import tw.com.codebyx.reservation.dto.ReservationRequest;
import tw.com.codebyx.reservation.dto.ReservationResponse;
import tw.com.codebyx.reservation.exception.BusinessException;
import tw.com.codebyx.reservation.model.*;
import tw.com.codebyx.reservation.service.ReservationService;
import tw.com.codebyx.reservation.service.TableAssignService;
import tw.com.codebyx.reservation.util.TokenUtil;

import java.time.LocalDate;
import java.util.List;

@Service
public class ReservationServiceImpl implements ReservationService {
    private final ReservationDao reservationDao;
    private final CustomerDao customerDao;
    private final BranchDao branchDao;
    private final TimeSlotDao timeSlotDao;
    private final WaitlistDao waitlistDao;
    private final TableAssignService tableAssignService;

    public ReservationServiceImpl(ReservationDao reservationDao,
                                  CustomerDao customerDao,
                                  BranchDao branchDao,
                                  TimeSlotDao timeSlotDao,
                                  WaitlistDao waitlistDao,
                                  TableAssignService tableAssignService) {
        this.reservationDao = reservationDao;
        this.customerDao = customerDao;
        this.branchDao = branchDao;
        this.timeSlotDao = timeSlotDao;
        this.waitlistDao = waitlistDao;
        this.tableAssignService = tableAssignService;
    }

    @Override
    @Transactional
    public ReservationResponse createReservation(ReservationRequest request) {
        validateRequest(request);
        Customer customer = customerDao.findByPhone(request.getPhone()).orElseGet(() -> {
            Customer newCustomer = new Customer();
            newCustomer.setName(request.getName());
            newCustomer.setPhone(request.getPhone());
            newCustomer.setEmail(request.getEmail());
            newCustomer.setPassword("1234");
            return customerDao.save(newCustomer);
        });

        customer.setName(request.getName());
        customer.setEmail(request.getEmail());
        customerDao.save(customer);

        Branch branch = branchDao.findById(request.getBranchId())
                .orElseThrow(() -> new BusinessException("找不到分店"));
        TimeSlot timeSlot = timeSlotDao.findById(request.getTimeSlotId())
                .orElseThrow(() -> new BusinessException("找不到時段"));

        return tableAssignService.autoAssignTable(
                        request.getBranchId(),
                        request.getReservationDate(),
                        request.getTimeSlotId(),
                        request.getPeopleCount()
                )
                .map(table -> createConfirmedReservation(request, customer, branch, timeSlot, table))
                .orElseGet(() -> createWaitlist(request, customer, branch, timeSlot));
    }

    @Override
    public List<ReservationResponse> findAll() {
        return reservationDao.findAll().stream().map(this::toResponse).toList();
    }

    @Override
    @Transactional
    public ReservationResponse cancel(Long id) {
        Reservation reservation = reservationDao.findById(id)
                .orElseThrow(() -> new BusinessException("找不到訂位資料"));
        if ("CHECKED_IN".equals(reservation.getStatus()) || "COMPLETED".equals(reservation.getStatus())) {
            throw new BusinessException("已報到或已完成的訂位不可取消");
        }
        reservation.setStatus("CANCELLED");
        return toResponse(reservationDao.save(reservation));
    }

    @Override
    @Transactional
    public ReservationResponse checkin(Long id) {
        Reservation reservation = reservationDao.findById(id)
                .orElseThrow(() -> new BusinessException("找不到訂位資料"));
        if ("CANCELLED".equals(reservation.getStatus())) {
            throw new BusinessException("已取消的訂位不可報到");
        }
        reservation.setStatus("CHECKED_IN");
        return toResponse(reservationDao.save(reservation));
    }

    private ReservationResponse createConfirmedReservation(ReservationRequest request, Customer customer, Branch branch,
                                                          TimeSlot timeSlot, RestaurantTable table) {
        Reservation reservation = new Reservation();
        reservation.setCustomer(customer);
        reservation.setBranch(branch);
        reservation.setTimeSlot(timeSlot);
        reservation.setTable(table);
        reservation.setReservationDate(request.getReservationDate());
        reservation.setPeopleCount(request.getPeopleCount());
        reservation.setStatus("CONFIRMED");
        reservation.setNote(request.getNote());
        reservation.setCheckinToken(TokenUtil.shortToken());
        Reservation saved = reservationDao.save(reservation);
        ReservationResponse response = toResponse(saved);
        response.setMessage("訂位成功，系統已自動分配桌號 " + table.getTableNo());
        return response;
    }

    private ReservationResponse createWaitlist(ReservationRequest request, Customer customer, Branch branch, TimeSlot timeSlot) {
        Waitlist waitlist = new Waitlist();
        waitlist.setCustomer(customer);
        waitlist.setBranch(branch);
        waitlist.setTimeSlot(timeSlot);
        waitlist.setWaitDate(request.getReservationDate());
        waitlist.setPeopleCount(request.getPeopleCount());
        waitlist.setStatus("WAITING");
        Waitlist saved = waitlistDao.save(waitlist);

        ReservationResponse response = new ReservationResponse();
        response.setWaitlistId(saved.getId());
        response.setCustomerName(customer.getName());
        response.setPhone(customer.getPhone());
        response.setBranchName(branch.getBranchName());
        response.setReservationDate(request.getReservationDate());
        response.setTimeSlot(timeSlot.getSlotName() + " " + timeSlot.getStartTime() + "-" + timeSlot.getEndTime());
        response.setPeopleCount(request.getPeopleCount());
        response.setStatus("WAITING");
        response.setMessage("目前沒有合適桌位，已自動加入候補名單");
        return response;
    }

    private void validateRequest(ReservationRequest request) {
        if (request.getBranchId() == null) throw new BusinessException("請選擇分店");
        if (request.getTimeSlotId() == null) throw new BusinessException("請選擇時段");
        if (request.getReservationDate() == null) throw new BusinessException("請選擇日期");
        if (request.getReservationDate().isBefore(LocalDate.now())) throw new BusinessException("訂位日期不可小於今天");
        if (request.getPeopleCount() == null || request.getPeopleCount() < 1) throw new BusinessException("人數至少 1 人");
        if (request.getName() == null || request.getName().isBlank()) throw new BusinessException("請輸入姓名");
        if (request.getPhone() == null || request.getPhone().isBlank()) throw new BusinessException("請輸入電話");
    }

    private ReservationResponse toResponse(Reservation reservation) {
        ReservationResponse response = new ReservationResponse();
        response.setId(reservation.getId());
        response.setCustomerName(reservation.getCustomer().getName());
        response.setPhone(reservation.getCustomer().getPhone());
        response.setBranchName(reservation.getBranch().getBranchName());
        response.setTableNo(reservation.getTable() == null ? "未分配" : reservation.getTable().getTableNo());
        response.setReservationDate(reservation.getReservationDate());
        response.setTimeSlot(reservation.getTimeSlot().getSlotName() + " " + reservation.getTimeSlot().getStartTime() + "-" + reservation.getTimeSlot().getEndTime());
        response.setPeopleCount(reservation.getPeopleCount());
        response.setStatus(reservation.getStatus());
        response.setNote(reservation.getNote());
        response.setCheckinToken(reservation.getCheckinToken());
        return response;
    }
}
