package tw.com.codebyx.reservation.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import tw.com.codebyx.reservation.model.TimeSlot;
import java.util.List;

public interface TimeSlotRepository extends JpaRepository<TimeSlot, Long> {
    List<TimeSlot> findByBranchIdAndStatusOrderByStartTimeAsc(Long branchId, String status);
}
