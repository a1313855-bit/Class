package tw.com.codebyx.reservation.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "restaurant_table")
public class RestaurantTable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "branch_id", nullable = false)
    private Branch branch;

    @Column(nullable = false, length = 20)
    private String tableNo;

    @Column(nullable = false)
    private Integer capacity;

    @Column(length = 20)
    private String status = "AVAILABLE";

    private Integer floorX = 20;
    private Integer floorY = 20;
    private Integer floorW = 90;
    private Integer floorH = 70;

    @Column(length = 30)
    private String zone = "A區";

    private LocalDateTime createdAt = LocalDateTime.now();

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public Branch getBranch() { return branch; }
    public void setBranch(Branch branch) { this.branch = branch; }
    public String getTableNo() { return tableNo; }
    public void setTableNo(String tableNo) { this.tableNo = tableNo; }
    public Integer getCapacity() { return capacity; }
    public void setCapacity(Integer capacity) { this.capacity = capacity; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
    public Integer getFloorX() { return floorX; }
    public void setFloorX(Integer floorX) { this.floorX = floorX; }
    public Integer getFloorY() { return floorY; }
    public void setFloorY(Integer floorY) { this.floorY = floorY; }
    public Integer getFloorW() { return floorW; }
    public void setFloorW(Integer floorW) { this.floorW = floorW; }
    public Integer getFloorH() { return floorH; }
    public void setFloorH(Integer floorH) { this.floorH = floorH; }
    public String getZone() { return zone; }
    public void setZone(String zone) { this.zone = zone; }
    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }
}
