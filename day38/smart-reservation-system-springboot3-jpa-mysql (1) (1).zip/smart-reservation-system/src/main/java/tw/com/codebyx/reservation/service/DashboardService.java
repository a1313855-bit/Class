package tw.com.codebyx.reservation.service;

import tw.com.codebyx.reservation.dto.DashboardSummaryDto;

public interface DashboardService {
    DashboardSummaryDto getSummary();
}
