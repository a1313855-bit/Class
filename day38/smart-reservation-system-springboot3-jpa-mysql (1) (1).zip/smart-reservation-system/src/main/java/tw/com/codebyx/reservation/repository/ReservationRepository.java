package tw.com.codebyx.reservation.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import tw.com.codebyx.reservation.model.Reservation;
import java.time.LocalDate;
import java.util.List;

public interface ReservationRepository extends JpaRepository<Reservation, Long> {
    List<Reservation> findAllByOrderByCreatedAtDesc();

    @Query("""
        select r from Reservation r
        where r.branch.id = :branchId
          and r.reservationDate = :reservationDate
          and r.timeSlot.id = :timeSlotId
          and r.status in :statuses
    """)
    List<Reservation> findActiveReservations(
            @Param("branchId") Long branchId,
            @Param("reservationDate") LocalDate reservationDate,
            @Param("timeSlotId") Long timeSlotId,
            @Param("statuses") List<String> statuses
    );

    List<Reservation> findByReservationDate(LocalDate reservationDate);
}
