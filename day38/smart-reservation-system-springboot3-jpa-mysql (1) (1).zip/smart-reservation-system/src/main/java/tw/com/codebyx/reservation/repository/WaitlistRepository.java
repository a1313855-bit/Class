package tw.com.codebyx.reservation.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import tw.com.codebyx.reservation.model.Waitlist;
import java.util.List;

public interface WaitlistRepository extends JpaRepository<Waitlist, Long> {
    List<Waitlist> findAllByOrderByCreatedAtAsc();
    long countByStatus(String status);
}
