package tw.com.codebyx.reservation.dao;

import tw.com.codebyx.reservation.model.Reservation;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

public interface ReservationDao {
    Reservation save(Reservation reservation);
    Optional<Reservation> findById(Long id);
    List<Reservation> findAll();
    List<Reservation> findActiveReservations(Long branchId, LocalDate date, Long timeSlotId);
    List<Reservation> findByDate(LocalDate date);
}
