package tw.com.codebyx.reservation.dao.impl;

import org.springframework.stereotype.Repository;
import tw.com.codebyx.reservation.dao.ReservationDao;
import tw.com.codebyx.reservation.model.Reservation;
import tw.com.codebyx.reservation.repository.ReservationRepository;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Repository
public class ReservationDaoImpl implements ReservationDao {
    private static final List<String> ACTIVE_STATUSES = List.of("PENDING", "CONFIRMED", "PAID", "CHECKED_IN");
    private final ReservationRepository reservationRepository;

    public ReservationDaoImpl(ReservationRepository reservationRepository) {
        this.reservationRepository = reservationRepository;
    }

    @Override
    public Reservation save(Reservation reservation) {
        return reservationRepository.save(reservation);
    }

    @Override
    public Optional<Reservation> findById(Long id) {
        return reservationRepository.findById(id);
    }

    @Override
    public List<Reservation> findAll() {
        return reservationRepository.findAllByOrderByCreatedAtDesc();
    }

    @Override
    public List<Reservation> findActiveReservations(Long branchId, LocalDate date, Long timeSlotId) {
        return reservationRepository.findActiveReservations(branchId, date, timeSlotId, ACTIVE_STATUSES);
    }

    @Override
    public List<Reservation> findByDate(LocalDate date) {
        return reservationRepository.findByReservationDate(date);
    }
}
