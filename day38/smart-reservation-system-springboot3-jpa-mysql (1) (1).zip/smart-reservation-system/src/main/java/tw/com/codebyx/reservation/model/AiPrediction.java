package tw.com.codebyx.reservation.model;

import jakarta.persistence.*;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Entity
@Table(name = "ai_prediction")
public class AiPrediction {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "branch_id", nullable = false)
    private Branch branch;

    private LocalDate predictDate;

    @Column(length = 50)
    private String timeRange;

    private Integer predictedReservationCount;
    private Double predictedRate;

    @Column(columnDefinition = "TEXT")
    private String suggestion;

    private LocalDateTime createdAt = LocalDateTime.now();

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public Branch getBranch() { return branch; }
    public void setBranch(Branch branch) { this.branch = branch; }
    public LocalDate getPredictDate() { return predictDate; }
    public void setPredictDate(LocalDate predictDate) { this.predictDate = predictDate; }
    public String getTimeRange() { return timeRange; }
    public void setTimeRange(String timeRange) { this.timeRange = timeRange; }
    public Integer getPredictedReservationCount() { return predictedReservationCount; }
    public void setPredictedReservationCount(Integer predictedReservationCount) { this.predictedReservationCount = predictedReservationCount; }
    public Double getPredictedRate() { return predictedRate; }
    public void setPredictedRate(Double predictedRate) { this.predictedRate = predictedRate; }
    public String getSuggestion() { return suggestion; }
    public void setSuggestion(String suggestion) { this.suggestion = suggestion; }
    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }
}
