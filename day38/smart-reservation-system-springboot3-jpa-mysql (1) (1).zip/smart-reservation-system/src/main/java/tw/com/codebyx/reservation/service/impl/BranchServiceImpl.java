package tw.com.codebyx.reservation.service.impl;

import org.springframework.stereotype.Service;
import tw.com.codebyx.reservation.dao.BranchDao;
import tw.com.codebyx.reservation.model.Branch;
import tw.com.codebyx.reservation.service.BranchService;
import java.util.List;

@Service
public class BranchServiceImpl implements BranchService {
    private final BranchDao branchDao;

    public BranchServiceImpl(BranchDao branchDao) {
        this.branchDao = branchDao;
    }

    @Override
    public List<Branch> findOpenBranches() {
        return branchDao.findOpenBranches();
    }
}
