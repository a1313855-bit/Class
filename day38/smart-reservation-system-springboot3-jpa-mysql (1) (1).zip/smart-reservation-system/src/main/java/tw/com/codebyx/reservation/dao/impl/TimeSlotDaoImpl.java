package tw.com.codebyx.reservation.dao.impl;

import org.springframework.stereotype.Repository;
import tw.com.codebyx.reservation.dao.TimeSlotDao;
import tw.com.codebyx.reservation.model.TimeSlot;
import tw.com.codebyx.reservation.repository.TimeSlotRepository;
import java.util.List;
import java.util.Optional;

@Repository
public class TimeSlotDaoImpl implements TimeSlotDao {
    private final TimeSlotRepository timeSlotRepository;

    public TimeSlotDaoImpl(TimeSlotRepository timeSlotRepository) {
        this.timeSlotRepository = timeSlotRepository;
    }

    @Override
    public List<TimeSlot> findOpenSlots(Long branchId) {
        return timeSlotRepository.findByBranchIdAndStatusOrderByStartTimeAsc(branchId, "OPEN");
    }

    @Override
    public Optional<TimeSlot> findById(Long id) {
        return timeSlotRepository.findById(id);
    }

    @Override
    public TimeSlot save(TimeSlot timeSlot) {
        return timeSlotRepository.save(timeSlot);
    }
}
