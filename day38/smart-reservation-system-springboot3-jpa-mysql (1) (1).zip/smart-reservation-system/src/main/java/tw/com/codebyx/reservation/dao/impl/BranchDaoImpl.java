package tw.com.codebyx.reservation.dao.impl;

import org.springframework.stereotype.Repository;
import tw.com.codebyx.reservation.dao.BranchDao;
import tw.com.codebyx.reservation.model.Branch;
import tw.com.codebyx.reservation.repository.BranchRepository;
import java.util.List;
import java.util.Optional;

@Repository
public class BranchDaoImpl implements BranchDao {
    private final BranchRepository branchRepository;

    public BranchDaoImpl(BranchRepository branchRepository) {
        this.branchRepository = branchRepository;
    }

    @Override
    public List<Branch> findOpenBranches() {
        return branchRepository.findByStatusOrderByIdAsc("OPEN");
    }

    @Override
    public Optional<Branch> findById(Long id) {
        return branchRepository.findById(id);
    }

    @Override
    public Branch save(Branch branch) {
        return branchRepository.save(branch);
    }
}
