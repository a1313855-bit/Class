package tw.com.codebyx.reservation.dto;

import java.time.LocalDate;

public class ReservationResponse {
    private Long id;
    private Long waitlistId;
    private String customerName;
    private String phone;
    private String branchName;
    private String tableNo;
    private LocalDate reservationDate;
    private String timeSlot;
    private Integer peopleCount;
    private String status;
    private String note;
    private String checkinToken;
    private String message;

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public Long getWaitlistId() { return waitlistId; }
    public void setWaitlistId(Long waitlistId) { this.waitlistId = waitlistId; }
    public String getCustomerName() { return customerName; }
    public void setCustomerName(String customerName) { this.customerName = customerName; }
    public String getPhone() { return phone; }
    public void setPhone(String phone) { this.phone = phone; }
    public String getBranchName() { return branchName; }
    public void setBranchName(String branchName) { this.branchName = branchName; }
    public String getTableNo() { return tableNo; }
    public void setTableNo(String tableNo) { this.tableNo = tableNo; }
    public LocalDate getReservationDate() { return reservationDate; }
    public void setReservationDate(LocalDate reservationDate) { this.reservationDate = reservationDate; }
    public String getTimeSlot() { return timeSlot; }
    public void setTimeSlot(String timeSlot) { this.timeSlot = timeSlot; }
    public Integer getPeopleCount() { return peopleCount; }
    public void setPeopleCount(Integer peopleCount) { this.peopleCount = peopleCount; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
    public String getNote() { return note; }
    public void setNote(String note) { this.note = note; }
    public String getCheckinToken() { return checkinToken; }
    public void setCheckinToken(String checkinToken) { this.checkinToken = checkinToken; }
    public String getMessage() { return message; }
    public void setMessage(String message) { this.message = message; }
}
