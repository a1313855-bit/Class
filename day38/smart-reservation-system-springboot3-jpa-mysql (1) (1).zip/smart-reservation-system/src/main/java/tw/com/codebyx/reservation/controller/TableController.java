package tw.com.codebyx.reservation.controller;

import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import tw.com.codebyx.reservation.dto.FloorTableDto;
import tw.com.codebyx.reservation.service.TableAssignService;

import java.time.LocalDate;
import java.util.List;

@RestController
@RequestMapping("/api/tables")
public class TableController {
    private final TableAssignService tableAssignService;

    public TableController(TableAssignService tableAssignService) {
        this.tableAssignService = tableAssignService;
    }

    @GetMapping("/floor-plan")
    public List<FloorTableDto> getFloorPlan(@RequestParam Long branchId,
                                            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate date,
                                            @RequestParam Long timeSlotId) {
        return tableAssignService.getFloorPlan(branchId, date, timeSlotId);
    }
}
