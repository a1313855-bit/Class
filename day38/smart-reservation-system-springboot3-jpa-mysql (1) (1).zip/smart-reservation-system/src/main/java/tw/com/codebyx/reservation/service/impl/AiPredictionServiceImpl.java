package tw.com.codebyx.reservation.service.impl;

import org.springframework.stereotype.Service;
import tw.com.codebyx.reservation.dao.ReservationDao;
import tw.com.codebyx.reservation.dto.AiPredictionDto;
import tw.com.codebyx.reservation.model.Reservation;
import tw.com.codebyx.reservation.service.AiPredictionService;

import java.time.LocalDate;
import java.util.*;

@Service
public class AiPredictionServiceImpl implements AiPredictionService {
    private final ReservationDao reservationDao;

    public AiPredictionServiceImpl(ReservationDao reservationDao) {
        this.reservationDao = reservationDao;
    }

    @Override
    public List<AiPredictionDto> predictPopularTime() {
        List<Reservation> reservations = reservationDao.findAll();
        Map<String, Long> countBySlot = new LinkedHashMap<>();
        for (Reservation r : reservations) {
            String key = r.getTimeSlot().getSlotName() + " " + r.getTimeSlot().getStartTime();
            countBySlot.put(key, countBySlot.getOrDefault(key, 0L) + 1);
        }
        if (countBySlot.isEmpty()) {
            countBySlot.put("晚餐 1 17:30", 3L);
            countBySlot.put("晚餐 2 19:00", 2L);
            countBySlot.put("午餐 1 11:30", 1L);
        }
        return countBySlot.entrySet().stream()
                .sorted(Map.Entry.<String, Long>comparingByValue().reversed())
                .limit(5)
                .map(entry -> {
                    AiPredictionDto dto = new AiPredictionDto();
                    dto.setPredictDate(LocalDate.now().plusDays(7));
                    dto.setTimeRange(entry.getKey());
                    dto.setPredictedReservationCount(entry.getValue().intValue() + 2);
                    double rate = Math.min(95.0, 55.0 + entry.getValue() * 12.0);
                    dto.setPredictedRate(rate);
                    dto.setRiskLevel(rate >= 85 ? "高" : rate >= 70 ? "中" : "低");
                    dto.setSuggestion(rate >= 85
                            ? "建議增加外場人力、開放候補，6 人以上可要求訂金。"
                            : "建議維持正常人力，持續觀察候補與取消率。");
                    return dto;
                })
                .toList();
    }
}
