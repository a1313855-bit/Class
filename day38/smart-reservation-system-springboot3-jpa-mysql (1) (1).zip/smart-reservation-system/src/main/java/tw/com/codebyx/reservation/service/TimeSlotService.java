package tw.com.codebyx.reservation.service;

import tw.com.codebyx.reservation.model.TimeSlot;
import java.util.List;

public interface TimeSlotService {
    List<TimeSlot> findOpenSlots(Long branchId);
}
