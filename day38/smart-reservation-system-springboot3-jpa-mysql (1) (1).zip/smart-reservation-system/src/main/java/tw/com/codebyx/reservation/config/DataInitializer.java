package tw.com.codebyx.reservation.config;

import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;
import tw.com.codebyx.reservation.model.*;
import tw.com.codebyx.reservation.repository.*;

import java.time.LocalTime;

@Component
public class DataInitializer implements CommandLineRunner {
    private final BranchRepository branchRepository;
    private final RestaurantTableRepository tableRepository;
    private final TimeSlotRepository timeSlotRepository;
    private final CustomerRepository customerRepository;

    public DataInitializer(BranchRepository branchRepository,
                           RestaurantTableRepository tableRepository,
                           TimeSlotRepository timeSlotRepository,
                           CustomerRepository customerRepository) {
        this.branchRepository = branchRepository;
        this.tableRepository = tableRepository;
        this.timeSlotRepository = timeSlotRepository;
        this.customerRepository = customerRepository;
    }

    @Override
    public void run(String... args) {
        if (branchRepository.count() > 0) {
            return;
        }

        Branch taipei = createBranch("台北信義店", "02-11112222", "台北市信義區信義路一段 100 號");
        Branch banqiao = createBranch("板橋新埔店", "02-33334444", "新北市板橋區文化路一段 200 號");
        branchRepository.save(taipei);
        branchRepository.save(banqiao);

        createTable(taipei, "A01", 2, "A區", 35, 45, 90, 70, "AVAILABLE");
        createTable(taipei, "A02", 2, "A區", 150, 45, 90, 70, "AVAILABLE");
        createTable(taipei, "B01", 4, "B區", 35, 150, 110, 80, "AVAILABLE");
        createTable(taipei, "B02", 4, "B區", 180, 150, 110, 80, "AVAILABLE");
        createTable(taipei, "C01", 6, "C區", 360, 60, 130, 95, "AVAILABLE");
        createTable(taipei, "VIP01", 8, "包廂", 350, 200, 150, 110, "AVAILABLE");
        createTable(taipei, "M01", 4, "維修區", 540, 75, 110, 80, "MAINTENANCE");

        createTable(banqiao, "A01", 2, "A區", 50, 50, 90, 70, "AVAILABLE");
        createTable(banqiao, "B01", 4, "B區", 180, 50, 110, 80, "AVAILABLE");
        createTable(banqiao, "C01", 6, "C區", 340, 50, 130, 95, "AVAILABLE");

        createSlots(taipei);
        createSlots(banqiao);

        createCustomer("王小明", "0911111111", "ming@example.com");
        createCustomer("陳美美", "0922222222", "may@example.com");
        createCustomer("林大華", "0933333333", "lin@example.com");
    }

    private Branch createBranch(String name, String phone, String address) {
        Branch branch = new Branch();
        branch.setBranchName(name);
        branch.setPhone(phone);
        branch.setAddress(address);
        branch.setOpeningTime(LocalTime.of(11, 0));
        branch.setClosingTime(LocalTime.of(22, 0));
        branch.setStatus("OPEN");
        return branch;
    }

    private void createTable(Branch branch, String tableNo, int capacity, String zone, int x, int y, int w, int h, String status) {
        RestaurantTable table = new RestaurantTable();
        table.setBranch(branch);
        table.setTableNo(tableNo);
        table.setCapacity(capacity);
        table.setZone(zone);
        table.setFloorX(x);
        table.setFloorY(y);
        table.setFloorW(w);
        table.setFloorH(h);
        table.setStatus(status);
        tableRepository.save(table);
    }

    private void createSlots(Branch branch) {
        createSlot(branch, "午餐 1", 11, 30, 13, 0, 30);
        createSlot(branch, "午餐 2", 13, 0, 14, 30, 30);
        createSlot(branch, "晚餐 1", 17, 30, 19, 0, 40);
        createSlot(branch, "晚餐 2", 19, 0, 20, 30, 40);
    }

    private void createSlot(Branch branch, String name, int sh, int sm, int eh, int em, int maxPeople) {
        TimeSlot slot = new TimeSlot();
        slot.setBranch(branch);
        slot.setSlotName(name);
        slot.setStartTime(LocalTime.of(sh, sm));
        slot.setEndTime(LocalTime.of(eh, em));
        slot.setMaxPeople(maxPeople);
        slot.setStatus("OPEN");
        timeSlotRepository.save(slot);
    }

    private void createCustomer(String name, String phone, String email) {
        Customer customer = new Customer();
        customer.setName(name);
        customer.setPhone(phone);
        customer.setEmail(email);
        customer.setPassword("1234");
        customerRepository.save(customer);
    }
}
