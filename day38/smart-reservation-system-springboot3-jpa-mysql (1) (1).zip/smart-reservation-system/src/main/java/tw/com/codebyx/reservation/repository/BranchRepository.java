package tw.com.codebyx.reservation.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import tw.com.codebyx.reservation.model.Branch;
import java.util.List;

public interface BranchRepository extends JpaRepository<Branch, Long> {
    List<Branch> findByStatusOrderByIdAsc(String status);
}
