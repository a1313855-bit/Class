package tw.com.codebyx.reservation.service;

import tw.com.codebyx.reservation.dto.FloorTableDto;
import tw.com.codebyx.reservation.model.RestaurantTable;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

public interface TableAssignService {
    Optional<RestaurantTable> autoAssignTable(Long branchId, LocalDate reservationDate, Long timeSlotId, Integer peopleCount);
    List<FloorTableDto> getFloorPlan(Long branchId, LocalDate reservationDate, Long timeSlotId);
}
