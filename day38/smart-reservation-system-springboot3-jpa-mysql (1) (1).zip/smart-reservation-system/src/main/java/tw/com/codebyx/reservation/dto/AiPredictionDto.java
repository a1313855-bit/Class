package tw.com.codebyx.reservation.dto;

import java.time.LocalDate;

public class AiPredictionDto {
    private LocalDate predictDate;
    private String timeRange;
    private int predictedReservationCount;
    private double predictedRate;
    private String riskLevel;
    private String suggestion;

    public LocalDate getPredictDate() { return predictDate; }
    public void setPredictDate(LocalDate predictDate) { this.predictDate = predictDate; }
    public String getTimeRange() { return timeRange; }
    public void setTimeRange(String timeRange) { this.timeRange = timeRange; }
    public int getPredictedReservationCount() { return predictedReservationCount; }
    public void setPredictedReservationCount(int predictedReservationCount) { this.predictedReservationCount = predictedReservationCount; }
    public double getPredictedRate() { return predictedRate; }
    public void setPredictedRate(double predictedRate) { this.predictedRate = predictedRate; }
    public String getRiskLevel() { return riskLevel; }
    public void setRiskLevel(String riskLevel) { this.riskLevel = riskLevel; }
    public String getSuggestion() { return suggestion; }
    public void setSuggestion(String suggestion) { this.suggestion = suggestion; }
}
