package tw.com.codebyx.reservation.dto;

public class FloorTableDto {
    private Long tableId;
    private String tableNo;
    private Integer capacity;
    private String status;
    private Integer floorX;
    private Integer floorY;
    private Integer floorW;
    private Integer floorH;
    private String zone;

    public FloorTableDto() {}

    public FloorTableDto(Long tableId, String tableNo, Integer capacity, String status,
                         Integer floorX, Integer floorY, Integer floorW, Integer floorH, String zone) {
        this.tableId = tableId;
        this.tableNo = tableNo;
        this.capacity = capacity;
        this.status = status;
        this.floorX = floorX;
        this.floorY = floorY;
        this.floorW = floorW;
        this.floorH = floorH;
        this.zone = zone;
    }

    public Long getTableId() { return tableId; }
    public void setTableId(Long tableId) { this.tableId = tableId; }
    public String getTableNo() { return tableNo; }
    public void setTableNo(String tableNo) { this.tableNo = tableNo; }
    public Integer getCapacity() { return capacity; }
    public void setCapacity(Integer capacity) { this.capacity = capacity; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
    public Integer getFloorX() { return floorX; }
    public void setFloorX(Integer floorX) { this.floorX = floorX; }
    public Integer getFloorY() { return floorY; }
    public void setFloorY(Integer floorY) { this.floorY = floorY; }
    public Integer getFloorW() { return floorW; }
    public void setFloorW(Integer floorW) { this.floorW = floorW; }
    public Integer getFloorH() { return floorH; }
    public void setFloorH(Integer floorH) { this.floorH = floorH; }
    public String getZone() { return zone; }
    public void setZone(String zone) { this.zone = zone; }
}
