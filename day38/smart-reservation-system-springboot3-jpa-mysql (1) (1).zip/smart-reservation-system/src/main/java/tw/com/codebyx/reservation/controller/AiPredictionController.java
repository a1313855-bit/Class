package tw.com.codebyx.reservation.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import tw.com.codebyx.reservation.dto.AiPredictionDto;
import tw.com.codebyx.reservation.service.AiPredictionService;
import java.util.List;

@RestController
@RequestMapping("/api/ai/predictions")
public class AiPredictionController {
    private final AiPredictionService aiPredictionService;

    public AiPredictionController(AiPredictionService aiPredictionService) {
        this.aiPredictionService = aiPredictionService;
    }

    @GetMapping("/popular-time")
    public List<AiPredictionDto> popularTime() {
        return aiPredictionService.predictPopularTime();
    }
}
