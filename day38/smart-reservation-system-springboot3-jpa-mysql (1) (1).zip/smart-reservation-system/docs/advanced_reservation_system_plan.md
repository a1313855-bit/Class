# 餐廳智慧訂位系統｜進階版完整規劃書

> 適合用途：專題作品、接案展示、企業內訓、Java / Spring Boot 全端專案、AI + 報表整合展示。  
> 系統定位：從「單純訂位」升級成「智慧訂位管理平台」，整合線上訂位、自動分桌、候補、通知、訂金、QR Code 報到、多分店、Power BI 分析與 AI 預測。

---

# 一、系統目標

## 1. 專案名稱

**餐廳智慧訂位管理系統**

英文名稱可使用：

```text
Smart Restaurant Reservation System
```

---

## 2. 專案核心價值

本系統不是只有「新增訂位」而已，而是模擬真實餐廳接案會遇到的營運需求。

系統要解決的問題：

1. 顧客可線上查詢空位並完成訂位。
2. 系統可根據人數自動分配合適桌位。
3. 滿位時可加入候補名單。
4. 訂位成功後可發送 Email 或簡訊通知。
5. 特殊日期或熱門時段可收取訂金。
6. 顧客到店後可用 QR Code 快速報到。
7. 老闆或管理者可查看後台儀表板。
8. 多分店可統一管理訂位與桌位。
9. Power BI 可分析訂位資料。
10. AI 可預測熱門時段與人流高峰。

---

# 二、使用角色設計

本系統建議設計 4 種角色。

| 角色 | 說明 | 主要功能 |
|---|---|---|
| 顧客 Customer | 一般訂位者 | 線上訂位、查詢、取消、QR Code 報到 |
| 櫃台 Staff | 餐廳現場人員 | 協助訂位、修改訂位、報到確認、候補管理 |
| 店長 Manager | 分店管理者 | 查看分店訂位、桌位狀態、報表統計 |
| 系統管理員 Admin | 總公司或系統管理者 | 多分店管理、帳號權限、系統設定、AI 分析 |

---

# 三、系統功能總覽

## 1. 前台功能

| 模組 | 功能 |
|---|---|
| 會員系統 | 註冊、登入、修改資料、查詢歷史訂位 |
| 線上訂位 | 選擇分店、日期、時段、人數、特殊需求 |
| 空位查詢 | 即時判斷可訂位狀態 |
| 自動分桌 | 根據人數與桌位容量安排桌號 |
| 候補系統 | 滿位時加入候補名單 |
| 訂金付款 | 訂位需付款時導向付款流程 |
| QR Code 報到 | 訂位成功後產生 QR Code，到店掃碼報到 |
| 通知系統 | Email / 簡訊通知訂位成功、取消、候補成功 |

---

## 2. 後台功能

| 模組 | 功能 |
|---|---|
| 訂位管理 | 查詢、新增、修改、取消、完成、未到場 |
| 桌位管理 | 新增桌位、修改容量、停用桌位、合併桌位 |
| 時段管理 | 設定營業時段、可訂位時段、每時段上限 |
| 候補管理 | 查看候補名單、轉正、取消候補 |
| 訂金管理 | 訂金狀態、退款、付款紀錄 |
| QR 報到管理 | 掃碼報到、人工報到、No-show 記錄 |
| 多分店管理 | 分店資料、分店桌位、分店時段、分店報表 |
| 後台儀表板 | 今日訂位、熱門時段、候補數、No-show 比率 |
| Power BI 分析 | 匯出資料或連接資料庫做視覺化分析 |
| AI 預測 | 預測熱門日期、熱門時段、建議人力配置 |

---

# 四、進階功能詳細說明

---

# 1. 線上訂位功能

## 1.1 功能說明

顧客可透過網站或手機瀏覽器完成訂位。

訂位流程：

```text
選擇分店
    ↓
選擇日期
    ↓
選擇時段
    ↓
輸入人數
    ↓
查詢空位
    ↓
系統自動分配桌位
    ↓
確認訂位
    ↓
發送通知
    ↓
產生 QR Code
```

---

## 1.2 前台欄位

| 欄位 | 說明 |
|---|---|
| 分店 | 例如：台北店、板橋店、桃園店 |
| 日期 | 訂位日期 |
| 時段 | 午餐、晚餐或指定時間 |
| 人數 | 訂位人數 |
| 姓名 | 顧客姓名 |
| 電話 | 顧客聯絡電話 |
| Email | 通知用信箱 |
| 備註 | 例如：兒童椅、靠窗、素食、慶生 |

---

## 1.3 訂位狀態

| 狀態 | 說明 |
|---|---|
| PENDING | 等待確認 |
| CONFIRMED | 已確認訂位 |
| PAID | 已付訂金 |
| CHECKED_IN | 已報到 |
| COMPLETED | 已完成 |
| CANCELLED | 已取消 |
| NO_SHOW | 未到場 |
| WAITING | 候補中 |

---

# 2. 自動分配桌位

## 2.1 功能說明

系統根據顧客人數，自動找出最適合的桌位。

例如：

| 人數 | 建議桌位 |
|---|---|
| 1～2 人 | 2 人桌 |
| 3～4 人 | 4 人桌 |
| 5～6 人 | 6 人桌 |
| 7～8 人 | 8 人桌 |
| 9 人以上 | 合併桌位 |

---

## 2.2 分桌邏輯

基本規則：

1. 優先找容量剛好的桌位。
2. 若沒有剛好的桌位，找容量大一級的桌位。
3. 避免 2 人佔用 8 人桌。
4. 避免同一時段重複分配同一桌。
5. 若所有桌位皆滿，轉入候補流程。
6. 若人數超過單桌上限，可使用合併桌。

---

## 2.3 分桌演算法概念

```text
輸入：分店、日期、時段、人數

Step 1：查詢該分店所有可用桌位
Step 2：排除該時段已被訂走的桌位
Step 3：找出 capacity >= people_count 的桌位
Step 4：依 capacity 由小到大排序
Step 5：選擇最接近人數的桌位
Step 6：若找不到，判斷是否可合併桌
Step 7：若仍找不到，加入候補名單
```

---

## 2.4 Java Service 方法設計

```java
public TableInfo autoAssignTable(
        Integer branchId,
        LocalDate reservationDate,
        Integer timeSlotId,
        Integer peopleCount
);
```

---

# 3. 候補系統

## 3.1 功能說明

當某日期與時段已滿，顧客可以加入候補。

候補流程：

```text
顧客查詢空位
    ↓
系統判斷已滿
    ↓
顯示「加入候補」
    ↓
顧客填寫聯絡資料
    ↓
系統產生候補編號
    ↓
有空位釋出
    ↓
系統通知候補者
    ↓
候補者確認
    ↓
候補轉正式訂位
```

---

## 3.2 候補狀態

| 狀態 | 說明 |
|---|---|
| WAITING | 候補中 |
| NOTIFIED | 已通知 |
| CONFIRMED | 已轉正式訂位 |
| EXPIRED | 逾時未確認 |
| CANCELLED | 已取消候補 |

---

## 3.3 候補排序規則

候補名單可依照以下規則排序：

1. 加入候補時間。
2. 人數是否符合釋出的桌位。
3. VIP 會員優先。
4. No-show 紀錄較少者優先。
5. 訂金確認者優先。

---

# 4. 訂位簡訊 / Email 通知

## 4.1 功能說明

系統在不同事件發生時，自動通知顧客。

通知事件：

| 事件 | 通知內容 |
|---|---|
| 訂位成功 | 訂位日期、時段、分店、桌位、QR Code |
| 訂位取消 | 取消成功通知 |
| 候補成功 | 已加入候補名單 |
| 候補轉正 | 有空位可訂，請確認 |
| 訂位提醒 | 用餐前一天提醒 |
| 訂金付款成功 | 付款成功與訂位資訊 |
| No-show 記錄 | 未到場通知 |

---

## 4.2 Email 內容範例

```text
親愛的 王小明 您好：

您的訂位已成功。

分店：台北信義店
日期：2026-08-01
時段：18:30
人數：4 人
桌號：A05

請於到店時出示 QR Code 報到。
若需取消訂位，請於用餐前 24 小時完成取消。

餐廳智慧訂位系統
```

---

## 4.3 通知資料表設計重點

通知不建議只發送後就結束，應該留下紀錄。

應記錄：

1. 通知對象。
2. 通知類型。
3. 通知內容。
4. 發送時間。
5. 發送狀態。
6. 失敗原因。

---

# 5. 訂金付款功能

## 5.1 功能說明

熱門時段、大桌訂位、節日訂位可要求先付訂金。

適用情境：

| 情境 | 是否需要訂金 |
|---|---|
| 一般平日 2 人訂位 | 不一定 |
| 假日晚餐 6 人以上 | 建議需要 |
| 節日訂位 | 建議需要 |
| 包廂訂位 | 建議需要 |
| 多次 No-show 會員 | 建議需要 |

---

## 5.2 付款流程

```text
建立訂位
    ↓
系統判斷是否需要訂金
    ↓
若需要，產生付款單
    ↓
顧客前往付款
    ↓
付款成功
    ↓
訂位狀態改為 PAID
    ↓
發送付款成功通知
```

---

## 5.3 付款狀態

| 狀態 | 說明 |
|---|---|
| UNPAID | 未付款 |
| PAID | 已付款 |
| REFUNDED | 已退款 |
| FAILED | 付款失敗 |
| EXPIRED | 付款逾時 |

---

## 5.4 Payment 資料表重點

| 欄位 | 說明 |
|---|---|
| id | 付款編號 |
| reservation_id | 訂位編號 |
| amount | 訂金金額 |
| payment_method | 付款方式 |
| payment_status | 付款狀態 |
| transaction_no | 金流交易編號 |
| paid_at | 付款時間 |
| refunded_at | 退款時間 |

---

# 6. QR Code 報到

## 6.1 功能說明

訂位成功後，系統產生 QR Code。  
顧客到店後，櫃台掃描 QR Code 即可報到。

---

## 6.2 QR Code 內容建議

QR Code 不建議直接放太多個資，建議放報到 token。

範例：

```text
reservation_checkin_token=8F3A9C2D
```

後端依 token 查詢訂位資料。

---

## 6.3 報到流程

```text
顧客出示 QR Code
    ↓
櫃台掃描
    ↓
系統查詢訂位
    ↓
確認日期與時段
    ↓
更新狀態為 CHECKED_IN
    ↓
記錄報到時間
```

---

## 6.4 防呆規則

| 規則 | 說明 |
|---|---|
| 日期不符 | 不允許報到 |
| 已取消訂位 | 不允許報到 |
| 已報到 | 顯示已報到 |
| 逾時太久 | 需管理員確認 |
| QR Code 失效 | 要重新產生 |

---

# 7. Power BI 訂位分析

## 7.1 功能說明

將訂位資料匯入 Power BI，讓管理者分析營運狀況。

可分析內容：

1. 每日訂位數。
2. 每月訂位趨勢。
3. 熱門時段。
4. 熱門分店。
5. No-show 比率。
6. 訂金收入。
7. 候補轉正率。
8. 桌位使用率。
9. 平日與假日差異。
10. 顧客回訪率。

---

## 7.2 Power BI 視覺化頁面

建議設計 5 頁：

| 頁面 | 內容 |
|---|---|
| 營運總覽 | 今日訂位、當月訂位、訂金收入、No-show |
| 分店分析 | 各分店訂位數、熱門分店排行 |
| 時段分析 | 午餐、晚餐、尖峰時段分析 |
| 顧客分析 | 回訪率、會員訂位次數、No-show 客戶 |
| 財務分析 | 訂金收入、退款金額、付款成功率 |

---

## 7.3 Power BI 資料來源

建議資料來源：

| 來源 | 說明 |
|---|---|
| MySQL | 直接連接正式資料庫 |
| Excel | 從系統匯出報表 |
| CSV | 排程產出統計資料 |
| API | 後端提供統計 API |

---

# 8. 後台儀表板

## 8.1 功能說明

後台儀表板讓店長一進後台就知道今日營運狀況。

---

## 8.2 儀表板 KPI

| KPI | 說明 |
|---|---|
| 今日訂位數 | 今日所有訂位筆數 |
| 今日用餐人數 | 今日總人數 |
| 已報到人數 | 已完成 QR 報到人數 |
| 候補人數 | 等待候補的顧客 |
| No-show 數 | 未到場數量 |
| 桌位使用率 | 已使用桌位 / 可用桌位 |
| 訂金收入 | 今日已收訂金 |
| 取消率 | 取消訂位 / 總訂位 |

---

## 8.3 後台畫面建議

```text
左側選單：
- 儀表板
- 訂位管理
- 候補管理
- 桌位管理
- 時段管理
- 訂金管理
- QR Code 報到
- 分店管理
- 報表分析
- AI 預測
- 系統設定

右側內容：
- KPI 卡片
- 今日訂位表
- 熱門時段圖表
- 桌位狀態圖
- 候補名單
```

---

# 9. 多分店管理

## 9.1 功能說明

若餐廳有多個分店，系統要能分開管理資料。

每個分店可有自己的：

1. 桌位。
2. 營業時間。
3. 訂位時段。
4. 訂金規則。
5. 分店管理員。
6. 訂位資料。
7. 報表統計。

---

## 9.2 分店資料欄位

| 欄位 | 說明 |
|---|---|
| branch_name | 分店名稱 |
| phone | 分店電話 |
| address | 分店地址 |
| opening_time | 開店時間 |
| closing_time | 關店時間 |
| status | 營業、暫停、關閉 |

---

## 9.3 多分店權限規則

| 角色 | 權限 |
|---|---|
| Admin | 可查看所有分店 |
| Manager | 只能查看自己管理的分店 |
| Staff | 只能操作所屬分店的訂位 |
| Customer | 可選擇任一開放分店訂位 |

---

# 10. AI 預測熱門時段

## 10.1 功能說明

AI 根據歷史訂位資料，預測未來哪些日期與時段會熱門。

AI 可提供：

1. 熱門時段預測。
2. 未來 7 天訂位量預測。
3. 建議開放候補時段。
4. 建議人力配置。
5. 建議是否收取訂金。
6. 預測 No-show 風險。
7. 分店營運比較。

---

## 10.2 AI 使用資料

| 資料 | 說明 |
|---|---|
| 歷史訂位數 | 每日每時段訂位量 |
| 實際到店數 | 報到與完成用餐資料 |
| No-show 數 | 未到場紀錄 |
| 取消數 | 取消訂位紀錄 |
| 假日資料 | 週末、國定假日、特殊節日 |
| 天氣資料 | 雨天可能影響到店率 |
| 活動資料 | 附近活動或商圈人潮 |

---

## 10.3 AI 預測輸出範例

```text
AI 預測結果：

2026-08-03 星期六
18:00～20:00 為高峰時段
預估訂位率：92%
建議：
1. 開放候補名額 10 組
2. 6 人以上訂位需收取訂金
3. 外場人員建議增加 2 位
4. 2 人桌需求較高，避免過早合併桌
```

---

# 五、系統架構建議

## 1. 推薦技術架構

| 層級 | 技術 |
|---|---|
| 前端 | HTML、CSS、JavaScript、Bootstrap |
| 後端 | Spring Boot 3 |
| ORM | Spring Data JPA / Hibernate |
| 資料庫 | MySQL 8 |
| API | RESTful API |
| 架構 | MVC + DAO Pattern |
| 報表 | Apache POI、Power BI |
| QR Code | ZXing |
| Email | JavaMailSender |
| 簡訊 | 第三方 SMS API |
| 付款 | 第三方金流 API |
| AI | Python / OpenAI API / 預測模型 |
| 部署 | Docker / Linux Server |

---

## 2. 後端分層架構

```text
controller
    ↓
service
    ↓
dao / repository
    ↓
entity / model
    ↓
database
```

---

## 3. Java 專案資料夾建議

```text
src/main/java/com/example/reservation

├─ controller
│  ├─ CustomerController.java
│  ├─ ReservationController.java
│  ├─ BranchController.java
│  ├─ TableController.java
│  ├─ WaitlistController.java
│  ├─ PaymentController.java
│  ├─ CheckinController.java
│  ├─ DashboardController.java
│  └─ AiPredictionController.java
│
├─ service
│  ├─ CustomerService.java
│  ├─ ReservationService.java
│  ├─ TableAssignService.java
│  ├─ WaitlistService.java
│  ├─ NotificationService.java
│  ├─ PaymentService.java
│  ├─ CheckinService.java
│  ├─ DashboardService.java
│  └─ AiPredictionService.java
│
├─ service.impl
│  ├─ CustomerServiceImpl.java
│  ├─ ReservationServiceImpl.java
│  ├─ TableAssignServiceImpl.java
│  ├─ WaitlistServiceImpl.java
│  ├─ NotificationServiceImpl.java
│  ├─ PaymentServiceImpl.java
│  ├─ CheckinServiceImpl.java
│  ├─ DashboardServiceImpl.java
│  └─ AiPredictionServiceImpl.java
│
├─ dao
│  ├─ CustomerDao.java
│  ├─ ReservationDao.java
│  ├─ BranchDao.java
│  ├─ RestaurantTableDao.java
│  ├─ TimeSlotDao.java
│  ├─ WaitlistDao.java
│  ├─ PaymentDao.java
│  └─ NotificationDao.java
│
├─ dao.impl
│  ├─ CustomerDaoImpl.java
│  ├─ ReservationDaoImpl.java
│  ├─ BranchDaoImpl.java
│  ├─ RestaurantTableDaoImpl.java
│  ├─ TimeSlotDaoImpl.java
│  ├─ WaitlistDaoImpl.java
│  ├─ PaymentDaoImpl.java
│  └─ NotificationDaoImpl.java
│
├─ model
│  ├─ Customer.java
│  ├─ Reservation.java
│  ├─ Branch.java
│  ├─ RestaurantTable.java
│  ├─ TimeSlot.java
│  ├─ Waitlist.java
│  ├─ Payment.java
│  ├─ NotificationLog.java
│  └─ CheckinLog.java
│
├─ dto
│  ├─ ReservationRequest.java
│  ├─ ReservationResponse.java
│  ├─ DashboardSummaryDto.java
│  ├─ PaymentRequest.java
│  └─ AiPredictionDto.java
│
├─ util
│  ├─ DateUtil.java
│  ├─ QrCodeUtil.java
│  ├─ ExcelUtil.java
│  ├─ TokenUtil.java
│  └─ ValidationUtil.java
│
├─ exception
│  ├─ ReservationException.java
│  ├─ TableNotAvailableException.java
│  ├─ PaymentException.java
│  └─ DataNotFoundException.java
│
└─ config
   ├─ WebConfig.java
   ├─ MailConfig.java
   └─ SecurityConfig.java
```

---

# 六、資料庫設計

---

## 1. 主要資料表

| 資料表 | 說明 |
|---|---|
| customer | 顧客資料 |
| admin_user | 後台使用者 |
| branch | 分店資料 |
| restaurant_table | 餐桌資料 |
| time_slot | 可訂位時段 |
| reservation | 訂位資料 |
| reservation_table | 訂位與桌位對應 |
| waitlist | 候補資料 |
| payment | 訂金付款資料 |
| notification_log | 通知紀錄 |
| checkin_log | 報到紀錄 |
| reservation_log | 訂位異動紀錄 |
| ai_prediction | AI 預測結果 |

---

## 2. ER Model Mermaid 圖

```mermaid
erDiagram
    CUSTOMER ||--o{ RESERVATION : makes
    BRANCH ||--o{ RESERVATION : has
    BRANCH ||--o{ RESTAURANT_TABLE : owns
    BRANCH ||--o{ TIME_SLOT : provides
    TIME_SLOT ||--o{ RESERVATION : selected
    RESERVATION ||--o{ RESERVATION_TABLE : uses
    RESTAURANT_TABLE ||--o{ RESERVATION_TABLE : assigned
    RESERVATION ||--o| PAYMENT : has
    RESERVATION ||--o{ NOTIFICATION_LOG : sends
    RESERVATION ||--o{ CHECKIN_LOG : checkin
    RESERVATION ||--o{ RESERVATION_LOG : records
    CUSTOMER ||--o{ WAITLIST : joins
    BRANCH ||--o{ WAITLIST : has
    TIME_SLOT ||--o{ WAITLIST : waits
    BRANCH ||--o{ AI_PREDICTION : predicts

    CUSTOMER {
        int id PK
        string name
        string phone
        string email
        string password
        string status
    }

    BRANCH {
        int id PK
        string branch_name
        string phone
        string address
        string status
    }

    RESTAURANT_TABLE {
        int id PK
        int branch_id FK
        string table_no
        int capacity
        string status
    }

    TIME_SLOT {
        int id PK
        int branch_id FK
        time start_time
        time end_time
        int max_people
        string status
    }

    RESERVATION {
        int id PK
        int customer_id FK
        int branch_id FK
        int time_slot_id FK
        date reservation_date
        int people_count
        string status
        string note
        string checkin_token
    }

    RESERVATION_TABLE {
        int id PK
        int reservation_id FK
        int table_id FK
    }

    WAITLIST {
        int id PK
        int customer_id FK
        int branch_id FK
        int time_slot_id FK
        date wait_date
        int people_count
        string status
    }

    PAYMENT {
        int id PK
        int reservation_id FK
        decimal amount
        string payment_status
        string transaction_no
    }

    NOTIFICATION_LOG {
        int id PK
        int reservation_id FK
        string notify_type
        string status
    }

    CHECKIN_LOG {
        int id PK
        int reservation_id FK
        datetime checkin_time
        string method
    }

    RESERVATION_LOG {
        int id PK
        int reservation_id FK
        string action
        string old_status
        string new_status
    }

    AI_PREDICTION {
        int id PK
        int branch_id FK
        date predict_date
        string time_range
        decimal predicted_rate
    }
```

---

# 七、MySQL 建表 SQL 範例

```sql
CREATE DATABASE IF NOT EXISTS smart_reservation
DEFAULT CHARACTER SET utf8mb4
COLLATE utf8mb4_unicode_ci;

USE smart_reservation;

CREATE TABLE customer (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(50) NOT NULL,
    phone VARCHAR(20) NOT NULL UNIQUE,
    email VARCHAR(100),
    password VARCHAR(255),
    status VARCHAR(20) DEFAULT 'ACTIVE',
    no_show_count INT DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE admin_user (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    role VARCHAR(20) NOT NULL,
    branch_id INT NULL,
    status VARCHAR(20) DEFAULT 'ACTIVE',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE branch (
    id INT AUTO_INCREMENT PRIMARY KEY,
    branch_name VARCHAR(100) NOT NULL,
    phone VARCHAR(20),
    address VARCHAR(255),
    opening_time TIME,
    closing_time TIME,
    status VARCHAR(20) DEFAULT 'OPEN',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE restaurant_table (
    id INT AUTO_INCREMENT PRIMARY KEY,
    branch_id INT NOT NULL,
    table_no VARCHAR(20) NOT NULL,
    capacity INT NOT NULL,
    status VARCHAR(20) DEFAULT 'AVAILABLE',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (branch_id) REFERENCES branch(id)
);

CREATE TABLE time_slot (
    id INT AUTO_INCREMENT PRIMARY KEY,
    branch_id INT NOT NULL,
    start_time TIME NOT NULL,
    end_time TIME NOT NULL,
    max_people INT DEFAULT 0,
    status VARCHAR(20) DEFAULT 'OPEN',
    FOREIGN KEY (branch_id) REFERENCES branch(id)
);

CREATE TABLE reservation (
    id INT AUTO_INCREMENT PRIMARY KEY,
    customer_id INT NOT NULL,
    branch_id INT NOT NULL,
    time_slot_id INT NOT NULL,
    reservation_date DATE NOT NULL,
    people_count INT NOT NULL,
    status VARCHAR(30) DEFAULT 'PENDING',
    note VARCHAR(500),
    checkin_token VARCHAR(100),
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (customer_id) REFERENCES customer(id),
    FOREIGN KEY (branch_id) REFERENCES branch(id),
    FOREIGN KEY (time_slot_id) REFERENCES time_slot(id)
);

CREATE TABLE reservation_table (
    id INT AUTO_INCREMENT PRIMARY KEY,
    reservation_id INT NOT NULL,
    table_id INT NOT NULL,
    FOREIGN KEY (reservation_id) REFERENCES reservation(id),
    FOREIGN KEY (table_id) REFERENCES restaurant_table(id)
);

CREATE TABLE waitlist (
    id INT AUTO_INCREMENT PRIMARY KEY,
    customer_id INT NOT NULL,
    branch_id INT NOT NULL,
    time_slot_id INT NOT NULL,
    wait_date DATE NOT NULL,
    people_count INT NOT NULL,
    status VARCHAR(30) DEFAULT 'WAITING',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (customer_id) REFERENCES customer(id),
    FOREIGN KEY (branch_id) REFERENCES branch(id),
    FOREIGN KEY (time_slot_id) REFERENCES time_slot(id)
);

CREATE TABLE payment (
    id INT AUTO_INCREMENT PRIMARY KEY,
    reservation_id INT NOT NULL,
    amount DECIMAL(10,2) NOT NULL,
    payment_method VARCHAR(30),
    payment_status VARCHAR(30) DEFAULT 'UNPAID',
    transaction_no VARCHAR(100),
    paid_at DATETIME NULL,
    refunded_at DATETIME NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (reservation_id) REFERENCES reservation(id)
);

CREATE TABLE notification_log (
    id INT AUTO_INCREMENT PRIMARY KEY,
    reservation_id INT,
    customer_id INT,
    notify_type VARCHAR(30),
    notify_channel VARCHAR(20),
    subject VARCHAR(200),
    content TEXT,
    status VARCHAR(20),
    error_message VARCHAR(500),
    sent_at DATETIME,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (reservation_id) REFERENCES reservation(id),
    FOREIGN KEY (customer_id) REFERENCES customer(id)
);

CREATE TABLE checkin_log (
    id INT AUTO_INCREMENT PRIMARY KEY,
    reservation_id INT NOT NULL,
    checkin_time DATETIME DEFAULT CURRENT_TIMESTAMP,
    method VARCHAR(20),
    staff_id INT,
    note VARCHAR(300),
    FOREIGN KEY (reservation_id) REFERENCES reservation(id)
);

CREATE TABLE reservation_log (
    id INT AUTO_INCREMENT PRIMARY KEY,
    reservation_id INT NOT NULL,
    action VARCHAR(50),
    old_status VARCHAR(30),
    new_status VARCHAR(30),
    operator_id INT,
    note VARCHAR(500),
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (reservation_id) REFERENCES reservation(id)
);

CREATE TABLE ai_prediction (
    id INT AUTO_INCREMENT PRIMARY KEY,
    branch_id INT NOT NULL,
    predict_date DATE NOT NULL,
    time_range VARCHAR(50),
    predicted_reservation_count INT,
    predicted_rate DECIMAL(5,2),
    suggestion TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (branch_id) REFERENCES branch(id)
);
```

---

# 八、測試資料 SQL

```sql
USE smart_reservation;

INSERT INTO branch(branch_name, phone, address, opening_time, closing_time)
VALUES
('台北信義店', '02-11112222', '台北市信義區信義路一段 100 號', '11:00:00', '22:00:00'),
('板橋新埔店', '02-33334444', '新北市板橋區文化路一段 200 號', '11:00:00', '22:00:00');

INSERT INTO restaurant_table(branch_id, table_no, capacity, status)
VALUES
(1, 'A01', 2, 'AVAILABLE'),
(1, 'A02', 2, 'AVAILABLE'),
(1, 'B01', 4, 'AVAILABLE'),
(1, 'B02', 4, 'AVAILABLE'),
(1, 'C01', 6, 'AVAILABLE'),
(1, 'VIP01', 8, 'AVAILABLE'),
(2, 'A01', 2, 'AVAILABLE'),
(2, 'B01', 4, 'AVAILABLE'),
(2, 'C01', 6, 'AVAILABLE');

INSERT INTO time_slot(branch_id, start_time, end_time, max_people, status)
VALUES
(1, '11:30:00', '13:00:00', 30, 'OPEN'),
(1, '13:00:00', '14:30:00', 30, 'OPEN'),
(1, '17:30:00', '19:00:00', 40, 'OPEN'),
(1, '19:00:00', '20:30:00', 40, 'OPEN'),
(2, '11:30:00', '13:00:00', 20, 'OPEN'),
(2, '17:30:00', '19:00:00', 30, 'OPEN');

INSERT INTO customer(name, phone, email, password)
VALUES
('王小明', '0911111111', 'ming@example.com', '1234'),
('陳美美', '0922222222', 'may@example.com', '1234'),
('林大華', '0933333333', 'lin@example.com', '1234');

INSERT INTO admin_user(username, password, role, branch_id)
VALUES
('admin', '1234', 'ADMIN', NULL),
('manager01', '1234', 'MANAGER', 1),
('staff01', '1234', 'STAFF', 1);
```

---

# 九、RESTful API 規劃

---

## 1. 顧客 API

| 方法 | URL | 說明 |
|---|---|---|
| POST | `/api/customers/register` | 顧客註冊 |
| POST | `/api/customers/login` | 顧客登入 |
| GET | `/api/customers/{id}` | 查詢顧客資料 |
| PUT | `/api/customers/{id}` | 修改顧客資料 |
| GET | `/api/customers/{id}/reservations` | 查詢顧客訂位紀錄 |

---

## 2. 訂位 API

| 方法 | URL | 說明 |
|---|---|---|
| GET | `/api/reservations/available` | 查詢空位 |
| POST | `/api/reservations` | 建立訂位 |
| GET | `/api/reservations/{id}` | 查詢單筆訂位 |
| PUT | `/api/reservations/{id}` | 修改訂位 |
| PUT | `/api/reservations/{id}/cancel` | 取消訂位 |
| PUT | `/api/reservations/{id}/complete` | 完成訂位 |
| PUT | `/api/reservations/{id}/no-show` | 標記 No-show |

---

## 3. 桌位 API

| 方法 | URL | 說明 |
|---|---|---|
| GET | `/api/tables` | 查詢桌位 |
| POST | `/api/tables` | 新增桌位 |
| PUT | `/api/tables/{id}` | 修改桌位 |
| PUT | `/api/tables/{id}/disable` | 停用桌位 |

---

## 4. 候補 API

| 方法 | URL | 說明 |
|---|---|---|
| POST | `/api/waitlist` | 加入候補 |
| GET | `/api/waitlist` | 查詢候補名單 |
| PUT | `/api/waitlist/{id}/notify` | 通知候補者 |
| PUT | `/api/waitlist/{id}/confirm` | 候補轉正式訂位 |
| PUT | `/api/waitlist/{id}/cancel` | 取消候補 |

---

## 5. 付款 API

| 方法 | URL | 說明 |
|---|---|---|
| POST | `/api/payments/create` | 建立付款單 |
| POST | `/api/payments/callback` | 金流付款回呼 |
| GET | `/api/payments/{reservationId}` | 查詢付款狀態 |
| POST | `/api/payments/{id}/refund` | 退款 |

---

## 6. QR Code 報到 API

| 方法 | URL | 說明 |
|---|---|---|
| GET | `/api/checkin/qrcode/{reservationId}` | 產生 QR Code |
| POST | `/api/checkin/scan` | 掃碼報到 |
| GET | `/api/checkin/logs` | 查詢報到紀錄 |

---

## 7. 後台儀表板 API

| 方法 | URL | 說明 |
|---|---|---|
| GET | `/api/dashboard/summary` | 儀表板總覽 |
| GET | `/api/dashboard/today` | 今日訂位 |
| GET | `/api/dashboard/time-slot-stats` | 時段統計 |
| GET | `/api/dashboard/branch-stats` | 分店統計 |
| GET | `/api/dashboard/no-show` | No-show 統計 |

---

## 8. AI 預測 API

| 方法 | URL | 說明 |
|---|---|---|
| GET | `/api/ai/predict/popular-time` | 預測熱門時段 |
| GET | `/api/ai/predict/no-show-risk` | 預測 No-show 風險 |
| GET | `/api/ai/suggestions/staffing` | 建議人力配置 |
| POST | `/api/ai/retrain` | 重新訓練模型 |

---

# 十、畫面規劃

---

## 1. 前台畫面

| 畫面 | 功能 |
|---|---|
| 首頁 | 餐廳介紹、立即訂位 |
| 分店選擇頁 | 選擇用餐分店 |
| 線上訂位頁 | 日期、時段、人數、聯絡資料 |
| 訂位確認頁 | 顯示訂位明細 |
| 付款頁 | 訂金付款 |
| 訂位成功頁 | 顯示 QR Code |
| 會員中心 | 查詢訂位、取消訂位 |
| 候補頁 | 加入候補、查詢候補狀態 |

---

## 2. 後台畫面

| 畫面 | 功能 |
|---|---|
| 後台登入 | Staff / Manager / Admin 登入 |
| 儀表板首頁 | KPI、今日訂位、圖表 |
| 訂位管理 | 查詢、新增、修改、取消 |
| 候補管理 | 候補清單、轉正式訂位 |
| 桌位管理 | 桌位 CRUD |
| 時段管理 | 設定可訂位時段 |
| 分店管理 | 多分店 CRUD |
| 付款管理 | 查詢付款、退款 |
| QR 報到 | 掃碼報到 |
| 報表中心 | Excel、CSV、Power BI |
| AI 預測 | 顯示預測與建議 |

---

## 3. 前台 UI 流程

```mermaid
flowchart TD
    A[首頁] --> B[選擇分店]
    B --> C[選擇日期與時段]
    C --> D[輸入人數]
    D --> E[查詢空位]
    E -->|有空位| F[填寫聯絡資料]
    E -->|無空位| G[加入候補]
    F --> H[確認訂位]
    H --> I{是否需要訂金}
    I -->|是| J[付款]
    I -->|否| K[訂位成功]
    J --> K
    K --> L[產生 QR Code]
```

---

## 4. 後台 UI 流程

```mermaid
flowchart TD
    A[後台登入] --> B[儀表板]
    B --> C[訂位管理]
    B --> D[候補管理]
    B --> E[桌位管理]
    B --> F[分店管理]
    B --> G[付款管理]
    B --> H[QR 報到]
    B --> I[報表中心]
    B --> J[AI 預測]
```

---

# 十一、核心商業規則

## 1. 訂位規則

1. 訂位日期不可小於今天。
2. 訂位人數至少 1 人。
3. 訂位人數不可超過系統設定上限。
4. 同一顧客同一天同時段不可重複訂位。
5. 桌位不可在同一時段被重複分配。
6. 訂位成功後產生唯一訂位編號。
7. 訂位成功後產生 QR Code token。

---

## 2. 取消規則

1. 顧客可在用餐前 24 小時取消。
2. 少於 24 小時取消可由後台管理員處理。
3. 已報到不可取消。
4. 已完成不可取消。
5. 已付訂金的訂位要判斷是否可退款。

---

## 3. No-show 規則

1. 超過訂位時間 15～30 分鐘未到可標記 No-show。
2. No-show 次數需要記錄。
3. No-show 超過 3 次可限制線上訂位。
4. 高風險顧客可要求訂金。

---

## 4. 候補規則

1. 滿位才開放候補。
2. 候補依加入時間排序。
3. 有空位釋出時通知第一順位。
4. 通知後可設定 30 分鐘內確認。
5. 未確認則通知下一位候補者。

---

## 5. 訂金規則

1. 可依人數判斷是否收訂金。
2. 可依日期判斷是否收訂金。
3. 可依時段判斷是否收訂金。
4. 可依會員 No-show 次數判斷是否收訂金。
5. 訂金退款規則需由後台設定。

---

# 十二、後台儀表板統計 SQL 範例

---

## 1. 今日訂位數

```sql
SELECT COUNT(*) AS today_reservations
FROM reservation
WHERE reservation_date = CURDATE()
AND status IN ('CONFIRMED', 'PAID', 'CHECKED_IN');
```

---

## 2. 今日用餐人數

```sql
SELECT SUM(people_count) AS today_people
FROM reservation
WHERE reservation_date = CURDATE()
AND status IN ('CONFIRMED', 'PAID', 'CHECKED_IN');
```

---

## 3. 熱門時段排行

```sql
SELECT 
    ts.start_time,
    ts.end_time,
    COUNT(r.id) AS reservation_count
FROM reservation r
JOIN time_slot ts ON r.time_slot_id = ts.id
GROUP BY ts.id, ts.start_time, ts.end_time
ORDER BY reservation_count DESC;
```

---

## 4. No-show 比率

```sql
SELECT 
    COUNT(CASE WHEN status = 'NO_SHOW' THEN 1 END) / COUNT(*) * 100 AS no_show_rate
FROM reservation;
```

---

## 5. 分店訂位統計

```sql
SELECT 
    b.branch_name,
    COUNT(r.id) AS reservation_count,
    SUM(r.people_count) AS total_people
FROM reservation r
JOIN branch b ON r.branch_id = b.id
GROUP BY b.id, b.branch_name
ORDER BY reservation_count DESC;
```

---

# 十三、AI 預測設計

---

## 1. 初階 AI：規則式分析

不用機器學習，先用統計規則完成。

範例規則：

```text
如果某時段過去 30 天平均訂位率超過 80%，判定為熱門時段。
如果某會員 No-show 次數 >= 3，判定為高風險顧客。
如果週六晚餐平均訂位數高於平日 50%，建議增加人力。
```

---

## 2. 中階 AI：Python 預測

可使用 Python 做預測：

| 工具 | 用途 |
|---|---|
| pandas | 資料整理 |
| scikit-learn | 預測模型 |
| Prophet | 時間序列預測 |
| matplotlib / plotly | 圖表 |
| FastAPI | 提供 AI 預測 API |

---

## 3. AI 模型輸入欄位

| 欄位 | 說明 |
|---|---|
| branch_id | 分店 |
| reservation_date | 日期 |
| week_day | 星期 |
| is_weekend | 是否週末 |
| is_holiday | 是否假日 |
| time_slot | 時段 |
| historical_count | 歷史訂位量 |
| no_show_count | 未到場數 |
| cancel_count | 取消數 |
| weather | 天氣 |
| event_nearby | 附近是否有活動 |

---

## 4. AI 模型輸出欄位

| 欄位 | 說明 |
|---|---|
| predicted_count | 預測訂位數 |
| predicted_rate | 預測訂位率 |
| risk_level | 低 / 中 / 高 |
| suggestion | AI 建議 |
| staffing_advice | 人力建議 |
| deposit_advice | 訂金建議 |

---

# 十四、Power BI 報表欄位設計

---

## 1. 訂位分析資料集

| 欄位 | 說明 |
|---|---|
| reservation_id | 訂位編號 |
| branch_name | 分店 |
| reservation_date | 日期 |
| week_day | 星期 |
| time_slot | 時段 |
| people_count | 人數 |
| status | 狀態 |
| payment_status | 付款狀態 |
| amount | 訂金 |
| no_show_flag | 是否 No-show |
| checkin_flag | 是否報到 |

---

## 2. Power BI KPI

| 指標 | 計算方式 |
|---|---|
| 訂位總數 | COUNT(reservation_id) |
| 總用餐人數 | SUM(people_count) |
| 平均每筆人數 | AVG(people_count) |
| No-show 率 | No-show 數 / 訂位總數 |
| 取消率 | 取消數 / 訂位總數 |
| 訂金收入 | SUM(amount) |
| 候補轉正率 | 候補轉正數 / 候補總數 |
| 桌位使用率 | 已使用桌數 / 可用桌數 |

---

# 十五、開發里程碑

---

## 第 1 階段：基礎訂位系統

完成內容：

1. 顧客管理。
2. 分店管理。
3. 桌位管理。
4. 時段管理。
5. 新增訂位。
6. 查詢訂位。
7. 修改訂位。
8. 取消訂位。

---

## 第 2 階段：自動分桌與候補

完成內容：

1. 自動查詢空桌。
2. 自動分配桌位。
3. 候補名單。
4. 候補轉正式訂位。
5. No-show 管理。

---

## 第 3 階段：通知、付款與 QR Code

完成內容：

1. Email 通知。
2. 簡訊通知。
3. 訂金付款流程。
4. QR Code 產生。
5. QR Code 報到。
6. 付款紀錄。

---

## 第 4 階段：後台儀表板與 Power BI

完成內容：

1. 後台 KPI。
2. 今日訂位總覽。
3. 熱門時段統計。
4. 分店統計。
5. Excel / CSV 匯出。
6. Power BI 儀表板。

---

## 第 5 階段：AI 預測熱門時段

完成內容：

1. 整理歷史訂位資料。
2. 建立統計分析。
3. 建立 AI 預測 API。
4. 顯示熱門時段預測。
5. 顯示人力與訂金建議。

---

# 十六、專題展示重點

展示時不要只說「這是訂位系統」，而要強調它是完整的智慧營運平台。

建議展示順序：

```text
1. 顧客線上訂位
2. 系統自動分配桌位
3. 滿位後加入候補
4. 訂位成功收到通知
5. 付款訂金
6. 顯示 QR Code
7. 到店掃碼報到
8. 後台查看今日訂位
9. Power BI 看訂位分析
10. AI 預測未來熱門時段
```

---

# 十七、接案報價功能拆分建議

若用於接案，可以拆成不同報價版本。

## 1. 基礎版

功能：

1. 線上訂位。
2. 後台訂位管理。
3. 桌位管理。
4. 時段管理。

適合小型餐廳。

---

## 2. 標準版

功能：

1. 基礎版全部功能。
2. 自動分桌。
3. 候補系統。
4. Email 通知。
5. Excel 報表。

適合中型餐廳。

---

## 3. 進階版

功能：

1. 標準版全部功能。
2. 訂金付款。
3. QR Code 報到。
4. 多分店管理。
5. 後台儀表板。

適合連鎖餐廳。

---

## 4. 智慧版

功能：

1. 進階版全部功能。
2. Power BI 分析。
3. AI 熱門時段預測。
4. No-show 風險預測。
5. 人力配置建議。

適合企業展示與高階專題。

---

# 十八、學生專題分工建議

如果是 3～5 人專題，可以這樣分工。

| 成員 | 負責內容 |
|---|---|
| A | 前台 UI、線上訂位流程 |
| B | 後台 UI、訂位管理 |
| C | Spring Boot API、Service、DAO |
| D | MySQL、報表、Power BI |
| E | QR Code、通知、AI 預測 |

---

# 十九、驗收標準

## 1. 必做功能

1. 可建立顧客資料。
2. 可選擇分店、日期、時段、人數。
3. 可查詢空位。
4. 可建立訂位。
5. 可自動分配桌位。
6. 滿位可加入候補。
7. 可取消訂位。
8. 可查詢訂位紀錄。
9. 後台可管理訂位。
10. 後台可管理桌位與時段。

---

## 2. 進階驗收

1. 訂位成功可發送 Email。
2. 可建立付款紀錄。
3. 可產生 QR Code。
4. 可掃碼報到。
5. 可匯出 Excel。
6. Power BI 可顯示訂位分析。
7. AI 可顯示熱門時段建議。

---

# 二十、課程教學建議

如果要做成課程，可安排為 30 小時。

| 堂次 | 主題 | 內容 |
|---|---|---|
| 1 | 專案需求與資料庫 | 需求分析、ER Model、MySQL |
| 2 | Spring Boot 專案建立 | Maven、JPA、MVC 分層 |
| 3 | 顧客與分店管理 | Customer、Branch CRUD |
| 4 | 桌位與時段管理 | Table、TimeSlot CRUD |
| 5 | 線上訂位功能 | 建立訂位 API |
| 6 | 自動分桌 | 分桌演算法與 Service |
| 7 | 候補系統 | Waitlist CRUD 與轉正 |
| 8 | 通知功能 | Email / SMS 設計 |
| 9 | 訂金與 QR Code | Payment、QRCode、Check-in |
| 10 | 後台儀表板 | KPI、統計 SQL、圖表 |
| 11 | Power BI 分析 | MySQL / Excel 串接 |
| 12 | AI 預測 | Python / API / 預測展示 |
| 13 | 測試與除錯 | API 測試、流程測試 |
| 14 | 部署與展示 | Docker、簡報、專題展示 |
| 15 | 接案包裝 | 報價版本、功能拆分、Demo 話術 |

---

# 二十一、Demo 展示話術

可以這樣介紹：

```text
這套系統是一個餐廳智慧訂位管理平台。

顧客可以在線上選擇分店、日期、時段與人數，
系統會即時判斷是否有空位，並自動分配最適合的桌位。

如果熱門時段已經滿位，顧客可以加入候補。
當有人取消訂位時，系統會自動通知候補顧客。

訂位成功後，系統會發送 Email 或簡訊通知，
並產生 QR Code，讓顧客到店時快速報到。

後台管理者可以查看今日訂位、候補、No-show、訂金收入與桌位使用率。
資料也可以匯出到 Power BI 做營運分析。

最後，系統還能透過 AI 預測未來熱門時段，
協助餐廳提前安排人力、桌位與訂金策略。
```

---

# 二十二、總結

進階版訂位系統的重點不是只有 CRUD，而是要整合：

1. 線上訂位。
2. 自動分配桌位。
3. 候補名單。
4. 通知系統。
5. 訂金付款。
6. QR Code 報到。
7. 多分店管理。
8. 後台儀表板。
9. Power BI 分析。
10. AI 預測。

這樣的系統才適合拿來做：

1. 專題作品。
2. 接案展示。
3. 企業內訓範例。
4. Java 全端課程。
5. AI + 報表整合課程。
