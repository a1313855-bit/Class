# 執行步驟

## 1. 建立 MySQL 資料庫

```sql
CREATE DATABASE IF NOT EXISTS smart_reservation
DEFAULT CHARACTER SET utf8mb4
COLLATE utf8mb4_unicode_ci;
```

## 2. 修改連線設定

檔案：`src/main/resources/application.properties`

```properties
spring.datasource.username=root
spring.datasource.password=你的密碼
```

## 3. 啟動專案

```bash
mvn spring-boot:run
```

## 4. 開啟畫面

前台訂位：

```text
http://localhost:8080/index.html
```

後台管理：

```text
http://localhost:8080/admin.html
```

## 5. 測試重點

1. 前台選擇分店、日期、時段、人數。
2. 查看右側桌位平面圖。
3. 送出訂位後，桌位會自動分配。
4. 若無合適桌位，系統會加入候補。
5. 後台可查看訂位、候補、KPI 與 AI 熱門時段建議。
