# 餐廳智慧訂位系統 Smart Reservation System

本專案依照 `docs/advanced_reservation_system_plan.md` 進階版需求製作，技術規格如下：

- UI：HTML + CSS + JavaScript + Bootstrap
- 特色 UI：位置桌號平面圖，可顯示桌號、容量、狀態
- 後端：Spring Boot 3
- ORM：Spring Data JPA / Hibernate
- 資料庫：MySQL 8
- 架構：MVC + DAO Pattern
- 功能：線上訂位、自動分配桌位、候補系統、後台儀表板、QR Code Token、AI 熱門時段建議

---

## 0. 本次指定規格

本 ZIP 已依照使用者指定條件製作：

1. UI 使用 HTML + CSS + JavaScript + Bootstrap。
2. UI 加入「位置桌號平面圖」，可顯示桌號、容量、可用、已訂、維修/停用狀態。
3. 後端使用 Spring Boot 3 + Spring Data JPA + MySQL。
4. 專案分層遵守 MVC + DAO Pattern：Controller → Service → DAO/Repository → Model。
5. 功能依照 `docs/advanced_reservation_system_plan.md`：線上訂位、自動分桌、候補、QR Code Token、後台儀表板、AI 熱門時段規則式建議。

---

## 1. 執行環境

Spring Boot 3 需要 JDK 17 以上。

建議環境：

| 項目 | 版本 |
|---|---|
| JDK | 17+ |
| Maven | 3.8+ |
| MySQL | 8.0+ |
| IDE | Eclipse / IntelliJ IDEA / VS Code |

---

## 2. 建立資料庫

先在 MySQL 執行：

```sql
CREATE DATABASE IF NOT EXISTS smart_reservation
DEFAULT CHARACTER SET utf8mb4
COLLATE utf8mb4_unicode_ci;
```

或直接執行：

```text
sql/create_database.sql
```

---

## 3. 修改資料庫連線

開啟：

```text
src/main/resources/application.properties
```

修改帳號密碼：

```properties
spring.datasource.username=root
spring.datasource.password=1234
```

---

## 4. 執行專案

```bash
mvn spring-boot:run
```

啟動後開啟：

```text
前台訂位：http://localhost:8080/index.html
後台管理：http://localhost:8080/admin.html
```

---

## 5. 預設測試資料

系統第一次啟動時會自動建立測試資料：

- 分店：台北信義店、板橋新埔店
- 桌位：A01、A02、B01、B02、C01、VIP01
- 時段：午餐 1、午餐 2、晚餐 1、晚餐 2
- 測試顧客：王小明、陳美美、林大華

資料初始化程式在：

```text
src/main/java/tw/com/codebyx/reservation/config/DataInitializer.java
```

---

## 6. 專案結構

```text
src/main/java/tw/com/codebyx/reservation
├─ controller      # REST Controller，處理前後端 API
├─ service         # Service 介面
├─ service/impl    # Service 實作，商業邏輯
├─ dao             # DAO 介面
├─ dao/impl        # DAO 實作，呼叫 Spring Data JPA Repository
├─ repository      # Spring Data JPA Repository
├─ model           # JPA Entity
├─ dto             # 前後端資料傳輸物件
├─ config          # 初始化資料與設定
├─ exception       # 例外處理
└─ util            # QR Code、Token 等工具
```

---

## 7. REST API

| 方法 | URL | 說明 |
|---|---|---|
| GET | `/api/branches` | 查詢分店 |
| GET | `/api/time-slots?branchId=1` | 查詢時段 |
| GET | `/api/tables/floor-plan?branchId=1&date=2026-07-09&timeSlotId=1` | 查詢桌位平面圖 |
| POST | `/api/reservations` | 建立訂位，自動分桌，滿位加入候補 |
| GET | `/api/reservations` | 查詢所有訂位 |
| PUT | `/api/reservations/{id}/cancel` | 取消訂位 |
| PUT | `/api/reservations/{id}/checkin` | QR Code 報到示範 |
| GET | `/api/waitlist` | 查詢候補名單 |
| GET | `/api/dashboard/summary` | 後台 KPI |
| GET | `/api/ai/predictions/popular-time` | AI 熱門時段建議 |

---

## 8. 教學重點

本專案保留 MVC + DAO Pattern：

```text
HTML / JavaScript
    ↓ fetch API
Controller
    ↓
Service / ServiceImpl
    ↓
DAO / DaoImpl
    ↓
Repository
    ↓
JPA Entity
    ↓
MySQL
```

雖然 Spring Data JPA 已經具備 Repository 功能，這裡仍加入 DAO 介面與 DAO Impl，方便教學時說明 DAO Pattern。

---

## 9. 桌位平面圖說明

前台與後台都會呼叫：

```text
/api/tables/floor-plan
```

桌位狀態：

| 狀態 | 說明 |
|---|---|
| AVAILABLE | 可訂位 |
| RESERVED | 已被訂位 |
| DISABLED | 停用或維修 |

桌位座標欄位在 `RestaurantTable`：

```java
floorX
floorY
floorW
floorH
zone
```

可用來控制平面圖上的位置、大小與區域。

---

## 10. 注意事項

1. 本專案是教學版，金流與簡訊沒有串接真實第三方服務。
2. QR Code 目前以 checkinToken 示範流程，可後續用 ZXing 產生圖片。
3. AI 預測目前是規則式分析，後續可改成 Python / FastAPI 模型。
4. Power BI 可直接連 MySQL，或由後端新增 Excel / CSV 匯出 API。
