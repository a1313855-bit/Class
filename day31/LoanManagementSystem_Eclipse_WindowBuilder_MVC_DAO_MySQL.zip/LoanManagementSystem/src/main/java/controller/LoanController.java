package controller;

import exception.LoanException;
import model.Loan;
import model.PaymentSchedule;
import service.LoanService;
import service.impl.LoanServiceImpl;

import java.io.File;
import java.util.List;

public class LoanController {

    private final LoanService loanService = new LoanServiceImpl();

    public void initializeDatabase() throws LoanException {
        loanService.initializeDatabase();
    }

    public List<PaymentSchedule> generateSchedule(Loan loan) throws LoanException {
        return loanService.generateSchedule(loan);
    }

    public int saveLoanWithSchedule(Loan loan, List<PaymentSchedule> schedules) throws LoanException {
        return loanService.saveLoanWithSchedule(loan, schedules);
    }

    public List<Loan> findAllLoans() throws LoanException {
        return loanService.findAllLoans();
    }

    public Loan findLoanById(int loanId) throws LoanException {
        return loanService.findLoanById(loanId);
    }

    public List<PaymentSchedule> findSchedulesByLoanId(int loanId) throws LoanException {
        return loanService.findSchedulesByLoanId(loanId);
    }

    public void deleteLoan(int loanId) throws LoanException {
        loanService.deleteLoan(loanId);
    }

    public void exportExcelReport(Loan loan, List<PaymentSchedule> schedules, File outputFile) throws LoanException {
        loanService.exportExcelReport(loan, schedules, outputFile);
    }
}
