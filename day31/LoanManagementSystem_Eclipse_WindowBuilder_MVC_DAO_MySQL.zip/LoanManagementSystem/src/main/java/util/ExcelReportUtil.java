package util;

import exception.LoanException;
import model.Loan;
import model.PaymentSchedule;
import org.apache.poi.ss.usermodel.BorderStyle;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.HorizontalAlignment;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.math.BigDecimal;
import java.time.format.DateTimeFormatter;
import java.util.List;

public class ExcelReportUtil {

    private ExcelReportUtil() {
    }

    public static void exportLoanSchedule(Loan loan, List<PaymentSchedule> schedules, File outputFile)
            throws LoanException {
        try (Workbook workbook = new XSSFWorkbook()) {
            Sheet sheet = workbook.createSheet("貸款排程");

            CellStyle titleStyle = createTitleStyle(workbook);
            CellStyle headerStyle = createHeaderStyle(workbook);
            CellStyle labelStyle = createLabelStyle(workbook);
            CellStyle moneyStyle = createMoneyStyle(workbook);
            CellStyle dateStyle = createDateStyle(workbook);
            CellStyle percentStyle = createPercentStyle(workbook);
            CellStyle normalStyle = createNormalStyle(workbook);

            Row titleRow = sheet.createRow(0);
            Cell titleCell = titleRow.createCell(1);
            titleCell.setCellValue("貸款分期償還排程");
            titleCell.setCellStyle(titleStyle);
            sheet.addMergedRegion(new CellRangeAddress(0, 0, 1, 10));

            createCell(sheet, 2, 2, "輸入值", headerStyle);
            createCell(sheet, 2, 6, "貸款摘要", headerStyle);

            createCell(sheet, 3, 2, "貸款名稱", labelStyle);
            createCell(sheet, 3, 4, loan.getLoanName(), normalStyle);
            createCell(sheet, 4, 2, "貸款金額", labelStyle);
            createNumericCell(sheet, 4, 4, loan.getPrincipal(), moneyStyle);
            createCell(sheet, 5, 2, "年利率", labelStyle);
            createNumericCell(sheet, 5, 4, loan.getAnnualRate(), percentStyle);
            createCell(sheet, 6, 2, "貸款期間 (年計)", labelStyle);
            createNumericCell(sheet, 6, 4, loan.getLoanYears(), normalStyle);
            createCell(sheet, 7, 2, "每年還款次數", labelStyle);
            createNumericCell(sheet, 7, 4, loan.getPaymentsPerYear(), normalStyle);
            createCell(sheet, 8, 2, "貸款開始日期", labelStyle);
            createCell(sheet, 8, 4, loan.getStartDate().format(DateTimeFormatter.ISO_LOCAL_DATE), dateStyle);
            createCell(sheet, 9, 2, "選擇性額外還款", labelStyle);
            createNumericCell(sheet, 9, 4, loan.getExtraPayment(), moneyStyle);

            createCell(sheet, 3, 6, "放款方名稱", labelStyle);
            createCell(sheet, 3, 8, loan.getLenderName(), normalStyle);
            createCell(sheet, 4, 6, "借款人", labelStyle);
            createCell(sheet, 4, 8, loan.getBorrowerName(), normalStyle);
            createCell(sheet, 5, 6, "已排程還款", labelStyle);
            createNumericCell(sheet, 5, 8, loan.getScheduledPayment(), moneyStyle);
            createCell(sheet, 6, 6, "已排程還款次數", labelStyle);
            createNumericCell(sheet, 6, 8, loan.getScheduledPaymentCount(), normalStyle);
            createCell(sheet, 7, 6, "實際還款次數", labelStyle);
            createNumericCell(sheet, 7, 8, loan.getActualPaymentCount(), normalStyle);
            createCell(sheet, 8, 6, "提早還款總金額", labelStyle);
            createNumericCell(sheet, 8, 8, loan.getExtraPaymentTotal(), moneyStyle);
            createCell(sheet, 9, 6, "總利息", labelStyle);
            createNumericCell(sheet, 9, 8, loan.getTotalInterest(), moneyStyle);

            String[] headers = {
                    "還款編號", "還款日", "期初餘額", "已排程還款", "額外還款",
                    "還款總金額", "本金", "利息", "結餘", "累計利息"
            };
            Row headerRow = sheet.createRow(11);
            for (int i = 0; i < headers.length; i++) {
                Cell cell = headerRow.createCell(i + 1);
                cell.setCellValue(headers[i]);
                cell.setCellStyle(headerStyle);
            }

            int rowIndex = 12;
            for (PaymentSchedule schedule : schedules) {
                Row row = sheet.createRow(rowIndex++);
                createNumericCell(row, 1, schedule.getPaymentNo(), normalStyle);
                createCell(row, 2, schedule.getPaymentDate().format(DateTimeFormatter.ISO_LOCAL_DATE), dateStyle);
                createNumericCell(row, 3, schedule.getBeginningBalance(), moneyStyle);
                createNumericCell(row, 4, schedule.getScheduledPayment(), moneyStyle);
                createNumericCell(row, 5, schedule.getExtraPayment(), moneyStyle);
                createNumericCell(row, 6, schedule.getTotalPayment(), moneyStyle);
                createNumericCell(row, 7, schedule.getPrincipalPayment(), moneyStyle);
                createNumericCell(row, 8, schedule.getInterestPayment(), moneyStyle);
                createNumericCell(row, 9, schedule.getEndingBalance(), moneyStyle);
                createNumericCell(row, 10, schedule.getCumulativeInterest(), moneyStyle);
            }

            for (int i = 1; i <= 10; i++) {
                sheet.autoSizeColumn(i);
                if (sheet.getColumnWidth(i) < 3200) {
                    sheet.setColumnWidth(i, 3200);
                }
            }

            sheet.setRepeatingRows(CellRangeAddress.valueOf("12:12"));
            sheet.getPrintSetup().setLandscape(true);
            sheet.getPrintSetup().setFitWidth((short) 1);
            sheet.getPrintSetup().setFitHeight((short) 0);

            try (FileOutputStream out = new FileOutputStream(outputFile)) {
                workbook.write(out);
            }
        } catch (IOException e) {
            throw new LoanException("匯出 Excel 報表失敗", e);
        }
    }

    private static CellStyle createTitleStyle(Workbook workbook) {
        CellStyle style = workbook.createCellStyle();
        style.setAlignment(HorizontalAlignment.CENTER);
        org.apache.poi.ss.usermodel.Font font = workbook.createFont();
        font.setBold(true);
        font.setFontHeightInPoints((short) 18);
        style.setFont(font);
        return style;
    }

    private static CellStyle createHeaderStyle(Workbook workbook) {
        CellStyle style = workbook.createCellStyle();
        style.setFillForegroundColor(IndexedColors.GREY_25_PERCENT.getIndex());
        style.setFillPattern(FillPatternType.SOLID_FOREGROUND);
        style.setAlignment(HorizontalAlignment.CENTER);
        style.setBorderBottom(BorderStyle.THIN);
        style.setBorderTop(BorderStyle.THIN);
        style.setBorderLeft(BorderStyle.THIN);
        style.setBorderRight(BorderStyle.THIN);
        org.apache.poi.ss.usermodel.Font font = workbook.createFont();
        font.setBold(true);
        style.setFont(font);
        return style;
    }

    private static CellStyle createLabelStyle(Workbook workbook) {
        CellStyle style = createNormalStyle(workbook);
        style.setFillForegroundColor(IndexedColors.LEMON_CHIFFON.getIndex());
        style.setFillPattern(FillPatternType.SOLID_FOREGROUND);
        return style;
    }

    private static CellStyle createMoneyStyle(Workbook workbook) {
        CellStyle style = createNormalStyle(workbook);
        style.setDataFormat(workbook.createDataFormat().getFormat("#,##0.00"));
        return style;
    }

    private static CellStyle createDateStyle(Workbook workbook) {
        CellStyle style = createNormalStyle(workbook);
        style.setDataFormat(workbook.createDataFormat().getFormat("yyyy-mm-dd"));
        return style;
    }

    private static CellStyle createPercentStyle(Workbook workbook) {
        CellStyle style = createNormalStyle(workbook);
        style.setDataFormat(workbook.createDataFormat().getFormat("0.00%"));
        return style;
    }

    private static CellStyle createNormalStyle(Workbook workbook) {
        CellStyle style = workbook.createCellStyle();
        style.setBorderBottom(BorderStyle.THIN);
        style.setBorderTop(BorderStyle.THIN);
        style.setBorderLeft(BorderStyle.THIN);
        style.setBorderRight(BorderStyle.THIN);
        return style;
    }

    private static void createCell(Sheet sheet, int rowIndex, int colIndex, String value, CellStyle style) {
        Row row = sheet.getRow(rowIndex);
        if (row == null) {
            row = sheet.createRow(rowIndex);
        }
        createCell(row, colIndex, value, style);
    }

    private static void createCell(Row row, int colIndex, String value, CellStyle style) {
        Cell cell = row.createCell(colIndex);
        cell.setCellValue(value);
        cell.setCellStyle(style);
    }

    private static void createNumericCell(Sheet sheet, int rowIndex, int colIndex, BigDecimal value, CellStyle style) {
        Row row = sheet.getRow(rowIndex);
        if (row == null) {
            row = sheet.createRow(rowIndex);
        }
        createNumericCell(row, colIndex, value, style);
    }

    private static void createNumericCell(Sheet sheet, int rowIndex, int colIndex, int value, CellStyle style) {
        Row row = sheet.getRow(rowIndex);
        if (row == null) {
            row = sheet.createRow(rowIndex);
        }
        createNumericCell(row, colIndex, value, style);
    }

    private static void createNumericCell(Row row, int colIndex, BigDecimal value, CellStyle style) {
        Cell cell = row.createCell(colIndex);
        cell.setCellValue(value.doubleValue());
        cell.setCellStyle(style);
    }

    private static void createNumericCell(Row row, int colIndex, int value, CellStyle style) {
        Cell cell = row.createCell(colIndex);
        cell.setCellValue(value);
        cell.setCellStyle(style);
    }
}
