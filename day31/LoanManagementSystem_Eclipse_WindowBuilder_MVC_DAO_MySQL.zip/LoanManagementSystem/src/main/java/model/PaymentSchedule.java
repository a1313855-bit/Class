package model;

import java.math.BigDecimal;
import java.time.LocalDate;

public class PaymentSchedule {
    private Integer id;
    private Integer loanId;
    private int paymentNo;
    private LocalDate paymentDate;
    private BigDecimal beginningBalance;
    private BigDecimal scheduledPayment;
    private BigDecimal extraPayment;
    private BigDecimal totalPayment;
    private BigDecimal principalPayment;
    private BigDecimal interestPayment;
    private BigDecimal endingBalance;
    private BigDecimal cumulativeInterest;

    public Integer getId() { return id; }
    public void setId(Integer id) { this.id = id; }
    public Integer getLoanId() { return loanId; }
    public void setLoanId(Integer loanId) { this.loanId = loanId; }
    public int getPaymentNo() { return paymentNo; }
    public void setPaymentNo(int paymentNo) { this.paymentNo = paymentNo; }
    public LocalDate getPaymentDate() { return paymentDate; }
    public void setPaymentDate(LocalDate paymentDate) { this.paymentDate = paymentDate; }
    public BigDecimal getBeginningBalance() { return beginningBalance; }
    public void setBeginningBalance(BigDecimal beginningBalance) { this.beginningBalance = beginningBalance; }
    public BigDecimal getScheduledPayment() { return scheduledPayment; }
    public void setScheduledPayment(BigDecimal scheduledPayment) { this.scheduledPayment = scheduledPayment; }
    public BigDecimal getExtraPayment() { return extraPayment; }
    public void setExtraPayment(BigDecimal extraPayment) { this.extraPayment = extraPayment; }
    public BigDecimal getTotalPayment() { return totalPayment; }
    public void setTotalPayment(BigDecimal totalPayment) { this.totalPayment = totalPayment; }
    public BigDecimal getPrincipalPayment() { return principalPayment; }
    public void setPrincipalPayment(BigDecimal principalPayment) { this.principalPayment = principalPayment; }
    public BigDecimal getInterestPayment() { return interestPayment; }
    public void setInterestPayment(BigDecimal interestPayment) { this.interestPayment = interestPayment; }
    public BigDecimal getEndingBalance() { return endingBalance; }
    public void setEndingBalance(BigDecimal endingBalance) { this.endingBalance = endingBalance; }
    public BigDecimal getCumulativeInterest() { return cumulativeInterest; }
    public void setCumulativeInterest(BigDecimal cumulativeInterest) { this.cumulativeInterest = cumulativeInterest; }
}
