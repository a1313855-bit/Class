package model;

import javax.swing.table.AbstractTableModel;
import java.util.ArrayList;
import java.util.List;

public class PaymentScheduleTableModel extends AbstractTableModel {

    private final String[] columns = {
            "還款編號", "還款日", "期初餘額", "已排程還款", "額外還款",
            "還款總金額", "本金", "利息", "結餘", "累計利息"
    };

    private List<PaymentSchedule> rows = new ArrayList<>();

    public void setRows(List<PaymentSchedule> rows) {
        this.rows = rows == null ? new ArrayList<>() : rows;
        fireTableDataChanged();
    }

    public List<PaymentSchedule> getRows() {
        return rows;
    }

    @Override
    public int getRowCount() {
        return rows.size();
    }

    @Override
    public int getColumnCount() {
        return columns.length;
    }

    @Override
    public String getColumnName(int column) {
        return columns[column];
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        PaymentSchedule row = rows.get(rowIndex);
        switch (columnIndex) {
            case 0: return row.getPaymentNo();
            case 1: return row.getPaymentDate();
            case 2: return row.getBeginningBalance();
            case 3: return row.getScheduledPayment();
            case 4: return row.getExtraPayment();
            case 5: return row.getTotalPayment();
            case 6: return row.getPrincipalPayment();
            case 7: return row.getInterestPayment();
            case 8: return row.getEndingBalance();
            case 9: return row.getCumulativeInterest();
            default: return null;
        }
    }
}
