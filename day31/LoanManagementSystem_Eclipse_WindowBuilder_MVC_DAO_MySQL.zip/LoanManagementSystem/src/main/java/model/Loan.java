package model;

import java.math.BigDecimal;
import java.time.LocalDate;

public class Loan {
    private Integer id;
    private String loanName;
    private String lenderName;
    private String borrowerName;
    private BigDecimal principal;
    private BigDecimal annualRate;
    private int loanYears;
    private int paymentsPerYear;
    private LocalDate startDate;
    private BigDecimal extraPayment;
    private BigDecimal scheduledPayment;
    private int scheduledPaymentCount;
    private int actualPaymentCount;
    private BigDecimal extraPaymentTotal;
    private BigDecimal totalInterest;

    public Integer getId() { return id; }
    public void setId(Integer id) { this.id = id; }
    public String getLoanName() { return loanName; }
    public void setLoanName(String loanName) { this.loanName = loanName; }
    public String getLenderName() { return lenderName; }
    public void setLenderName(String lenderName) { this.lenderName = lenderName; }
    public String getBorrowerName() { return borrowerName; }
    public void setBorrowerName(String borrowerName) { this.borrowerName = borrowerName; }
    public BigDecimal getPrincipal() { return principal; }
    public void setPrincipal(BigDecimal principal) { this.principal = principal; }
    public BigDecimal getAnnualRate() { return annualRate; }
    public void setAnnualRate(BigDecimal annualRate) { this.annualRate = annualRate; }
    public int getLoanYears() { return loanYears; }
    public void setLoanYears(int loanYears) { this.loanYears = loanYears; }
    public int getPaymentsPerYear() { return paymentsPerYear; }
    public void setPaymentsPerYear(int paymentsPerYear) { this.paymentsPerYear = paymentsPerYear; }
    public LocalDate getStartDate() { return startDate; }
    public void setStartDate(LocalDate startDate) { this.startDate = startDate; }
    public BigDecimal getExtraPayment() { return extraPayment; }
    public void setExtraPayment(BigDecimal extraPayment) { this.extraPayment = extraPayment; }
    public BigDecimal getScheduledPayment() { return scheduledPayment; }
    public void setScheduledPayment(BigDecimal scheduledPayment) { this.scheduledPayment = scheduledPayment; }
    public int getScheduledPaymentCount() { return scheduledPaymentCount; }
    public void setScheduledPaymentCount(int scheduledPaymentCount) { this.scheduledPaymentCount = scheduledPaymentCount; }
    public int getActualPaymentCount() { return actualPaymentCount; }
    public void setActualPaymentCount(int actualPaymentCount) { this.actualPaymentCount = actualPaymentCount; }
    public BigDecimal getExtraPaymentTotal() { return extraPaymentTotal; }
    public void setExtraPaymentTotal(BigDecimal extraPaymentTotal) { this.extraPaymentTotal = extraPaymentTotal; }
    public BigDecimal getTotalInterest() { return totalInterest; }
    public void setTotalInterest(BigDecimal totalInterest) { this.totalInterest = totalInterest; }

    @Override
    public String toString() {
        return id + " - " + loanName;
    }
}
