package view;

import controller.LoanController;
import exception.LoanException;
import model.Loan;
import model.PaymentSchedule;
import model.PaymentScheduleTableModel;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.io.File;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class LoanManagementFrame extends JFrame {

    private JTextField loanNameField;
    private JTextField lenderNameField;
    private JTextField borrowerNameField;
    private JTextField principalField;
    private JTextField annualRateField;
    private JTextField loanYearsField;
    private JTextField paymentsPerYearField;
    private JTextField startDateField;
    private JTextField extraPaymentField;
    private JTextField scheduledPaymentField;
    private JTextField actualPaymentCountField;
    private JTextField extraPaymentTotalField;
    private JTextField totalInterestField;
    private JComboBox<Loan> loanComboBox;
    private JTable scheduleTable;
    private PaymentScheduleTableModel scheduleTableModel;

    private final LoanController loanController = new LoanController();
    private Loan currentLoan;
    private List<PaymentSchedule> currentSchedules = new ArrayList<>();

    public LoanManagementFrame() {
        setTitle("貸款管理系統 - Eclipse WindowBuilder MVC DAO MySQL");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1180, 760);
        setLocationRelativeTo(null);
        initDatabase();
        initComponents();
        bindEvents();
        loadLoans();
    }

    private void initDatabase() {
        try {
            loanController.initializeDatabase();
        } catch (LoanException e) {
            showError(e);
        }
    }

    private void initComponents() {
        JPanel mainPanel = new JPanel(new BorderLayout(10, 10));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        setContentPane(mainPanel);

        mainPanel.add(createInputPanel(), BorderLayout.WEST);

        scheduleTableModel = new PaymentScheduleTableModel();
        scheduleTable = new JTable(scheduleTableModel);
        scheduleTable.setRowHeight(26);
        mainPanel.add(new JScrollPane(scheduleTable), BorderLayout.CENTER);

        mainPanel.add(createButtonPanel(), BorderLayout.SOUTH);
    }

    private JPanel createInputPanel() {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBorder(BorderFactory.createTitledBorder("貸款資料輸入"));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(4, 4, 4, 4);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.weightx = 1.0;

        loanComboBox = new JComboBox<>();
        loanNameField = new JTextField("範例貸款", 18);
        lenderNameField = new JTextField("Woodgrove Bank", 18);
        borrowerNameField = new JTextField("王小明", 18);
        principalField = new JTextField("5000", 18);
        annualRateField = new JTextField("4", 18);
        loanYearsField = new JTextField("1", 18);
        paymentsPerYearField = new JTextField("12", 18);
        startDateField = new JTextField(LocalDate.now().toString(), 18);
        extraPaymentField = new JTextField("100", 18);
        scheduledPaymentField = new JTextField(18);
        actualPaymentCountField = new JTextField(18);
        extraPaymentTotalField = new JTextField(18);
        totalInterestField = new JTextField(18);

        scheduledPaymentField.setEditable(false);
        actualPaymentCountField.setEditable(false);
        extraPaymentTotalField.setEditable(false);
        totalInterestField.setEditable(false);

        int row = 0;
        addRow(panel, gbc, row++, "資料庫貸款", loanComboBox);
        addRow(panel, gbc, row++, "貸款名稱", loanNameField);
        addRow(panel, gbc, row++, "放款方名稱", lenderNameField);
        addRow(panel, gbc, row++, "借款人", borrowerNameField);
        addRow(panel, gbc, row++, "貸款金額", principalField);
        addRow(panel, gbc, row++, "年利率 (%)", annualRateField);
        addRow(panel, gbc, row++, "貸款期間 (年)", loanYearsField);
        addRow(panel, gbc, row++, "每年還款次數", paymentsPerYearField);
        addRow(panel, gbc, row++, "貸款開始日期", startDateField);
        addRow(panel, gbc, row++, "選擇性額外還款", extraPaymentField);
        addRow(panel, gbc, row++, "已排程還款", scheduledPaymentField);
        addRow(panel, gbc, row++, "實際還款次數", actualPaymentCountField);
        addRow(panel, gbc, row++, "提早還款總金額", extraPaymentTotalField);
        addRow(panel, gbc, row, "總利息", totalInterestField);
        return panel;
    }

    private void addRow(JPanel panel, GridBagConstraints gbc, int row, String label, java.awt.Component component) {
        gbc.gridx = 0;
        gbc.gridy = row;
        gbc.weightx = 0;
        panel.add(new JLabel(label), gbc);
        gbc.gridx = 1;
        gbc.weightx = 1;
        panel.add(component, gbc);
    }

    private JPanel createButtonPanel() {
        JPanel panel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        JButton newButton = new JButton("清空");
        JButton generateButton = new JButton("產生試算");
        JButton saveButton = new JButton("存入資料庫");
        JButton loadButton = new JButton("載入資料庫");
        JButton exportButton = new JButton("匯出 Excel 報表");
        JButton deleteButton = new JButton("刪除貸款");

        newButton.setActionCommand("new");
        generateButton.setActionCommand("generate");
        saveButton.setActionCommand("save");
        loadButton.setActionCommand("load");
        exportButton.setActionCommand("export");
        deleteButton.setActionCommand("delete");

        panel.add(newButton);
        panel.add(generateButton);
        panel.add(saveButton);
        panel.add(loadButton);
        panel.add(exportButton);
        panel.add(deleteButton);

        newButton.addActionListener(e -> clearForm());
        generateButton.addActionListener(e -> generateSchedule());
        saveButton.addActionListener(e -> saveLoan());
        loadButton.addActionListener(e -> loadSelectedLoan());
        exportButton.addActionListener(e -> exportExcel());
        deleteButton.addActionListener(e -> deleteSelectedLoan());

        return panel;
    }

    private void bindEvents() {
        loanComboBox.addActionListener(e -> {
            Loan selected = (Loan) loanComboBox.getSelectedItem();
            if (selected != null && selected.getId() != null) {
                // 只切換選項，不自動載入，避免使用者輸入一半被覆蓋。
            }
        });
    }

    private Loan readLoanFromForm() {
        Loan loan = new Loan();
        loan.setLoanName(loanNameField.getText().trim());
        loan.setLenderName(lenderNameField.getText().trim());
        loan.setBorrowerName(borrowerNameField.getText().trim());
        loan.setPrincipal(new BigDecimal(principalField.getText().trim()));
        BigDecimal ratePercent = new BigDecimal(annualRateField.getText().trim());
        loan.setAnnualRate(ratePercent.divide(BigDecimal.valueOf(100)));
        loan.setLoanYears(Integer.parseInt(loanYearsField.getText().trim()));
        loan.setPaymentsPerYear(Integer.parseInt(paymentsPerYearField.getText().trim()));
        loan.setStartDate(LocalDate.parse(startDateField.getText().trim()));
        loan.setExtraPayment(new BigDecimal(extraPaymentField.getText().trim()));
        return loan;
    }

    private void generateSchedule() {
        try {
            currentLoan = readLoanFromForm();
            currentSchedules = loanController.generateSchedule(currentLoan);
            scheduleTableModel.setRows(currentSchedules);
            refreshSummary(currentLoan);
        } catch (Exception e) {
            showError(e);
        }
    }

    private void refreshSummary(Loan loan) {
        scheduledPaymentField.setText(String.valueOf(loan.getScheduledPayment()));
        actualPaymentCountField.setText(String.valueOf(loan.getActualPaymentCount()));
        extraPaymentTotalField.setText(String.valueOf(loan.getExtraPaymentTotal()));
        totalInterestField.setText(String.valueOf(loan.getTotalInterest()));
    }

    private void saveLoan() {
        try {
            if (currentLoan == null || currentSchedules.isEmpty()) {
                generateSchedule();
            }
            int id = loanController.saveLoanWithSchedule(currentLoan, currentSchedules);
            JOptionPane.showMessageDialog(this, "已存入資料庫，貸款 ID：" + id);
            loadLoans();
        } catch (Exception e) {
            showError(e);
        }
    }

    private void loadLoans() {
        try {
            loanComboBox.removeAllItems();
            for (Loan loan : loanController.findAllLoans()) {
                loanComboBox.addItem(loan);
            }
        } catch (LoanException e) {
            showError(e);
        }
    }

    private void loadSelectedLoan() {
        try {
            Loan selected = (Loan) loanComboBox.getSelectedItem();
            if (selected == null) {
                return;
            }
            currentLoan = loanController.findLoanById(selected.getId());
            currentSchedules = loanController.findSchedulesByLoanId(selected.getId());
            fillForm(currentLoan);
            scheduleTableModel.setRows(currentSchedules);
        } catch (Exception e) {
            showError(e);
        }
    }

    private void fillForm(Loan loan) {
        loanNameField.setText(loan.getLoanName());
        lenderNameField.setText(loan.getLenderName());
        borrowerNameField.setText(loan.getBorrowerName());
        principalField.setText(String.valueOf(loan.getPrincipal()));
        annualRateField.setText(String.valueOf(loan.getAnnualRate().multiply(BigDecimal.valueOf(100))));
        loanYearsField.setText(String.valueOf(loan.getLoanYears()));
        paymentsPerYearField.setText(String.valueOf(loan.getPaymentsPerYear()));
        startDateField.setText(String.valueOf(loan.getStartDate()));
        extraPaymentField.setText(String.valueOf(loan.getExtraPayment()));
        refreshSummary(loan);
    }

    private void exportExcel() {
        try {
            if (currentLoan == null || currentSchedules.isEmpty()) {
                generateSchedule();
            }
            JFileChooser chooser = new JFileChooser();
            chooser.setSelectedFile(new File("loan_schedule_report.xlsx"));
            if (chooser.showSaveDialog(this) != JFileChooser.APPROVE_OPTION) {
                return;
            }
            File output = chooser.getSelectedFile();
            if (!output.getName().toLowerCase().endsWith(".xlsx")) {
                output = new File(output.getParentFile(), output.getName() + ".xlsx");
            }
            loanController.exportExcelReport(currentLoan, currentSchedules, output);
            JOptionPane.showMessageDialog(this, "Excel 報表已匯出：" + output.getAbsolutePath());
        } catch (Exception e) {
            showError(e);
        }
    }

    private void deleteSelectedLoan() {
        try {
            Loan selected = (Loan) loanComboBox.getSelectedItem();
            if (selected == null) {
                return;
            }
            int result = JOptionPane.showConfirmDialog(this,
                    "確定刪除：" + selected.getLoanName() + "？",
                    "確認刪除",
                    JOptionPane.YES_NO_OPTION);
            if (result != JOptionPane.YES_OPTION) {
                return;
            }
            loanController.deleteLoan(selected.getId());
            clearForm();
            loadLoans();
        } catch (Exception e) {
            showError(e);
        }
    }

    private void clearForm() {
        currentLoan = null;
        currentSchedules = new ArrayList<>();
        loanNameField.setText("新貸款");
        lenderNameField.setText("Woodgrove Bank");
        borrowerNameField.setText("");
        principalField.setText("5000");
        annualRateField.setText("4");
        loanYearsField.setText("1");
        paymentsPerYearField.setText("12");
        startDateField.setText(LocalDate.now().toString());
        extraPaymentField.setText("0");
        scheduledPaymentField.setText("");
        actualPaymentCountField.setText("");
        extraPaymentTotalField.setText("");
        totalInterestField.setText("");
        scheduleTableModel.setRows(currentSchedules);
    }

    private void showError(Exception e) {
        e.printStackTrace();
        JOptionPane.showMessageDialog(this, e.getMessage(), "錯誤", JOptionPane.ERROR_MESSAGE);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new LoanManagementFrame().setVisible(true));
    }
}
