package dao;

import exception.LoanException;
import model.Loan;
import model.PaymentSchedule;

import java.util.List;

public interface LoanDao {
    int insertLoan(Loan loan) throws LoanException;
    void insertPaymentSchedules(int loanId, List<PaymentSchedule> schedules) throws LoanException;
    List<Loan> findAllLoans() throws LoanException;
    Loan findLoanById(int id) throws LoanException;
    List<PaymentSchedule> findSchedulesByLoanId(int loanId) throws LoanException;
    void deleteLoan(int loanId) throws LoanException;
    void initializeDatabase() throws LoanException;
}
