package dao.impl;

import dao.LoanDao;
import exception.LoanException;
import model.Loan;
import model.PaymentSchedule;
import util.DBUtil;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class LoanDaoImpl implements LoanDao {

    @Override
    public void initializeDatabase() throws LoanException {
        String createLoanTable = "CREATE TABLE IF NOT EXISTS loans ("
                + "id INT NOT NULL AUTO_INCREMENT,"
                + "loan_name VARCHAR(100) NOT NULL,"
                + "lender_name VARCHAR(100) NOT NULL,"
                + "borrower_name VARCHAR(100) NOT NULL,"
                + "principal DECIMAL(15,2) NOT NULL,"
                + "annual_rate DECIMAL(8,6) NOT NULL,"
                + "loan_years INT NOT NULL,"
                + "payments_per_year INT NOT NULL,"
                + "start_date DATE NOT NULL,"
                + "extra_payment DECIMAL(15,2) NOT NULL DEFAULT 0,"
                + "scheduled_payment DECIMAL(15,2) NOT NULL DEFAULT 0,"
                + "scheduled_payment_count INT NOT NULL DEFAULT 0,"
                + "actual_payment_count INT NOT NULL DEFAULT 0,"
                + "extra_payment_total DECIMAL(15,2) NOT NULL DEFAULT 0,"
                + "total_interest DECIMAL(15,2) NOT NULL DEFAULT 0,"
                + "created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,"
                + "PRIMARY KEY (id)"
                + ") ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";

        String createScheduleTable = "CREATE TABLE IF NOT EXISTS loan_payments ("
                + "id INT NOT NULL AUTO_INCREMENT,"
                + "loan_id INT NOT NULL,"
                + "payment_no INT NOT NULL,"
                + "payment_date DATE NOT NULL,"
                + "beginning_balance DECIMAL(15,2) NOT NULL,"
                + "scheduled_payment DECIMAL(15,2) NOT NULL,"
                + "extra_payment DECIMAL(15,2) NOT NULL,"
                + "total_payment DECIMAL(15,2) NOT NULL,"
                + "principal_payment DECIMAL(15,2) NOT NULL,"
                + "interest_payment DECIMAL(15,2) NOT NULL,"
                + "ending_balance DECIMAL(15,2) NOT NULL,"
                + "cumulative_interest DECIMAL(15,2) NOT NULL,"
                + "PRIMARY KEY (id),"
                + "KEY idx_loan_payments_loan_id (loan_id),"
                + "CONSTRAINT fk_loan_payments_loan FOREIGN KEY (loan_id) REFERENCES loans(id) ON DELETE CASCADE"
                + ") ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";

        try (Connection conn = DBUtil.getConnection();
             Statement stmt = conn.createStatement()) {
            stmt.execute(createLoanTable);
            stmt.execute(createScheduleTable);
        } catch (SQLException e) {
            throw new LoanException("初始化資料庫失敗", e);
        }
    }

    @Override
    public int insertLoan(Loan loan) throws LoanException {
        String sql = "INSERT INTO loans "
                + "(loan_name, lender_name, borrower_name, principal, annual_rate, loan_years, "
                + "payments_per_year, start_date, extra_payment, scheduled_payment, "
                + "scheduled_payment_count, actual_payment_count, extra_payment_total, total_interest) "
                + "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

        try (Connection conn = DBUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            fillLoanStatement(ps, loan);
            ps.executeUpdate();
            try (ResultSet rs = ps.getGeneratedKeys()) {
                if (rs.next()) {
                    return rs.getInt(1);
                }
            }
            throw new LoanException("新增貸款失敗：無法取得 ID");
        } catch (SQLException e) {
            throw new LoanException("新增貸款失敗", e);
        }
    }

    private void fillLoanStatement(PreparedStatement ps, Loan loan) throws SQLException {
        int i = 1;
        ps.setString(i++, loan.getLoanName());
        ps.setString(i++, loan.getLenderName());
        ps.setString(i++, loan.getBorrowerName());
        ps.setBigDecimal(i++, loan.getPrincipal());
        ps.setBigDecimal(i++, loan.getAnnualRate());
        ps.setInt(i++, loan.getLoanYears());
        ps.setInt(i++, loan.getPaymentsPerYear());
        ps.setDate(i++, Date.valueOf(loan.getStartDate()));
        ps.setBigDecimal(i++, loan.getExtraPayment());
        ps.setBigDecimal(i++, loan.getScheduledPayment());
        ps.setInt(i++, loan.getScheduledPaymentCount());
        ps.setInt(i++, loan.getActualPaymentCount());
        ps.setBigDecimal(i++, loan.getExtraPaymentTotal());
        ps.setBigDecimal(i++, loan.getTotalInterest());
    }

    @Override
    public void insertPaymentSchedules(int loanId, List<PaymentSchedule> schedules) throws LoanException {
        String sql = "INSERT INTO loan_payments "
                + "(loan_id, payment_no, payment_date, beginning_balance, scheduled_payment, "
                + "extra_payment, total_payment, principal_payment, interest_payment, "
                + "ending_balance, cumulative_interest) "
                + "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

        try (Connection conn = DBUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            for (PaymentSchedule schedule : schedules) {
                int i = 1;
                ps.setInt(i++, loanId);
                ps.setInt(i++, schedule.getPaymentNo());
                ps.setDate(i++, Date.valueOf(schedule.getPaymentDate()));
                ps.setBigDecimal(i++, schedule.getBeginningBalance());
                ps.setBigDecimal(i++, schedule.getScheduledPayment());
                ps.setBigDecimal(i++, schedule.getExtraPayment());
                ps.setBigDecimal(i++, schedule.getTotalPayment());
                ps.setBigDecimal(i++, schedule.getPrincipalPayment());
                ps.setBigDecimal(i++, schedule.getInterestPayment());
                ps.setBigDecimal(i++, schedule.getEndingBalance());
                ps.setBigDecimal(i++, schedule.getCumulativeInterest());
                ps.addBatch();
            }
            ps.executeBatch();
        } catch (SQLException e) {
            throw new LoanException("新增攤還明細失敗", e);
        }
    }

    @Override
    public List<Loan> findAllLoans() throws LoanException {
        String sql = "SELECT * FROM loans ORDER BY id DESC";
        List<Loan> list = new ArrayList<>();
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                list.add(mapLoan(rs));
            }
            return list;
        } catch (SQLException e) {
            throw new LoanException("查詢貸款清單失敗", e);
        }
    }

    @Override
    public Loan findLoanById(int id) throws LoanException {
        String sql = "SELECT * FROM loans WHERE id = ?";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return mapLoan(rs);
                }
            }
            return null;
        } catch (SQLException e) {
            throw new LoanException("查詢貸款失敗", e);
        }
    }

    @Override
    public List<PaymentSchedule> findSchedulesByLoanId(int loanId) throws LoanException {
        String sql = "SELECT * FROM loan_payments WHERE loan_id = ? ORDER BY payment_no";
        List<PaymentSchedule> list = new ArrayList<>();
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, loanId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    PaymentSchedule schedule = new PaymentSchedule();
                    schedule.setId(rs.getInt("id"));
                    schedule.setLoanId(rs.getInt("loan_id"));
                    schedule.setPaymentNo(rs.getInt("payment_no"));
                    schedule.setPaymentDate(rs.getDate("payment_date").toLocalDate());
                    schedule.setBeginningBalance(rs.getBigDecimal("beginning_balance"));
                    schedule.setScheduledPayment(rs.getBigDecimal("scheduled_payment"));
                    schedule.setExtraPayment(rs.getBigDecimal("extra_payment"));
                    schedule.setTotalPayment(rs.getBigDecimal("total_payment"));
                    schedule.setPrincipalPayment(rs.getBigDecimal("principal_payment"));
                    schedule.setInterestPayment(rs.getBigDecimal("interest_payment"));
                    schedule.setEndingBalance(rs.getBigDecimal("ending_balance"));
                    schedule.setCumulativeInterest(rs.getBigDecimal("cumulative_interest"));
                    list.add(schedule);
                }
            }
            return list;
        } catch (SQLException e) {
            throw new LoanException("查詢攤還明細失敗", e);
        }
    }

    @Override
    public void deleteLoan(int loanId) throws LoanException {
        String sql = "DELETE FROM loans WHERE id = ?";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, loanId);
            ps.executeUpdate();
        } catch (SQLException e) {
            throw new LoanException("刪除貸款失敗", e);
        }
    }

    private Loan mapLoan(ResultSet rs) throws SQLException {
        Loan loan = new Loan();
        loan.setId(rs.getInt("id"));
        loan.setLoanName(rs.getString("loan_name"));
        loan.setLenderName(rs.getString("lender_name"));
        loan.setBorrowerName(rs.getString("borrower_name"));
        loan.setPrincipal(rs.getBigDecimal("principal"));
        loan.setAnnualRate(rs.getBigDecimal("annual_rate"));
        loan.setLoanYears(rs.getInt("loan_years"));
        loan.setPaymentsPerYear(rs.getInt("payments_per_year"));
        loan.setStartDate(rs.getDate("start_date").toLocalDate());
        loan.setExtraPayment(rs.getBigDecimal("extra_payment"));
        loan.setScheduledPayment(rs.getBigDecimal("scheduled_payment"));
        loan.setScheduledPaymentCount(rs.getInt("scheduled_payment_count"));
        loan.setActualPaymentCount(rs.getInt("actual_payment_count"));
        loan.setExtraPaymentTotal(rs.getBigDecimal("extra_payment_total"));
        loan.setTotalInterest(rs.getBigDecimal("total_interest"));
        return loan;
    }
}
