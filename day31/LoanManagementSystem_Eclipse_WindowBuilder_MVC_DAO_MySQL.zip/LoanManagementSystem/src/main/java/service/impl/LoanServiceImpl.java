package service.impl;

import dao.LoanDao;
import dao.impl.LoanDaoImpl;
import exception.LoanException;
import model.Loan;
import model.PaymentSchedule;
import service.LoanService;
import util.ExcelReportUtil;

import java.io.File;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class LoanServiceImpl implements LoanService {

    private final LoanDao loanDao = new LoanDaoImpl();

    @Override
    public void initializeDatabase() throws LoanException {
        loanDao.initializeDatabase();
    }

    @Override
    public List<PaymentSchedule> generateSchedule(Loan loan) throws LoanException {
        validateLoan(loan);

        int scheduledCount = loan.getLoanYears() * loan.getPaymentsPerYear();
        BigDecimal scheduledPayment = calculateScheduledPayment(
                loan.getPrincipal(),
                loan.getAnnualRate(),
                loan.getPaymentsPerYear(),
                scheduledCount
        );

        List<PaymentSchedule> schedules = new ArrayList<>();
        BigDecimal balance = money(loan.getPrincipal());
        BigDecimal cumulativeInterest = BigDecimal.ZERO.setScale(2, RoundingMode.HALF_UP);
        BigDecimal extraPaymentTotal = BigDecimal.ZERO.setScale(2, RoundingMode.HALF_UP);
        BigDecimal periodRate = loan.getAnnualRate()
                .divide(BigDecimal.valueOf(loan.getPaymentsPerYear()), 10, RoundingMode.HALF_UP);

        for (int i = 1; i <= scheduledCount && balance.compareTo(BigDecimal.ZERO) > 0; i++) {
            BigDecimal interest = money(balance.multiply(periodRate));
            BigDecimal scheduled = scheduledPayment.min(balance.add(interest));
            BigDecimal extra = loan.getExtraPayment() == null ? BigDecimal.ZERO : loan.getExtraPayment();

            BigDecimal maxExtra = balance.add(interest).subtract(scheduled);
            if (maxExtra.compareTo(BigDecimal.ZERO) < 0) {
                maxExtra = BigDecimal.ZERO;
            }
            extra = money(extra.min(maxExtra));

            BigDecimal totalPayment = money(scheduled.add(extra));
            BigDecimal principalPayment = money(totalPayment.subtract(interest));
            if (principalPayment.compareTo(balance) > 0) {
                principalPayment = balance;
                totalPayment = money(principalPayment.add(interest));
            }

            BigDecimal endingBalance = money(balance.subtract(principalPayment));
            cumulativeInterest = money(cumulativeInterest.add(interest));
            extraPaymentTotal = money(extraPaymentTotal.add(extra));

            PaymentSchedule row = new PaymentSchedule();
            row.setPaymentNo(i);
            row.setPaymentDate(calculatePaymentDate(loan.getStartDate(), i, loan.getPaymentsPerYear()));
            row.setBeginningBalance(balance);
            row.setScheduledPayment(scheduled);
            row.setExtraPayment(extra);
            row.setTotalPayment(totalPayment);
            row.setPrincipalPayment(principalPayment);
            row.setInterestPayment(interest);
            row.setEndingBalance(endingBalance);
            row.setCumulativeInterest(cumulativeInterest);
            schedules.add(row);

            balance = endingBalance;
        }

        loan.setScheduledPayment(scheduledPayment);
        loan.setScheduledPaymentCount(scheduledCount);
        loan.setActualPaymentCount(schedules.size());
        loan.setExtraPaymentTotal(extraPaymentTotal);
        loan.setTotalInterest(cumulativeInterest);

        return schedules;
    }

    private BigDecimal calculateScheduledPayment(BigDecimal principal, BigDecimal annualRate,
                                                 int paymentsPerYear, int paymentCount) {
        double rate = annualRate.doubleValue() / paymentsPerYear;
        double pv = principal.doubleValue();

        if (rate == 0) {
            return money(BigDecimal.valueOf(pv / paymentCount));
        }

        double payment = pv * rate / (1 - Math.pow(1 + rate, -paymentCount));
        return money(BigDecimal.valueOf(payment));
    }

    private LocalDate calculatePaymentDate(LocalDate startDate, int paymentNo, int paymentsPerYear) {
        if (12 % paymentsPerYear == 0) {
            return startDate.plusMonths((long) paymentNo * (12 / paymentsPerYear));
        }
        long days = Math.round(365.0 * paymentNo / paymentsPerYear);
        return startDate.plusDays(days);
    }

    private void validateLoan(Loan loan) throws LoanException {
        if (loan == null) {
            throw new LoanException("貸款資料不可為空");
        }
        if (loan.getLoanName() == null || loan.getLoanName().trim().isEmpty()) {
            throw new LoanException("貸款名稱不可為空");
        }
        if (loan.getPrincipal() == null || loan.getPrincipal().compareTo(BigDecimal.ZERO) <= 0) {
            throw new LoanException("貸款金額必須大於 0");
        }
        if (loan.getAnnualRate() == null || loan.getAnnualRate().compareTo(BigDecimal.ZERO) < 0) {
            throw new LoanException("年利率不可小於 0");
        }
        if (loan.getLoanYears() <= 0 || loan.getPaymentsPerYear() <= 0) {
            throw new LoanException("貸款年限與每年還款次數必須大於 0");
        }
        if (loan.getStartDate() == null) {
            loan.setStartDate(LocalDate.now());
        }
        if (loan.getExtraPayment() == null) {
            loan.setExtraPayment(BigDecimal.ZERO);
        }
    }

    private BigDecimal money(BigDecimal value) {
        return value.setScale(2, RoundingMode.HALF_UP);
    }

    @Override
    public int saveLoanWithSchedule(Loan loan, List<PaymentSchedule> schedules) throws LoanException {
        int loanId = loanDao.insertLoan(loan);
        loanDao.insertPaymentSchedules(loanId, schedules);
        return loanId;
    }

    @Override
    public List<Loan> findAllLoans() throws LoanException {
        return loanDao.findAllLoans();
    }

    @Override
    public Loan findLoanById(int loanId) throws LoanException {
        return loanDao.findLoanById(loanId);
    }

    @Override
    public List<PaymentSchedule> findSchedulesByLoanId(int loanId) throws LoanException {
        return loanDao.findSchedulesByLoanId(loanId);
    }

    @Override
    public void deleteLoan(int loanId) throws LoanException {
        loanDao.deleteLoan(loanId);
    }

    @Override
    public void exportExcelReport(Loan loan, List<PaymentSchedule> schedules, File outputFile) throws LoanException {
        ExcelReportUtil.exportLoanSchedule(loan, schedules, outputFile);
    }
}
