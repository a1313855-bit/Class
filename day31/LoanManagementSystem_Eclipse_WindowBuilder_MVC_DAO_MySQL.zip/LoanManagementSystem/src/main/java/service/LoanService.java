package service;

import exception.LoanException;
import model.Loan;
import model.PaymentSchedule;

import java.io.File;
import java.util.List;

public interface LoanService {
    void initializeDatabase() throws LoanException;
    List<PaymentSchedule> generateSchedule(Loan loan) throws LoanException;
    int saveLoanWithSchedule(Loan loan, List<PaymentSchedule> schedules) throws LoanException;
    List<Loan> findAllLoans() throws LoanException;
    Loan findLoanById(int loanId) throws LoanException;
    List<PaymentSchedule> findSchedulesByLoanId(int loanId) throws LoanException;
    void deleteLoan(int loanId) throws LoanException;
    void exportExcelReport(Loan loan, List<PaymentSchedule> schedules, File outputFile) throws LoanException;
}
