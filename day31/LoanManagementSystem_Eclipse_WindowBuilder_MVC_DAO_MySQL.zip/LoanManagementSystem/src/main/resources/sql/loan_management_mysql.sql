CREATE DATABASE IF NOT EXISTS `loan_management`
  DEFAULT CHARACTER SET utf8mb4
  DEFAULT COLLATE utf8mb4_unicode_ci;

USE `loan_management`;

DROP TABLE IF EXISTS `loan_payments`;
DROP TABLE IF EXISTS `loans`;

CREATE TABLE `loans` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `loan_name` VARCHAR(100) NOT NULL,
  `lender_name` VARCHAR(100) NOT NULL,
  `borrower_name` VARCHAR(100) NOT NULL,
  `principal` DECIMAL(15,2) NOT NULL,
  `annual_rate` DECIMAL(8,6) NOT NULL,
  `loan_years` INT NOT NULL,
  `payments_per_year` INT NOT NULL,
  `start_date` DATE NOT NULL,
  `extra_payment` DECIMAL(15,2) NOT NULL DEFAULT 0,
  `scheduled_payment` DECIMAL(15,2) NOT NULL DEFAULT 0,
  `scheduled_payment_count` INT NOT NULL DEFAULT 0,
  `actual_payment_count` INT NOT NULL DEFAULT 0,
  `extra_payment_total` DECIMAL(15,2) NOT NULL DEFAULT 0,
  `total_interest` DECIMAL(15,2) NOT NULL DEFAULT 0,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `loan_payments` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `loan_id` INT NOT NULL,
  `payment_no` INT NOT NULL,
  `payment_date` DATE NOT NULL,
  `beginning_balance` DECIMAL(15,2) NOT NULL,
  `scheduled_payment` DECIMAL(15,2) NOT NULL,
  `extra_payment` DECIMAL(15,2) NOT NULL,
  `total_payment` DECIMAL(15,2) NOT NULL,
  `principal_payment` DECIMAL(15,2) NOT NULL,
  `interest_payment` DECIMAL(15,2) NOT NULL,
  `ending_balance` DECIMAL(15,2) NOT NULL,
  `cumulative_interest` DECIMAL(15,2) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_loan_payments_loan_id` (`loan_id`),
  CONSTRAINT `fk_loan_payments_loan`
    FOREIGN KEY (`loan_id`) REFERENCES `loans` (`id`)
    ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `loans`
(`id`, `loan_name`, `lender_name`, `borrower_name`, `principal`, `annual_rate`,
 `loan_years`, `payments_per_year`, `start_date`, `extra_payment`,
 `scheduled_payment`, `scheduled_payment_count`, `actual_payment_count`,
 `extra_payment_total`, `total_interest`)
VALUES
(1, '範例貸款', 'Woodgrove Bank', '王小明', 5000, 0.04, 1, 12, '2026-01-01', 100,
 425.75, 12, 10, 900, 89.63);

INSERT INTO `loan_payments`
(`loan_id`, `payment_no`, `payment_date`, `beginning_balance`, `scheduled_payment`,
 `extra_payment`, `total_payment`, `principal_payment`, `interest_payment`,
 `ending_balance`, `cumulative_interest`)
VALUES
(1, 1, '2026-02-01', 5000.00, 425.75, 100.00, 525.75, 509.08, 16.67, 4490.92, 16.67),
(1, 2, '2026-03-01', 4490.92, 425.75, 100.00, 525.75, 510.78, 14.97, 3980.14, 31.64),
(1, 3, '2026-04-01', 3980.14, 425.75, 100.00, 525.75, 512.48, 13.27, 3467.66, 44.91),
(1, 4, '2026-05-01', 3467.66, 425.75, 100.00, 525.75, 514.19, 11.56, 2953.47, 56.47),
(1, 5, '2026-06-01', 2953.47, 425.75, 100.00, 525.75, 515.91, 9.84, 2437.56, 66.31),
(1, 6, '2026-07-01', 2437.56, 425.75, 100.00, 525.75, 517.62, 8.13, 1919.94, 74.44),
(1, 7, '2026-08-01', 1919.94, 425.75, 100.00, 525.75, 519.35, 6.40, 1400.59, 80.84),
(1, 8, '2026-09-01', 1400.59, 425.75, 100.00, 525.75, 521.08, 4.67, 879.51, 85.51),
(1, 9, '2026-10-01', 879.51, 425.75, 100.00, 525.75, 522.82, 2.93, 356.69, 88.44),
(1, 10, '2026-11-01', 356.69, 357.88, 0.00, 357.88, 356.69, 1.19, 0.00, 89.63);
