@echo off
chcp 65001 > nul

echo Importing MySQL schema and sample data...
mysql -u root -p1234 < src\main\resources\sql\loan_management_mysql.sql

if errorlevel 1 (
    echo Import failed. Please check MySQL service and root password.
    pause
    exit /b 1
)

echo Import completed.
pause
