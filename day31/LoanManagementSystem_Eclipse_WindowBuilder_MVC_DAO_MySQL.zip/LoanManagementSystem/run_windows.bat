@echo off
chcp 65001 > nul

echo LoanManagementSystem
echo MySQL: localhost:3306
echo User : root
echo Pass : 1234
echo.

mvn clean package
if errorlevel 1 (
    echo Build failed. Please check Maven/JDK/MySQL dependency settings.
    pause
    exit /b 1
)

java -jar target\LoanManagementSystem-1.0.0.jar
pause
