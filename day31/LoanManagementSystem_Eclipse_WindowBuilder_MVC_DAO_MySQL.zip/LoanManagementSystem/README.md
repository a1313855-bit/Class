# 貸款管理系統

## 專案規格

- JDK 11
- MySQL 8.0
- Eclipse Java SE + WindowBuilder
- Maven Project
- MVC + DAO Pattern

## 資料夾

```text
src/main/java
├── model
├── dao
├── dao/impl
├── service
├── service/impl
├── controller
├── util
├── exception
└── view
```

## 功能

- JFrame UI 輸入貸款資料
- 產生貸款分期償還時間表
- 儲存貸款與攤還明細到 MySQL
- 從 MySQL 載入貸款資料
- JTable 顯示攤還明細
- 匯出 Excel 報表，欄位對應原始 Excel：
  - 還款編號
  - 還款日
  - 期初餘額
  - 已排程還款
  - 額外還款
  - 還款總金額
  - 本金
  - 利息
  - 結餘
  - 累計利息

原始 Excel 範本已保留在：

```text
src/main/resources/templates/loan_schedule_template.xlsx
```

## MySQL 設定

連線設定在：

```text
src/main/java/util/DBUtil.java
```

目前設定：

```text
url=jdbc:mysql://localhost:3306/loan_management
user=root
password=1234
```

完整 SQL 檔：

```text
src/main/resources/sql/loan_management_mysql.sql
```

匯入測試資料：

```bat
mysql -u root -p1234 < src\main\resources\sql\loan_management_mysql.sql
```

## Eclipse 匯入方式

1. Eclipse 選擇 `File -> Import`
2. 選擇 `Maven -> Existing Maven Projects`
3. 選擇本專案資料夾
4. 等 Maven 下載：
   - `mysql-connector-j`
   - `poi-ooxml`
5. 執行：

```text
src/main/java/view/LoanManagementFrame.java
```

輸入欄位說明：

```text
貸款金額：例如 5000
年利率：請輸入百分比，例如 4 代表 4%
貸款期間：年數，例如 1
每年還款次數：每月還款請輸入 12
貸款開始日期：yyyy-MM-dd，例如 2026-01-01
選擇性額外還款：例如 100
```

## WindowBuilder

主要 JFrame：

```text
src/main/java/view/LoanManagementFrame.java
```

右鍵選：

```text
Open With -> WindowBuilder Editor
```

## 打包執行

```bat
mvn clean package
java -jar target\LoanManagementSystem-1.0.0.jar
```
