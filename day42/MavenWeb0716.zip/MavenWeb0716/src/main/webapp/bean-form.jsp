<%@ page contentType="text/html;charset=UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<!DOCTYPE html>
<html lang="zh-TW">
<head>
    <meta charset="UTF-8">
    <title>JavaBean 與表單</title>
    <style>
        body { font-family: "Microsoft JhengHei", Arial; max-width: 800px; margin: 50px auto; padding: 20px; }
        .section { background: #f9f9f9; padding: 15px; margin: 10px 0; border-radius: 5px; }
        h2 { color: #333; border-bottom: 2px solid #3498db; padding-bottom: 5px; }
        .result { color: #27ae60; font-weight: bold; }
        form { margin: 20px 0; }
        label { display: block; margin: 10px 0 5px; }
        input { padding: 8px; width: 300px; }
        button { padding: 10px 20px; background: #3498db; color: white; border: none; border-radius: 5px; cursor: pointer; }
        button:hover { background: #2980b9; }
    </style>
</head>
<body>
    <h1>JavaBean 與表單</h1>
    
    <%-- 建立 Bean --%>
    <%--
    scope="request" 表示 user 物件只存在於這一次 HTTP Request 中。
    --%>
    <jsp:useBean id="user" class="model.User" scope="request" />
    
    <%-- 表單 --%>
    <%-- action="bean-form.jsp" 表示送出後回到同一頁；method="post" 使用 POST --%>
    <div class="section">
        <h2>輸入資料</h2>
        <form method="post" action="bean-form.jsp">
            <label>姓名：</label>
            <%--
            name="name" 是送到伺服器的參數名稱。
            value="${user.name}" 會把 Bean 目前的 name 顯示回輸入框。
            --%>
            <input type="text" name="name" value="${user.name}" />
            
            <label>年齡：</label>
            <input type="number" name="age" value="${user.age}" />
            
            <label>Email：</label>
            <input type="email" name="email" value="${user.email}" />
            
            <br><br>
            <button type="submit">送出</button>
            <button type="reset">清除</button>
        </form>
    </div>
    
    <%-- 處理表單提交 --%>
    <%-- param.name 取得表單送來的 name；not empty 確認有資料後才處理 --%>
    <c:if test="${not empty param.name}">
        <%-- 自動對應表單參數到 Bean --%>
        <%--
        property="*" 會依表單參數名稱，自動呼叫同名 Bean 屬性的 setter。
        name→setName、age→setAge、email→setEmail。
        --%>
        <jsp:setProperty name="user" property="*" />
        
        <div class="section">
            <h2>顯示結果</h2>
            <p>姓名：<span class="result">${user.name}</span></p>
            <p>年齡：<span class="result">${user.age}</span></p>
            <p>Email：<span class="result">${user.email}</span></p>
            <%-- ${user.adult} 會呼叫 User.isAdult()，再用三元運算子把 true／false 轉成「是／否」 --%>
            <p>是否成年：<span class="result">${user.adult ? '是' : '否'}</span></p>
        </div>
    </c:if>
    
    <br>
    <a href="index.jsp">回首頁</a>
</body>
</html>