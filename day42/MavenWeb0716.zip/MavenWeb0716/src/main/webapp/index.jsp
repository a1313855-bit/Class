<html>
<body>
<%--
【Review】
⭐ 建議新增註解：

<%= ... %> 是 JSP Expression，會計算 Java 運算式並直接輸出結果。
--%>
<h2><%= "Hello World!" %></h2>
</body>
</html>
