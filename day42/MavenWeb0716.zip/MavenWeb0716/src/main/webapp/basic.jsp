<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<body>
<h2>1. 建立 Bean 並手動設定屬性</h2>
        <%--
        <jsp:useBean> 建立或取得一個 JavaBean。
        id="user1" 是 JSP／EL 使用的名稱；class 指定 model.User。
        未指定 scope 時，預設為 page scope。
        --%>
        <jsp:useBean id="user1" class="model.User" />
        <%--
        <jsp:setProperty> 透過 setter 設定 JavaBean 屬性。
        property="name" 會呼叫 user1.setName("張小明")。
        --%>
        <jsp:setProperty name="user1" property="name" value="張小明" />
        <jsp:setProperty name="user1" property="age" value="25" />
        <jsp:setProperty name="user1" property="email" value="ming@example.com" />
        <jsp:setProperty name="user1" property="active" value="true" />
    <h2>
       <%--
       EL 讀取 JavaBean 屬性時會依命名規則呼叫 getter：
       ${user1.name} → getName()
       ${user1.status} → getStatus()
       ${user1.greeting} → getGreeting()
       --%>
       Name : ${user1.name}<br/>
       Status : ${user1.status}<br/>
       Greeting : ${user1.greeting}
    </h2>
</body>
</html>