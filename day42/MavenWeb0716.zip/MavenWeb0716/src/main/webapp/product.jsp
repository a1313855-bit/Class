<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<%@page import="model.Product" %>
<%--
本頁使用 class="model.Product" 的完整類別名稱，
所以這個 import 目前不是必要的；可能只是示範 page import 語法。
--%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Product JSP</title>
</head>
<body>
<%--
<jsp:useBean> 建立 Product，名稱為 myproduct。
內部的 property="*" 會把同名表單參數自動設定到 Bean：
num→setNum、pname→setPname、place→setPlace、price→setPrice。

表單參數原本是文字，JSP 會嘗試將 price 轉成 int；
無法轉成整數時可能發生錯誤。
--%>
<jsp:useBean class="model.Product" id="myproduct">
  <jsp:setProperty name="myproduct"  property="*"></jsp:setProperty>
</jsp:useBean>
<h2>
  <%--
  EL 透過 getter 讀取 Bean：
  ${myproduct.num}→getNum()、${myproduct.pname}→getPname()、
  ${myproduct.place}→getPlace()、${myproduct.price}→getPrice()。
  --%>
  No.:${myproduct.num}<br/>
  Name:${myproduct.pname}<br/>
  Place:${myproduct.place}<br/>
  Price:${myproduct.price}<br/>
</h2>
</body>
</html>