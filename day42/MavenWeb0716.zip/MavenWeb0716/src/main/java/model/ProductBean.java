package model;



/*
ProductBean 用來保存產品清單中的單筆產品資料。
bean-list.jsp 會建立多個 ProductBean，再放進 ArrayList 中顯示。

✅ 這個類別符合常見 JavaBean 結構：
- private 欄位
- public 無參數建構子
- getter／setter
*/
public class ProductBean {
    private int id;
    private String name;
    private double price;
    private int stock;
    
    /* 無參數建構子，符合 JavaBean 的基本慣例 */
    public ProductBean() {}
    
    public ProductBean(int id, String name, double price, int stock) {
        this.id = id;
        this.name = name;
        this.price = price;
        this.stock = stock;
    }
    
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    
    public double getPrice() { return price; }
    public void setPrice(double price) { this.price = price; }
    
    public int getStock() { return stock; }
    public void setStock(int stock) { this.stock = stock; }
    
    // 業務方法

    /*
    getStockStatus() 會依據 stock 數量，回傳「缺貨／庫存不足／現貨」。

    EL 使用 ${product.stockStatus} 時，
    實際上會依 JavaBean 命名規則呼叫 getStockStatus()。
    */
    public String getStockStatus() {
        if (stock == 0) return "缺貨";
        if (stock <= 5) return "庫存不足";
        return "現貨";
    }
}
