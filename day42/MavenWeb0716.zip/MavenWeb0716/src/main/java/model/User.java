package model;

/*
User 是用來保存使用者資料的 JavaBean。
basic.jsp 與 bean-form.jsp 都會透過 JSP／EL 存取這個物件。

注意：
欄位名稱是 username，但 getter／setter 使用 getName()、setName()。
因此 EL 的屬性名稱是 name，而不是 username。
*/
public class User {
    private String username;
    private int age;
    private String email;
    private boolean active;
    
    /*
    無參數建構子。
    <jsp:useBean> 建立 User 物件時會使用它。
    */
    public User() {}
    
    public User(String name, int age, String email, boolean active) {
        this.username = name;
        this.age = age;
        this.email = email;
        this.active = active;
    }
    
    public String getName() { return username; }
    public void setName(String name) { this.username = name; }
    
    public int getAge() { return age; }
    public void setAge(int age) { this.age = age; }
    
    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }
    
    public boolean isActive() { return active; }
    public void setActive(boolean active) { this.active = active; }
    
    // 業務方法

    /*
    isAdult() 依據 age 判斷是否成年。
    EL 使用 ${user.adult} 時，會呼叫 isAdult()。
    */
    public boolean isAdult() {
        return age >= 18;
    }
    /*
    將 boolean active 轉換成適合顯示在畫面上的文字。
    EL 使用 ${user.status} 時，會呼叫 getStatus()。
    */
    public String getStatus() {
        return active ? "啟用" : "停用";
    }
    /*
    根據 username 組合問候文字。
    EL 使用 ${user.greeting} 時，會呼叫 getGreeting()。
    */
    public String getGreeting() {
        return "您好，我是 " + username + "！";
    }
}