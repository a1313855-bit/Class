package model;

/*
Product 是用來保存產品資料的 JavaBean／資料物件。
product.jsp 會透過 <jsp:useBean> 建立它，並使用表單參數設定屬性。

實務補充（老師尚未教到）
JavaBean 的欄位通常會宣告為 private，再透過 public getter、setter 存取。
這份範例的欄位沒有寫 private，程式仍可運作，但封裝性較弱。
*/
public class Product {
   String num;
   String pname;
   int price;
   String place;
   /*
   無參數建構子。
   <jsp:useBean> 建立 Bean 時，預設需要呼叫無參數建構子。
   */
   public Product() {
   }
   /*
   有參數建構子，方便建立物件時一次設定全部產品資料。

   實務補充
   這個建構子目前沒有被 <jsp:useBean> 使用；
   <jsp:useBean> 會先建立空物件，再透過 setter 設定屬性。
   */
   public Product(String num, String pname,String place, int price) {	
	this.num = num;
	this.pname = pname;
	this.place=place;
	this.price = price;
   }
   public String getNum() {
	return num;
   }
   public void setNum(String num) {
	this.num = num;
   }
   public String getPname() {
	return pname;
   }
   public void setPname(String pname) {
	this.pname = pname;
   }
   public int getPrice() {
	return price;
   }
   public void setPrice(int price) {
	this.price = price;
   }
   public String getPlace() {
	return place;
   }
   public void setPlace(String place) {
	this.place = place;
   }
   
}
