

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * Servlet implementation class TestServlet
 */
/*
【Review】
⭐ 建議新增註解：

@WebServlet("/test") 將網址路徑 /test 對應到這個 Servlet。
Tomcat 收到該路徑的請求後，會交給 TestServlet 處理。
*/
@WebServlet("/test")
public class TestServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public TestServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	/*
    【Review】
    ⭐ 建議新增註解：

    doGet() 負責處理 HTTP GET 請求。
    request 保存瀏覽器送來的請求資料；response 用來回傳伺服器回應。
    */
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		/*
        【Review】
        💡 建議補充：

        response.getWriter() 取得文字輸出物件。
        request.getContextPath() 取得目前 Web 專案的根路徑。
        */
        response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	/*
    【Review】
    ⭐ 建議新增註解：

    doPost() 負責處理 HTTP POST 請求。
    這份範例會再呼叫 doGet()，代表 GET 與 POST 暫時共用相同流程。
    */
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
