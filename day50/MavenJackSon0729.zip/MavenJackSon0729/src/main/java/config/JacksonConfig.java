package config;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import jakarta.ws.rs.ext.ContextResolver;
import jakarta.ws.rs.ext.Provider;
/* 📖 概念 : 把這個類別註冊給 REST 框架使用的 Annotation */
/* 🔍 原因 : JAX-RS 自動發現並使用 */
@Provider

/* ContextResolver<ObjectMapper> */
/* 📖 概念 : 提供 ObjectMapper */
/* 🔍 原因 : 全專案共用同一個設定 */
public class JacksonConfig implements ContextResolver<ObjectMapper> {
    private final ObjectMapper mapper;

    /* 📖 概念 : 初始化 mapper */
    public JacksonConfig() {
    	/* 📖 概念 : 建立 Jackson 的核心物件 */
        mapper = new ObjectMapper();
        
        /* 📖 概念 : 支援 Java 8 日期時間 */
        /* 🔍 原因 : LocalDate、LocalDateTime 等可正常轉換 */
        mapper.registerModule(new JavaTimeModule());
        
        /* WRITE_DATES_AS_TIMESTAMPS 關閉 */
        /* 📖 概念 : 日期不要輸出成時間戳或陣列 */
        /* 🔍 原因 : 以可讀的日期字串表示 */
        mapper.disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);
        
        /* FAIL_ON_UNKNOWN_PROPERTIES 關閉 */
        /* 📖 概念 : 忽略未知 JSON 欄位 */
        /* 🔍 原因 : API 對新增欄位更有相容性 */
        mapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
        
        /* 📖 概念 : 不輸出 null 欄位 */
        /* 🔍 原因 : JSON 更精簡 */
        mapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);
        
        /* 📖 概念 : 控制 JSON 名稱 */
        /* 🔍 原因 : 與 Java 欄位命名一致 */
        /* LOWER_CAMEL_CASE 駝峰命名 */       
        mapper.setPropertyNamingStrategy(PropertyNamingStrategies.LOWER_CAMEL_CASE);
    }

    @Override
    public ObjectMapper getContext(Class<?> type) {
        return mapper;
    }
    
    /* 📖 概念 : */
    /* ObjectMapper  -> 負責 Java 物件 ↔ JSON 轉換的核心 */
    /* JacksonConfig -> 告訴整個 REST API */
    /* 日期怎麼表示。 */
    /* 遇到未知欄位怎麼處理 */
    /* null 要不要輸出 */
    /* JSON 欄位採用什麼命名方式 */
}
