package model;

import com.fasterxml.jackson.annotation.*;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Date;

public class Product {

	private int id;

	/* 📖 概念 : 指定 JSON 的欄位名稱 */
	@JsonProperty("product_name")
	/* @JsonProperty("product_name") */
	/* Java : productName="iPhone"; */
	/* JSON 輸出 : */
	/* { "product_name": "iPhone" } */
	/* 📝 範例 : */
	/* 不使用 @JsonProperty */
	/* productName="Mr.A"; */
	/* JSON 輸出 : */
	/* { "productName": "iPhone" } */
	
	/* 📖 概念 : 允許多個 JSON 名稱對應到同一個 Java 欄位 */
	/* ❄ 重點 : */
	/* 只影響讀取(JSON → Java) */
	/* 不影響輸出(Java → JSON) */
	@JsonAlias({ "productName", "product_name", "name" })
	/* JSON : { "productName": "iPhone" } 或 { "product_name": "iPhone" } 或 { "name": "iPhone" } */
	/* Java : productName=iPhone */
	/* ⚠ 注意 : 不影響輸出(Java → JSON) */
	/* Java : productName=iPhone */
	/* JSON : { "productName": "iPhone" } */
	/* ✏ 補充: 想印出 { "product_name": "iPhone" } */
	/* 加上 @JsonProperty("product_name") */
		
	private String name;
	private double price;

	/* 📖 概念 : 忽略這個欄位 */
	/* 不會 ： 輸出 讀取 */
	/* 💡 我的理解 : 隱藏 Json 屬性(不是消失) */	
	@JsonIgnore
	private String internalCode;

	/* 📖 概念 : 指定格式 */
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	private Date createdAt;

	/* 📖 概念 : 控制哪些欄位要輸出 */
	@JsonInclude(JsonInclude.Include.NON_NULL)
	/* null 不輸出 */
	private String remark;

	public Product() {
		/* 📖 概念 : */
		/* LocalDateTime.now() -> 格林威治天文臺標準時間 */
		/* plusHours(8) -> 加上8小時(台灣時間) */
		this.createdAt = Date.from(LocalDateTime.now().plusHours(8).atZone(ZoneId.systemDefault()).toInstant());
	}

	public Product(int id, String name, double price) {
		this();
		this.id = id;
		this.name = name;
		this.price = price;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public String getInternalCode() {
		return internalCode;
	}

	public void setInternalCode(String internalCode) {
		this.internalCode = internalCode;
	}

	public Date getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(Date createdAt) {
		this.createdAt = createdAt;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	@Override
	public String toString() {
		return "Product [id=" + id + ", name=" + name + ", price=" + price + ", internalCode=" + internalCode
				+ ", createdAt=" + createdAt + ", remark=" + remark + "]";
	}
	
	
}
