package config;

import java.util.HashSet;
import java.util.Set;

import jakarta.ws.rs.ApplicationPath;
import jakarta.ws.rs.core.Application;

@ApplicationPath("/srv")
public class MyServiceApp extends Application {
	
	/* 💡 我的理解 : 入口授權 */
	public Set<Class<?>> getClasses() {
		/* ✏ 補充 : 目前 <jersey.version>3.1.11</jersey.version> */
		/* 版本 : 3.0 之前必須 HashSet<>() 手動註冊 controller 內的類別 */
		/* 版本 : 3.0 之後如果沒有手動註冊系統會自動搜尋 controller 內的類別 */
		/* 📖 概念 : 這邊沒有特別寫註冊類別，所以系統自動搜尋 controller 內的類別 */
		return new HashSet();
	}
}
