package config;

import java.util.HashSet;
import java.util.Set;

import controller.Hello;
import controller.ProductController;
import jakarta.ws.rs.ApplicationPath;
import jakarta.ws.rs.core.Application;

@ApplicationPath("/api")
public class MyCRUDApp extends Application {
	
	/* 💡 我的理解 : 入口授權 */
	/* ✏ 補充 :　如果沒有寫註冊動作，這個 Path 就可以進入所有的類別網址 */
	/* 📐 應用 : 某些網站可能需要限制 */
	public Set<Class<?>> getClasses(){
		Set<Class<?>> classes=new HashSet<>();
		/* ✏ 補充 : 目前 <jersey.version>3.1.11</jersey.version> */
		/* 版本 : 3.0 之前必須 HashSet<>() 手動註冊 */
		/* 版本 : 3.0 之後如果沒有手動註冊系統會自動搜尋 */
		/* 📖 概念 : 這邊我們註冊了 Hello 所以只能進入 /api/hello */
		classes.add(Hello.class);
		/* 📖 概念 : 如果要進入 HelloWorld 必須註冊 HelloWorld */
		//classes.add(HelloWorld.class);
		classes.add(ProductController.class);
		return classes;
	}
}
