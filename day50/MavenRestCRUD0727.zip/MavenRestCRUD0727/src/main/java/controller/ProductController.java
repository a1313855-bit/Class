package controller;

import java.net.URI;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.DefaultValue;
import jakarta.ws.rs.FormParam;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.PATCH;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.Context;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.core.UriInfo;
import model.Product;
import model.ProductDao;
import model.ProductdbDao;

@Path("/products")
/* 💡 我的理解 : 告訴伺服器回傳的類型是 JSON */
@Produces(MediaType.APPLICATION_JSON)
/* 💡 我的理解 : 告訴伺服器接收的類型是 JSON */
@Consumes(MediaType.APPLICATION_JSON)
public class ProductController {
	ProductdbDao dao=new ProductdbDao();
	
	/* 💡 我的理解 : 用 ProductDao 方法查詢所有資料 */
	@GET	
	public Response getAllProducts() {
		List<Product> data=dao.getAll();
		if(data!=null && data.size()>0) {
			/* 💡 我的理解 : 200 OK (成功) */
			return Response.ok(data).build();
		}else {
			/* 💡 我的理解 : 204 NO_CONTENT (成功但無資料) */
			return Response.status(Response.Status.NO_CONTENT).build();
		}
	}
	
	/* 💡 我的理解 : 用 ProductDao 方法查詢該商品(name)資料 */
	@GET
	@Path("/query")
	public Response queryByName(@DefaultValue("na") @QueryParam("name") String name) {
		Optional<Product> found=dao.findByName(name);
		if(found.isEmpty()) {
			return Response.status(Response.Status.NOT_FOUND)
					.entity("Product not found: "+ name)
					.build();
		}
		return Response.ok(found.get()).build();
	}
	
	/* 💡 我的理解 : 用 ProductDao 方法查詢該商品(id)資料 */
	@GET
	@Path("/{id}")
	public Response productGetById(@PathParam("id") String id) {
		Optional<Product> data=dao.find(id);
		/* 💡 我的理解 : .isEmpty -> 是空的 */
		if(data.isEmpty()) {
			/* 💡 我的理解 : 404 NOT_FOUND (查無資料) */
			return Response.status(Response.Status.NOT_FOUND)
					.entity("Product not found: "+id)
					.build();
		}
		/* 💡 我的理解 : 200 OK (成功) */
		return Response.ok(data.get()).build();
	}
	
	/* 📖 概念 : */
	// ── @POST + @Context UriInfo ──────────────────────────────
    // 對應 POST /api/employees
    // @Context UriInfo 注入請求 URI 資訊，用來建構 Location Header
    // 成功回傳 201 Created，含 Location Header 指向新資源
    // 必填欄位不合法回傳 400 Bad Request
    //────────────────────────────────────────────────────────────	
	/* 💡 我的理解 : 用 ProductDao 方法新增資料 */
	@POST
	public Response create(Product pt,@Context UriInfo uriInfo) {
		if(pt.getName() == null || pt.getName().isBlank()) {
			/* 💡 我的理解 : 400 BAD_REQUEST (請求格式錯誤) */
			return Response.status(Response.Status.BAD_REQUEST)
					.entity("Product Name is reqired")
					.build();
		}
		
		dao.addProduct(pt);
		
		/* 💡 我的理解 : uriInfo.getAbsolutePathBuilder() 網址絕對路徑 */
		URI location = uriInfo.getAbsolutePathBuilder()
				/* 💡 我的理解 : 加上 id */
				.path(String.valueOf(pt.getId()))
				.build();
		/* 💡 我的理解 : 201 CREATED (新增成功) */
		return Response.created(location)
				.entity(pt)
				.build();
	}
	
	/* ✏ 補充 : 用表單來填入資料(html) */
	@POST
	@Path("/myform")
	/* 💡 我的理解 : 從 html 接收的資料型態 */
	@Consumes(MediaType.APPLICATION_FORM_URLENCODED)
	/* 💡 我的理解 : 從表單接收資料(html) */
	public Response formcreate(@FormParam("id") String id,
			@FormParam("name") String name,
			@FormParam("price") double price,
			@Context UriInfo uriInfo) {
		if(name == null || name.isBlank()) {
			/* 💡 我的理解 : 400 BAD_REQUEST (請求格式錯誤) */
			return Response.status(Response.Status.BAD_REQUEST)
					.entity("Product Name is reqired")
					.build();
		}
		Product pt=new Product(id,name,price);
		dao.addProduct(pt);
		
		/* 💡 我的理解 : uriInfo.getAbsolutePathBuilder() 網址絕對路徑 */
		URI location = uriInfo.getAbsolutePathBuilder()
				/* 💡 我的理解 : 加上 id */
				.path(String.valueOf(pt.getId()))
				.build();
		/* 💡 我的理解 : 201 CREATED (新增成功) */
		return Response.created(location)
				.entity(pt)
				.build();
	}
	
	/* 💡 我的理解 : 用 ProductDao 方法修改資料 */
	@PUT
	@Path("/{id}")
	public Response update(@PathParam("id") String id, Product updated) {
		Product pt=dao.updateById(id, updated);
		/* 💡 我的理解 : 如果 id 搜尋到的物件是 null */
		if(pt == null) {
			/* 💡 我的理解 : 404 NOT_FOUND (查無資料) */
			return Response.status(Response.Status.NOT_FOUND)
					.entity("Product not found: "+id)
					.build();			
		}
		if(updated.getName() == null || updated.getName().isBlank()) {
			/* 💡 我的理解 : 400 BAD_REQUEST (請求格式錯誤) */
			return Response.status(Response.Status.BAD_REQUEST)
					.entity("Product Name is required")
					.build();
		}
		return Response.ok(pt).build();
	}
	
	/* 📖 概念 : */
	// ── @PATCH + @Path + @PathParam + Map<String, Object> ────
    // 對應 PATCH /api/employees/{id}
    // 只更新請求中有提供的欄位，其餘保持不變
    // 數值型別轉換需用 ((Number) value).doubleValue()
    // 成功回傳 200 OK，不存在回傳 404
    //────────────────────────────────────────────────────────────
	@PATCH
	@Path("/{id}")
	public Response partialUpdate(@PathParam("id") String id,
			Map<String, Object> fields) {
		Optional<Product> found=dao.find(id);
		if(found.isEmpty()) {
			return Response.status(Response.Status.NOT_FOUND)
					.entity("Product not found: "+id)
					.build();
		}
		Product pt=found.get();
		/* ❓ 疑問 : 這段 Lambda 語法看不懂 */
		fields.forEach((key, value) -> {
			switch(key) {
				case "name"  -> pt.setName((String) value);
				case "price" -> pt.setPrice(((Number) value).doubleValue());
			}
		});
		dao.updateById(id,pt);
		return Response.ok(pt).build();
	}
	
	@DELETE
	@Path("/{id}")
	public Response delete(@PathParam("id") String id) {
		Product obj=dao.deleteById(id);
		if(obj==null) {
			return Response.status(Response.Status.NOT_FOUND)
					.entity("Product not found: "+id)
					.build();
		}
		return Response.ok(obj).build();
	}
}
