package model;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class ProductDao {
	/* 💡 我的理解 : 先創建一次性資料模型 */
	static List<Product> products=new ArrayList<>();
	static {
		products.add(new Product("P01","Apple",30.0));
		products.add(new Product("P02","Banana",25.0));
		products.add(new Product("P03","Lemon",20.0));
	}
	
	/* 💡 我的理解 : 查詢所有資料 */
	public List<Product> getAll(){
		return products;
	}
	
	/* 💡 我的理解 : 用 id 查詢該資料 */
	public Optional<Product> find(String id){
		return products.stream().filter(p ->p.getId().equalsIgnoreCase(id)).findFirst();
	}
	
	/* 💡 我的理解 : 用 name 查詢該資料 */
	public Optional<Product> findByName(String name){
		return products.stream().filter(p ->p.getName().equalsIgnoreCase(name)).findFirst();
	}
	
	/* 💡 我的理解 : 新增資料 */
	public boolean addProduct(Product product) {
		return products.add(product);
	}
	
	/* 💡 我的理解 : 用 id 找到資料後修改 */
	public Product updateById(String id,Product updateObject) {
		Product obj=products.stream().filter(p ->p.getId().equalsIgnoreCase(id))
				.findFirst().orElse(null);
		if(obj!=null) {
			obj.setId(id);
			obj.setName(updateObject.getName());
			obj.setPrice(updateObject.getPrice());
			return obj;
		}else {
			return null;
		}		
	}
	
	/* 💡 我的理解 : 用 id 找到資料後刪除 */
	 public Product deleteById(String id) {
//		Optional<Product> found=products.stream()
//				.filter(p-> p.getId().equalsIgnoreCase(id)).findFirst();
//		if(found.isPresent()) {
//			Product del=found.get();
//			product.remove(del);
//			return del;
//		}else {
//			return null;
//		}
		/* ✏ 補充 : Lambda 語法 */
		Optional<Product> found=products.stream()
				.filter(p-> p.getId().equalsIgnoreCase(id)).findFirst();
		boolean flag=products.removeIf(p-> p.getId().equalsIgnoreCase(id));
		if(flag) {
			return found.get();
		}else {
			return null;
		}
	}
}
